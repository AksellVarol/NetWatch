package com.aksell.netwatch

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.random.Random

data class PingStats(val host: String, val ok: Boolean, val avgMs: Double, val minMs: Double, val maxMs: Double, val lossPct: Int, val jitterMs: Double, val raw: String, val completed: Boolean = true, val burst: Int = 0)
data class Timed(val ok: Boolean, val ms: Long, val note: String)

object Diagnostics {
    // Bounded command runner: the output is read on a separate thread (so a full
    // buffer can never deadlock the process) and the process is forcibly killed
    // after timeoutSec — a command can never run longer than ~timeoutSec + 2s.
    data class CmdRun(val out: String, val timedOut: Boolean, val startFailed: Boolean)
    fun runCmdDetailed(vararg args: String, timeoutSec: Int = 8): CmdRun {
        return try {
            val p = ProcessBuilder(*args).redirectErrorStream(true).start()
            val sb = StringBuilder()
            val reader = Thread {
                try {
                    val br = BufferedReader(InputStreamReader(p.inputStream))
                    var line: String?
                    while (br.readLine().also { line = it } != null) { sb.append(line).append("\n") }
                } catch (e: Exception) {}
            }
            reader.start()
            val finished = p.waitFor(timeoutSec.toLong(), TimeUnit.SECONDS)
            if (!finished) {
                try { p.destroyForcibly() } catch (e: Exception) {}
                try { p.waitFor(1, TimeUnit.SECONDS) } catch (e: Exception) {}
            }
            reader.join(1000)
            CmdRun(sb.toString(), !finished, false)
        } catch (e: Exception) { CmdRun("", false, true) }
    }
    private fun runCmd(vararg args: String, timeoutSec: Int = 8): String = runCmdDetailed(*args, timeoutSec = timeoutSec).out

    // True when the system ping binary is missing (not "no internet" — a
    // different failure, reported as such wherever ping is used).
    @Volatile var pingMissing: Boolean = false
        private set

    // Bounded ping run: returns every reply time, whether the process finished
    // in time, and whether the ping binary itself is missing. Never blocks
    // longer than count*2 + 5 seconds.
    data class PingRun(val times: List<Double>, val completed: Boolean, val binaryMissing: Boolean, val raw: String)
    fun pingLines(host: String, count: Int): PingRun {
        val r = runCmdDetailed("ping", "-c", count.toString(), "-W", "2", host, timeoutSec = count * 2 + 5)
        if (r.startFailed) { pingMissing = true; return PingRun(emptyList(), false, true, "دستور ping در دسترس نیست") }
        val times = Regex("time=([0-9.]+)").findAll(r.out).mapNotNull { it.groupValues.get(1).toDoubleOrNull() }.toList()
        return PingRun(times, !r.timedOut, false, r.out)
    }

    // One single ICMP ping, for live updates. Returns the RTT in ms, or null on timeout.
    fun pingOnce(host: String = "1.1.1.1"): Double? {
        val r = runCmdDetailed("ping", "-c", "1", "-W", "1", host, timeoutSec = 3)
        if (r.startFailed) { pingMissing = true; return null }
        return Regex("time=([0-9.]+)").find(r.out)?.groupValues?.get(1)?.toDoubleOrNull()
    }

    // ---- ICMP sequence helpers (issue 10) ----
    // Android's toybox ping prints NO line for a lost packet, so counting
    // lines that contain "timeout" always yields burst 0. The only honest
    // signal is the icmp_seq gap in the reply lines. The sequence base is
    // NOT assumed (toybox may start at 0 or 1): the expected range starts
    // at the first seq actually seen.
    fun parseIcmpSeqs(raw: String): List<Int> =
        Regex("icmp_seq=(\\d+)").findAll(raw).mapNotNull { it.groupValues.get(1).toIntOrNull() }.toList()

    // Longest run of consecutively missing seqs. When the run completed,
    // the expected range is firstSeq..firstSeq+count-1 (a trailing loss
    // counts); when it was killed early, only seqs up to the highest one
    // seen count — packets never sent are not "lost".
    fun seqBurst(raw: String, count: Int, completed: Boolean): Int {
        val seqs = parseIcmpSeqs(raw).toSortedSet()
        if (seqs.isEmpty()) return if (completed) count else 0
        val start = seqs.first()
        val end = if (completed) start + count - 1 else seqs.last()
        var burst = 0; var cur = 0
        for (s in start..end) {
            if (s in seqs) cur = 0 else { cur++; if (cur > burst) burst = cur }
        }
        return burst
    }

    // mdev from the "rtt min/avg/max/mdev = ..." summary line, or null
    // when ping printed no summary (then callers fall back to the
    // mean-absolute-successive-difference of the reply times).
    fun mdevJitter(raw: String): Double? =
        Regex("rtt min/avg/max/mdev = [0-9.]+/[0-9.]+/[0-9.]+/([0-9.]+)").find(raw)?.groupValues?.get(1)?.toDoubleOrNull()

    fun pingStats(host: String): PingStats {
        val count = 4
        val run = pingLines(host, count)
        if (run.binaryMissing || run.raw.isBlank()) {
            // Binary missing (or no output at all): nothing was measured.
            // completed=false and lossPct=-1 mean "unknown", NOT 100%.
            return PingStats(host, false, 0.0, 0.0, 0.0, -1, 0.0, if (run.binaryMissing) run.raw else "دستور ping در دسترس نیست یا جواب نداد", completed = false, burst = 0)
        }
        val out = run.raw
        // Loss from the icmp_seq values actually seen (unique), not from
        // the "N% packet loss" summary line — the line may be absent when
        // the process is killed, and then loss is unknown (-1), not 100%.
        val seqs = parseIcmpSeqs(out).toSet()
        val received = if (seqs.isNotEmpty()) seqs.size else run.times.size
        val lossPct = if (!run.completed) -1 else (count - received).coerceIn(0, count) * 100 / count
        val burst = seqBurst(out, count, run.completed)
        val rtt = Regex("rtt min/avg/max/mdev = ([0-9.]+)/([0-9.]+)/([0-9.]+)/([0-9.]+)").find(out)
        val times = run.times
        // Jitter is the mdev of the rtt line when ping printed one;
        // otherwise the mean absolute successive difference of the
        // reply times (same fallback definition as Gaming.pingHost).
        val jitter = mdevJitter(out) ?: if (times.size > 1) (1 until times.size).map { kotlin.math.abs(times[it] - times[it - 1]) }.average() else 0.0
        return if (rtt != null) {
            PingStats(host, times.isNotEmpty(), rtt.groupValues[2].toDouble(), rtt.groupValues[1].toDouble(), rtt.groupValues[3].toDouble(), lossPct, jitter, out.trim(), completed = run.completed, burst = burst)
        } else {
            val sorted = times.sorted()
            PingStats(host, times.isNotEmpty(), if (times.isEmpty()) 0.0 else times.average(), sorted.firstOrNull() ?: 0.0, sorted.lastOrNull() ?: 0.0, lossPct, jitter, out.trim(), completed = run.completed, burst = burst)
        }
    }

    // Real UDP DNS query with a random transaction ID — no JVM/system DNS cache
    // is involved, so repeated measurements give real, differing times.
    private fun buildDnsQuery(host: String, id: Int): ByteArray {
        val out = mutableListOf<Byte>()
        out.add(((id shr 8) and 0xFF).toByte())
        out.add((id and 0xFF).toByte())
        out.add(0x01); out.add(0x00)                 // flags: RD
        out.add(0x00); out.add(0x01)                 // QDCOUNT = 1
        repeat(6) { out.add(0x00) }                  // AN, NS, AR = 0
        for (label in host.split(".").filter { it.isNotEmpty() }) {
            val bytes = label.toByteArray(Charsets.US_ASCII)
            require(bytes.size <= 63) { "برچسب DNS بیش از ۶۳ بایت است" }
            out.add(bytes.size.toByte())
            bytes.forEach { out.add(it) }
        }
        out.add(0x00)
        out.add(0x00); out.add(0x01)                 // QTYPE = A
        out.add(0x00); out.add(0x01)                 // QCLASS = IN
        return out.toByteArray()
    }

    fun udpDns(serverIp: String, hostname: String = "google.com"): Timed {
        val start = System.nanoTime()
        fun elapsedMs() = (System.nanoTime() - start) / 1_000_000
        return try {
            val id = Random.nextInt(0, 0xFFFF)
            val query = buildDnsQuery(hostname, id)
            DatagramSocket().use { sock ->
                sock.soTimeout = 4000
                sock.send(DatagramPacket(query, query.size, InetAddress.getByName(serverIp), 53))
                val buf = ByteArray(512)
                val pkt = DatagramPacket(buf, buf.size)
                sock.receive(pkt)
                val ms = elapsedMs()
                if (pkt.length < 12) return Timed(false, ms, "پاسخ DNS کوتاه است")
                val rid = ((buf[0].toInt() and 0xFF) shl 8) or (buf[1].toInt() and 0xFF)
                val isResponse = (buf[2].toInt() and 0x80) != 0
                val rcode = buf[3].toInt() and 0x0F
                return when {
                    rid != id -> Timed(false, ms, "ID پاسخ مطابقت ندارد")
                    !isResponse -> Timed(false, ms, "پیام دریافتی پاسخ DNS نیست")
                    rcode == 0 -> Timed(true, ms, "پاسخ موفق DNS")
                    rcode == 3 -> Timed(false, ms, "NXDOMAIN: دامنه وجود ندارد")
                    else -> Timed(false, ms, "خطای DNS با کد $rcode")
                }
            }
        } catch (e: SocketTimeoutException) {
            Timed(false, elapsedMs(), "timeout: پاسخ DNS نرسید")
        } catch (e: Exception) {
            Timed(false, elapsedMs(), e.javaClass.simpleName)
        }
    }

    // DNS resolution time on a specific resolver (default Cloudflare 1.1.1.1).
    // A real UDP query is sent, so the system DNS cache cannot fake a 0ms result.
    // An IP literal needs no resolution at all.
    fun dnsTime(host: String, resolver: String = "1.1.1.1"): Timed {
        // An IP literal needs no resolution — that is N/A, NOT a 0ms DNS success.
        // Callers that test IP hosts must not count this as a passed DNS test.
        if (host.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}$"))) return Timed(false, 0, "N/A — IP مستقیم نیازی به resolve ندارد")
        return udpDns(resolver, host)
    }

    // DNS resolution with the SYSTEM resolver (issue 22): InetAddress
    // uses the device's configured DNS, unlike dnsTime() which always
    // asks 1.1.1.1. An IP literal needs no resolution at all (N/A, not 0ms).
    fun systemDnsTime(host: String): Timed {
        if (host.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}$"))) return Timed(false, 0, "N/A — IP مستقیم نیازی به resolve ندارد")
        val start = System.nanoTime()
        return try {
            val a = InetAddress.getByName(host)
            Timed(true, (System.nanoTime() - start) / 1_000_000, a.hostAddress ?: "")
        } catch (e: Exception) {
            Timed(false, (System.nanoTime() - start) / 1_000_000, e.javaClass.simpleName)
        }
    }

    // Real DNS-over-TLS: TLS handshake to :853, then a real DNS query over the
    // TLS stream (2-byte length prefix + DNS message, response validated).
    // This is a genuine DoT test — not a bare TCP connect to port 853.
    fun dotQuery(serverIp: String, hostname: String = "google.com"): Timed {
        val start = System.nanoTime()
        fun elapsedMs() = (System.nanoTime() - start) / 1_000_000
        return try {
            Socket().use { raw ->
                raw.connect(InetSocketAddress(serverIp, 853), 5000)
                val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
                (factory.createSocket(raw, serverIp, 853, true) as SSLSocket).use { ssl ->
                    ssl.soTimeout = 5000
                    // Issue 18: without endpoint identification the socket
                    // only validates the chain, not that the certificate
                    // matches this host — a transparent proxy with a valid
                    // cert for another domain would pass as "real DoT".
                    val params = ssl.sslParameters
                    params.endpointIdentificationAlgorithm = "HTTPS"
                    ssl.sslParameters = params
                    ssl.startHandshake()
                    val id = Random.nextInt(0, 0xFFFF)
                    val query = buildDnsQuery(hostname, id)
                    val out = ssl.outputStream
                    out.write(byteArrayOf(((query.size shr 8) and 0xFF).toByte(), (query.size and 0xFF).toByte()))
                    out.write(query); out.flush()
                    val input = ssl.inputStream
                    val lenBytes = ByteArray(2)
                    var read = 0
                    while (read < 2) { val n = input.read(lenBytes, read, 2 - read); if (n < 0) return Timed(false, elapsedMs(), "DoT: پاسخ ناقص"); read += n }
                    val len = ((lenBytes[0].toInt() and 0xFF) shl 8) or (lenBytes[1].toInt() and 0xFF)
                    if (len <= 0 || len > 4096) return Timed(false, elapsedMs(), "DoT: طول پاسخ نامعتبر")
                    val resp = ByteArray(len)
                    var got = 0
                    while (got < len) { val n = input.read(resp, got, len - got); if (n < 0) break; got += n }
                    if (got < 12) return Timed(false, elapsedMs(), "DoT: پاسخ کوتاه")
                    val rid = ((resp[0].toInt() and 0xFF) shl 8) or (resp[1].toInt() and 0xFF)
                    if (rid != id) return Timed(false, elapsedMs(), "DoT: ID پاسخ مطابقت ندارد")
                    val rcode = resp[3].toInt() and 0x0F
                    if (rcode == 0) Timed(true, elapsedMs(), "DoT واقعی: TLS + DNS روی 853") else Timed(false, elapsedMs(), "DoT: خطای DNS با کد $rcode")
                }
            }
        } catch (e: SocketTimeoutException) {
            Timed(false, elapsedMs(), "DoT: timeout در اتصال یا هندشیک")
        } catch (e: SSLHandshakeException) {
            Timed(false, elapsedMs(), "DoT: خطای TLS Handshake")
        } catch (e: Exception) {
            Timed(false, elapsedMs(), "DoT: ${e.javaClass.simpleName}")
        }
    }

    fun tcpTime(host: String, port: Int): Timed {
        val s = System.currentTimeMillis()
        return try {
            // v2.9: `use` — same fix as Probes.tcpProbe: the socket is closed
            // on every path, not only after a successful connect.
            Socket().use { sock ->
                sock.connect(InetSocketAddress(host, port), 5000)
                Timed(true, System.currentTimeMillis() - s, "متصل شد")
            }
        } catch (e: Exception) { Timed(false, System.currentTimeMillis() - s, e.message ?: e.javaClass.simpleName) }
    }

    // TLS handshake with a bounded TCP connect: a plain socket is connected first
    // (5s timeout), then wrapped in TLS. All sockets are closed via `use`, even
    // when the handshake fails. TCP and TLS times are reported separately.
    fun tlsTime(host: String, port: Int = 443, timeoutMs: Int = 5000): Timed {
        val start = System.nanoTime()
        fun elapsedMs() = (System.nanoTime() - start) / 1_000_000
        return try {
            Socket().use { raw ->
                raw.connect(InetSocketAddress(host, port), timeoutMs)
                val tcpMs = elapsedMs()
                val tlsStart = System.nanoTime()
                val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
                (factory.createSocket(raw, host, port, true) as SSLSocket).use { ssl ->
                    ssl.soTimeout = timeoutMs
                    // Issue 18: same as dotQuery — verify the certificate
                    // actually belongs to `host` before the handshake.
                    val params = ssl.sslParameters
                    params.endpointIdentificationAlgorithm = "HTTPS"
                    ssl.sslParameters = params
                    ssl.startHandshake()
                }
                val tlsMs = (System.nanoTime() - tlsStart) / 1_000_000
                Timed(true, elapsedMs(), "TCP ${tcpMs}ms + TLS ${tlsMs}ms")
            }
        } catch (e: SocketTimeoutException) {
            Timed(false, elapsedMs(), "timeout در اتصال یا هندشیک")
        } catch (e: SSLHandshakeException) {
            Timed(false, elapsedMs(), "خطای TLS Handshake")
        } catch (e: java.net.ConnectException) {
            Timed(false, elapsedMs(), "اتصال TCP رد شد")
        } catch (e: java.net.SocketException) {
            val msg = e.message ?: ""
            val kind = if (msg.contains("reset", true)) "TCP Reset" else "خطای سوکت: $msg"
            Timed(false, elapsedMs(), kind)
        } catch (e: Exception) {
            Timed(false, elapsedMs(), "خطای نامشخص: ${e.javaClass.simpleName}")
        }
    }

    // QUIC/HTTP3 tri-state: Success / Failed / Unknown. A reply counts as Success
    // ONLY if it has a valid QUIC long-header structure (first bit set, version
    // field present). Any other UDP reply is Unknown, never Success.
    data class QuicResult(val state: String, val reason: String)
    fun quicStatus(host: String): QuicResult {
        val t = quicUdp(host)
        return if (t.ok) QuicResult("Success", t.note)
        else QuicResult("Unknown", t.note)
    }
    fun quicUdp(host: String): Timed {
        val s = System.currentTimeMillis()
        return try {
            // v2.9: `use` closes the DatagramSocket on EVERY path. The old
            // code closed it on the receive paths, but a getByName/send
            // failure before the inner try leaked it.
            DatagramSocket().use { sock ->
                sock.soTimeout = 1500
                val data = ByteArray(32) { 0x00 }
                sock.send(DatagramPacket(data, data.size, InetAddress.getByName(host), 443))
                val buf = ByteArray(512)
                try {
                    val pkt = DatagramPacket(buf, buf.size)
                    sock.receive(pkt)
                    val ms = System.currentTimeMillis() - s
                    if (pkt.length < 5 || (buf[0].toInt() and 0x80) == 0) {
                        Timed(false, ms, "پاسخ UDP رسید ولی ساختار QUIC معتبر نداشت — Success نیست")
                    } else {
                        val version = ((buf[1].toInt() and 0xFF) shl 24) or ((buf[2].toInt() and 0xFF) shl 16) or ((buf[3].toInt() and 0xFF) shl 8) or (buf[4].toInt() and 0xFF)
                        if (version == 0) Timed(true, ms, "پاسخ QUIC معتبر: Version Negotiation")
                        else Timed(true, ms, "پاسخ QUIC معتبر: Long Header")
                    }
                } catch (e: Exception) {
                    Timed(false, System.currentTimeMillis() - s, "نامشخص — ارسال UDP 443 انجام شد ولی بدون Handshake کامل QUIC پاسخی نمی‌رسد؛ این شکست نیست")
                }
            }
        } catch (e: Exception) { Timed(false, System.currentTimeMillis() - s, e.javaClass.simpleName) }
    }

    fun mtuTest(host: String = "1.1.1.1"): String {
        val recv = Regex("(\\d+)\\s+received")
        var smallOk = false; var bigOk = false; var unsupported = false; var anyReply = false
        for (h in listOf(host, "8.8.8.8")) {
            repeat(2) {
                val small = runCmd("ping", "-c", "1", "-W", "2", "-s", "100", "-M", "do", h, timeoutSec = 4)
                val big = runCmd("ping", "-c", "1", "-W", "2", "-s", "1400", "-M", "do", h, timeoutSec = 4)
                if (small.contains("bad option", true) || small.contains("invalid option", true) ||
                    big.contains("bad option", true) || big.contains("invalid option", true)) unsupported = true
                val sN = recv.find(small)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val bN = recv.find(big)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                if (sN > 0) { smallOk = true; anyReply = true }
                if (bN > 0) { bigOk = true; anyReply = true }
            }
        }
        return when {
            unsupported -> "قابل بررسی نیست (-M do روی این گوشی پشتیبانی نمی‌شود)"
            !anyReply -> "پینگ جواب نداد — MTU قابل بررسی نیست"
            smallOk && bigOk -> "سالم: بسته‌ی ۱۴۰۰ بایتی بدون فرگمنت عبور کرد"
            smallOk && !bigOk -> "مشکوک به MTU: بسته‌ی کوچک عبور کرد ولی ۱۴۰۰ بایتی با Don't Fragment شکست خورد — احتمال MTU کمتر از ۱۴۰۰"
            else -> "پینگ کوچک هم جواب نداد — MTU قابل بررسی نیست"
        }
    }

    fun traceroute(host: String = "8.8.8.8"): String {
        val sb = StringBuilder()
        for (ttl in 1..8) {
            val out = runCmd("ping", "-c", "1", "-W", "1", "-t", ttl.toString(), host, timeoutSec = 4)
            if (out.isBlank()) { sb.append("$ttl. * (پاسخ نداد)\n"); continue }
            if (out.contains("bad option", true) || out.contains("invalid option", true) || out.contains("unrecognized", true)) {
                return "ping -t روی این گوشی پشتیبانی نمی‌شود — traceroute در دسترس نیست"
            }
            // TTL-exceeded lines say "From <ip> ... Time to live exceeded" (capital F,
            // no time= field), so match case-insensitively and measure the hop's RTT
            // with a separate direct ping to that hop's IP.
            val from = Regex("(?i)from\\s+([0-9.]+)").find(out)?.groupValues?.get(1)
            if (from == null) {
                sb.append("$ttl. * (بدون پاسخ)\n")
            } else {
                val rtt = runCmd("ping", "-c", "1", "-W", "1", from, timeoutSec = 3)
                val time = Regex("time=([0-9.]+)").find(rtt)?.groupValues?.get(1)
                sb.append("$ttl. $from — ${time ?: "?"}ms\n")
                if (from == host) break
            }
        }
        val r = sb.toString()
        return if (r.isBlank()) "traceroute در این گوشی در دسترس نیست" else r
    }

    // DoH answer IPs for a hostname, for DNS-poisoning comparison.
    // Only type 1 (A) records are returned; CNAMEs are excluded.
    fun dohIps(dohUrl: String, host: String): List<String> {
        var conn: java.net.HttpURLConnection? = null
        return try {
            val url = "$dohUrl?name=" + URLEncoder.encode(host, "UTF-8") + "&type=A"
            conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 5000; conn.readTimeout = 5000
            conn.setRequestProperty("Accept", "application/dns-json")
            // Issue 17: readText() with no cap could read an unbounded
            // body; the JSON answer is small — 8192 chars is plenty.
            val body = BufferedReader(InputStreamReader(conn.inputStream)).use { br ->
                val sb = StringBuilder(); val cbuf = CharArray(2048); var total = 0
                while (total < 8192) {
                    val n = br.read(cbuf, 0, minOf(cbuf.size, 8192 - total))
                    if (n < 0) break
                    sb.append(cbuf, 0, n); total += n
                }
                sb.toString()
            }
            val ans = org.json.JSONObject(body).optJSONArray("Answer") ?: return emptyList()
            val out = mutableListOf<String>()
            for (i in 0 until ans.length()) {
                val o = ans.optJSONObject(i) ?: continue
                if (o.optInt("type", -1) == 1) {
                    val d = o.optString("data", "")
                    if (d.isNotBlank()) out.add(d)
                }
            }
            out
        } catch (e: Exception) { emptyList() } finally { try { conn?.disconnect() } catch (e: Exception) {} }
    }

    // Binary DoH (RFC 8484, issue 17): POST the DNS wire-format query
    // with Content-Type: application/dns-message. This is the ONLY form
    // https://dns.quad9.net/dns-query speaks — Quad9 retired its JSON
    // API on port 5053 on 5 May 2025, so a JSON GET there always fails.
    // The binary response (max 8KB) is parsed by hand: the transaction ID
    // must match, and only type-1 (A) records from the Answer section are
    // returned; CNAMEs are skipped, never returned as answers.
    fun dohBinaryIps(dohUrl: String, host: String): List<String> {
        var conn: java.net.HttpURLConnection? = null
        return try {
            val id = Random.nextInt(0, 0xFFFF)
            val query = buildDnsQuery(host, id)
            conn = java.net.URL(dohUrl).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 5000; conn.readTimeout = 5000
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/dns-message")
            conn.setRequestProperty("Accept", "application/dns-message")
            conn.outputStream.use { it.write(query); it.flush() }
            if (conn.responseCode != 200) return emptyList()
            val out = java.io.ByteArrayOutputStream()
            conn.inputStream.use { ins ->
                val buf = ByteArray(2048)
                while (out.size() < 8192) {
                    val n = ins.read(buf, 0, minOf(buf.size, 8192 - out.size()))
                    if (n < 0) break
                    out.write(buf, 0, n)
                }
            }
            parseDnsResponse(out.toByteArray(), id)
        } catch (e: Exception) { emptyList() } finally { try { conn?.disconnect() } catch (e: Exception) {} }
    }

    private fun u16(b: ByteArray, off: Int): Int = ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)

    // Skip one DNS name at `off` (labels, or a 2-byte compression
    // pointer); returns the offset just past it, or -1 if malformed.
    private fun skipDnsName(resp: ByteArray, off: Int): Int {
        var p = off
        while (true) {
            if (p >= resp.size) return -1
            val len = resp[p].toInt() and 0xFF
            if (len == 0) return p + 1
            if ((len and 0xC0) == 0xC0) return p + 2
            p += 1 + len
        }
    }

    private fun parseDnsResponse(resp: ByteArray, id: Int): List<String> {
        if (resp.size < 12) return emptyList()
        if (u16(resp, 0) != id) return emptyList()
        if ((resp[3].toInt() and 0x0F) != 0) return emptyList() // rcode != NOERROR
        val qdCount = u16(resp, 4)
        val anCount = u16(resp, 6)
        var off = 12
        repeat(qdCount) {
            off = skipDnsName(resp, off)
            if (off < 0 || off + 4 > resp.size) return emptyList()
            off += 4 // QTYPE + QCLASS
        }
        val out = mutableListOf<String>()
        repeat(anCount) {
            off = skipDnsName(resp, off)
            if (off < 0 || off + 10 > resp.size) return out
            val type = u16(resp, off)
            val rdLen = u16(resp, off + 8)
            off += 10
            if (off + rdLen > resp.size) return out
            if (type == 1 && rdLen == 4) {
                out.add((0..3).joinToString(".") { (resp[off + it].toInt() and 0xFF).toString() })
            }
            // Type 5 (CNAME) and every other type: skipped, never an answer.
            off += rdLen
        }
        return out
    }
}
