package com.aksell.netwatch

import android.content.Context
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

// NETWATCH–MUSE BRIDGE — core (Phase 1; spec v1.0 approved 2026-11-10).
//
// What this file is:
// - A module-tagged event logger (in-memory ring + persisted JSON lines).
// - A sanitizer: sensitive data is stripped BEFORE anything is stored.
// - A chained uncaught-exception handler: records a crash atomically and
//   then chains to the previous handler, so a crash still crashes.
// - Breadcrumbs: the steps leading up to an error.
// - A read-only health snapshot (on demand, off the main thread).
//
// What this file is NOT:
// - No chatbot, no AI analysis, no network upload, no new dependency.
// - No behaviour change to any existing feature: nothing here is called
//   from existing code except the crash-handler install (NetWatchApp /
//   MainActivity) and the breadcrumb mirror (History.addTimeline).
//
// Pure vs on-device:
// - sanitize(), signatureOf(), extractLocation(), inferModule(),
//   isDuplicateCrash() and the dedup/eviction rules are pure functions
//   (no Context / I/O).
// - Persistence, crash files and healthSnapshot() need a real device
//   (Context / SQLite / org.json on Android) and are NOT run on the JVM.
object Bridge {

    enum class Module { APP, MONITOR, NETWORK, GEO, ANALYTICS, HISTORY, RESTORE, GAMING, LAB, WIDGET, UI, EXPORT, SYSTEM }
    enum class Status { ERROR, WARNING, UNKNOWN, NOT_RUN }
    enum class Kind { CRASH, EXCEPTION, LAB_FAIL, HEALTH_FAIL, RESTORE_ABORT, SERVICE_DEATH, EXPORT_FAIL, WIDGET_STALE }
    enum class ModuleSource { EXPLICIT, STACK_TRACE_INFERRED, UNKNOWN }
    enum class LocationSource { STACK_TRACE, NONE }

    data class Frame(val cls: String, val method: String, val file: String?, val line: Int)
    data class Breadcrumb(val ts: Long, val kind: String, val text: String)
    // One level of a throwable's cause chain (audit fix 2).
    data class CauseInfo(val cls: String, val message: String, val frames: List<Frame>)

    data class Event(
        val eventId: String,
        val ts: Long,
        val module: Module,
        val moduleSource: ModuleSource,
        val status: Status,
        val kind: Kind,
        val message: String,
        val file: String?,
        val line: Int?,
        val function: String?,
        val locationSource: LocationSource,
        val stackTrace: List<Frame>,
        val stackSignature: String,
        val occurrences: Int,
        val firstSeen: Long,
        val lastSeen: Long,
        val breadcrumbs: List<String>,
        val context: Map<String, Any>,
        val causedBy: List<CauseInfo> = emptyList()
    )

    // Read-only health snapshot (spec §9). lastCheck carries what
    // History.LastCheck actually stores (intl/dom percentages + score),
    // not an invented ok/total count.
    data class Health(
        val serviceRunning: Boolean,
        val monitoringOn: Boolean,
        val lastHeartbeatAgeS: Long?,
        val lastCheckPingAvg: Double?,
        val lastCheckLossPct: Double?,
        val lastCheckIntlPct: Int?,
        val lastCheckDomPct: Int?,
        val lastCheckScore: Int?,
        val lastCheckTime: Long?,
        val widgetLastRefreshAgeS: Long?,
        val dbIntegrity: String, // ok | fail | not_checked
        val dbIntegrityDetail: String,
        val dbSamples: Long?,
        val dbPingPoints: Long?,
        val dbGamingSessions: Long?,
        val dbGamingSamplesLast: Long?,
        val restoreJournalState: String, // NONE | STARTED | COMMITTED | UNKNOWN
        val lastRestoreDiag: String,
        val lastGamingSession: String,
        val lastLabRun: String,
        // Phase 2: structured LAB counts (the formatted lastLabRun string
        // cannot be parsed reliably). Nullable with defaults, so existing
        // constructor calls keep compiling; filled in healthSnapshot.
        val lastLabTotal: Int? = null,
        val lastLabPassed: Int? = null,
        val lastLabFailed: Int? = null,
        val lastLabNotTested: Int? = null,
        val storageFreeMb: Long?
    )

    // ---- caps (spec §13) ----
    const val MAX_EVENTS = 200
    const val MAX_CRASH_FILES = 5
    const val MAX_BREADCRUMBS = 100
    const val MAX_MESSAGE_CHARS = 500
    const val MAX_STACK_FRAMES = 30
    const val MAX_EVENT_BYTES = 8 * 1024
    const val MAX_CRASH_BYTES = 32 * 1024
    const val MAX_BRIDGE_BYTES = 512 * 1024L
    const val CRASH_DEDUP_WINDOW_MS = 10 * 60 * 1000L
    const val MAX_EVENT_AGE_MS = 30L * 24 * 60 * 60 * 1000

    const val PKG = "com.aksell.netwatch"
    private const val DIR_NAME = "bridge"
    private const val EVENTS_NAME = "events.jsonl"
    private const val CRASHES_DIR = "crashes"

    private val lock = Any()
    // File lock (audit fix 3): serializes every read/write on the bridge
    // dir (append, atomic rewrite, cap enforcement, crash write, startup
    // load). It is NEVER held at the same time as `lock`: log() releases
    // `lock` before persisting, recordCrash snapshots breadcrumbs (a brief
    // `lock`) before entering fileLock, and loadPersistedState reads files
    // under fileLock first and only then merges into the ring under `lock`.
    // No nesting in either order means no deadlock between the two locks.
    private val fileLock = Any()
    // v2.11.2 (ایراد ۱۶): شمارنده persist برای enforceCaps دوره‌ای.
    @Volatile private var persistCount = 0
    private val ring = ArrayList<Event>()
    private val crumbs = ArrayList<Breadcrumb>()
    private val counter = AtomicLong(0)
    private val handlerInstalled = AtomicBoolean(false)
    @Volatile private var appCtx: Context? = null
    @Volatile private var previousHandler: Thread.UncaughtExceptionHandler? = null
    // Test-only storage override (JVM harness): when set, bridgeDir()
    // returns this directory without needing a Context, so the file path
    // (persist, enforceCaps, crash write, temp cleanup) is testable on
    // the JVM. Never set in production.
    @Volatile private var testDir: File? = null

    fun timeStr(t: Long): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(t))

    // ================= sanitizer (pure) =================
    // Order matters: IPs first (so a long hex token rule never sees them),
    // credentials before the generic long-hex rule.
    private val IPV4 = Regex("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b")
    // v2.11.2 (ایراد ۲۰): الگوی قبلی «::ba» را از دل «Foo::bar» می‌خورد —
    // چون بدون مرز شروع می‌شد و :: خالی هم قبول می‌کرد. حالا دو طرف
    // match باید مرز واقعی باشد (قبلش حرف/عدد/کولون نباشد و بعدش هم)، پس
    // «Foo::bar» و «x::1y» دست نمی‌خورند ولی «::1» و «2001:db8::1» و
    // «fe80::a6db:30ff:fe40:12c3» هنوز حذف می‌شوند.
    private val IPV6_COMPRESSED = Regex("(?<![0-9A-Za-z:])(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}(?![0-9A-Za-z:])")
    private val IPV6_FULL = Regex("(?<![0-9A-Za-z:])(?=[0-9a-fA-F:]*[a-fA-F])(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}(?![0-9A-Za-z:])")
    private val MAC = Regex("\\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\\b")
    private val EMAIL = Regex("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b")
    private val IR_MOBILE_INTL = Regex("\\+98\\d{10}\\b")
    private val IR_MOBILE = Regex("\\b09\\d{9}\\b")
    private val PATH_SENSITIVE = Regex("/(?:data|storage|sdcard)/[^\\s\"']*")
    private val BEARER = Regex("(?i)(bearer\\s+)[A-Za-z0-9._~-]+")
    private val CRED_ASSIGN = Regex("(?i)(token|api[_-]?key|password|passwd|secret)[=:]\\s*[^\\s,;]+")
    private val SSID_Q = Regex("(?i)(ssid\\s*[:=]\\s*\")[^\"]*(\")")
    private val SSID_BARE = Regex("(?i)(ssid\\s*[:=]\\s*)[^\\s,;]+")
    private val HEX_TOKEN = Regex("\\b[0-9a-fA-F]{32,}\\b")

    /** Strips network identifiers, credentials, paths and tokens. Pure. */
    fun sanitize(text: String): String {
        var s = text
        s = IPV4.replace(s, "<ip>")
        // MAC before IPv6: "AA:BB:CC:DD:EE:FF" is hex-colon shaped and
        // would otherwise match the IPv6 full form.
        s = MAC.replace(s, "<mac>")
        s = IPV6_COMPRESSED.replace(s, "<ip6>")
        s = IPV6_FULL.replace(s, "<ip6>")
        s = EMAIL.replace(s, "<email>")
        s = IR_MOBILE_INTL.replace(s, "<phone>")
        s = IR_MOBILE.replace(s, "<phone>")
        s = PATH_SENSITIVE.replace(s, "<path>")
        s = BEARER.replace(s, "$1<token>")
        s = CRED_ASSIGN.replace(s, "$1=<redacted>")
        s = SSID_Q.replace(s, "$1<ssid>$2")
        s = SSID_BARE.replace(s, "$1<ssid>")
        s = HEX_TOKEN.replace(s, "<token>")
        return s
    }

    // ================= pure location / signature / module =================

    /** First frame in our own package. Line only with real evidence (>= 1). */
    fun extractLocation(t: Throwable): Triple<String?, Int?, String?> {
        for (e in t.stackTrace) {
            if (e.className.startsWith(PKG)) {
                val line = if (e.lineNumber >= 1) e.lineNumber else null
                return Triple(e.fileName, line, e.methodName)
            }
        }
        return Triple(null, null, null)
    }

    /** Dedup signature: exception class + top 3 frames. Pure. */
    fun signatureOf(t: Throwable): String {
        val top = t.stackTrace.take(3).joinToString("|") { "${it.className}.${it.methodName}" }
        return t.javaClass.name + "|" + top
    }

    /** Maps a top-level class name to its owning module (spec §3). Pure. */
    fun moduleForClass(topClass: String): Module = when (topClass) {
        "MainActivity", "NetWatchApp" -> Module.APP
        "MonitorService", "MonitoringEngine" -> Module.MONITOR
        "NetworkEngine", "Probes", "Diagnostics", "Advanced" -> Module.NETWORK
        "Geo", "NetworkInfo" -> Module.GEO
        "AnalyticsEngine", "Quality" -> Module.ANALYTICS
        "History", "HistoryDb", "HistoryEngine" -> Module.HISTORY
        "RestoreStream" -> Module.RESTORE
        "Gaming", "GamingActivity" -> Module.GAMING
        "Lab", "LabActivity" -> Module.LAB
        "NetWatchWidget", "WidgetStats", "ChartData" -> Module.WIDGET
        "GaugeView", "GraphView", "SparklineView" -> Module.UI
        "ExportHelper" -> Module.EXPORT
        "NetExecutor", "Bridge" -> Module.SYSTEM
        else -> Module.SYSTEM
    }

    // History.kt hosts both HISTORY and RESTORE functions; the method name
    // decides for that file. Everything else is decided by the class.
    private fun isRestoreMethod(m: String): Boolean {
        return m.startsWith("doRestore") || m == "phaseB" || m.startsWith("rollback") ||
            m.startsWith("recover") || m.startsWith("reconcile") || m.startsWith("migrate") ||
            m.contains("Journal") || m.startsWith("restore")
    }

    /**
     * Module inference — ONLY for uncaught crashes, where no caller passed
     * a module. The result is always labelled STACK_TRACE_INFERRED (or
     * UNKNOWN), never presented as certain. Pure.
     */
    fun inferModule(t: Throwable): Pair<Module, ModuleSource> {
        for (e in t.stackTrace) {
            if (!e.className.startsWith(PKG)) continue
            val top = e.className.removePrefix("$PKG.").substringBefore('$').substringBefore('.')
            val mod = if (top == "History" && isRestoreMethod(e.methodName)) Module.RESTORE else moduleForClass(top)
            return Pair(mod, ModuleSource.STACK_TRACE_INFERRED)
        }
        return Pair(Module.SYSTEM, ModuleSource.UNKNOWN)
    }

    /** Crash dedup rule (decision 3): same signature inside 10 minutes. Pure. */
    fun isDuplicateCrash(existingTs: Long, now: Long, sameSignature: Boolean): Boolean {
        if (!sameSignature) return false
        val age = now - existingTs
        return age in 0 until CRASH_DEDUP_WINDOW_MS
    }

    /**
     * The cause chain of a throwable, up to 3 levels (audit fix 2).
     * Cycle-safe: a cause already seen (by identity — Throwable does not
     * override equals) stops the walk, so an a<->b cycle can never loop
     * forever. Messages are sanitized at every level. Pure.
     */
    fun causeChain(t: Throwable, maxDepth: Int = 3, framesPerCause: Int = 10): List<CauseInfo> {
        val out = ArrayList<CauseInfo>()
        val seen = HashSet<Throwable>()
        seen.add(t)
        var c = t.cause
        while (c != null && out.size < maxDepth) {
            if (!seen.add(c)) break
            val msg = sanitize(c.message ?: c.javaClass.simpleName).take(MAX_MESSAGE_CHARS)
            val frames = c.stackTrace.take(framesPerCause).map { Frame(it.className, it.methodName, it.fileName, it.lineNumber) }
            out.add(CauseInfo(c.javaClass.name, msg, frames))
            c = c.cause
        }
        return out
    }

    /** Last 10 breadcrumbs as formatted strings (audit fix 1). Never throws. */
    fun snapshotBreadcrumbs(): List<String> {
        return try {
            synchronized(lock) { crumbs.takeLast(10).map { "${timeStr(it.ts)} [${it.kind}] ${it.text}" } }
        } catch (_: Exception) { emptyList() }
    }

    /** Test-only: overrides the bridge storage directory (JVM harness). */
    fun setTestDirForTests(dir: File?) {
        testDir = dir
    }

    private fun framesToJson(frames: List<Frame>): JSONArray {
        val arr = JSONArray()
        for (fr in frames) {
            val fo = JSONObject()
            fo.put("class", fr.cls)
            fo.put("method", fr.method)
            if (fr.file != null) fo.put("file", fr.file) else fo.put("file", JSONObject.NULL)
            fo.put("line", fr.line)
            arr.put(fo)
        }
        return arr
    }

    // ================= event log =================

    fun events(): List<Event> = synchronized(lock) { ring.toList() }
    fun breadcrumbs(): List<Breadcrumb> = synchronized(lock) { crumbs.toList() }

    // ---- Phase 2 read APIs (additive only) ----
    // Nothing here writes, logs, or changes a cap or the handler; these
    // only expose what Phase 1 already stores, for the Bridge page.

    /** One recorded crash, parsed from its file (Phase 2 list). */
    data class CrashSummary(
        val fileName: String,
        val ts: Long,
        val module: Module,
        val moduleSource: ModuleSource,
        val exceptionClass: String,
        val message: String,
        val file: String?,
        val line: Int?,
        val function: String?,
        val stackSignature: String
    )

    fun handlerInstalled(): Boolean = handlerInstalled.get()

    /** Bytes used by the bridge dir (events + crashes), for the status card. */
    fun storageUsageBytes(): Long {
        val dir = bridgeDir(appCtx) ?: return 0L
        return try { dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } } catch (_: Exception) { 0L }
    }

    /** Counts per status over the given events (default: the ring). Pure. */
    fun summaryCounts(evts: List<Event> = events()): Map<Status, Int> {
        val m = mutableMapOf<Status, Int>()
        for (s in Status.values()) m[s] = 0
        for (e in evts) m[e.status] = (m[e.status] ?: 0) + 1
        return m
    }

    /**
     * All recorded crashes, newest first. One corrupt or truncated file
     * never blocks the others: each file is parsed in its own try/catch
     * and skipped on failure, so the page always shows what is readable.
     */
    fun listCrashes(): List<CrashSummary> {
        val dir = bridgeDir(appCtx) ?: return emptyList()
        val cd = File(dir, CRASHES_DIR)
        val files = try { cd.listFiles()?.filter { it.name.endsWith(".json") } ?: emptyList() } catch (_: Exception) { return emptyList() }
        val out = ArrayList<CrashSummary>()
        for (f in files) {
            try {
                val jo = JSONObject(f.readText())
                val mod = try { Module.valueOf(jo.optString("module", "SYSTEM")) } catch (_: Exception) { Module.SYSTEM }
                val modSrc = try { ModuleSource.valueOf(jo.optString("module_source", "UNKNOWN")) } catch (_: Exception) { ModuleSource.UNKNOWN }
                val exc = jo.optString("exception", "").takeIf { it.isNotBlank() } ?: "—"
                out.add(CrashSummary(
                    fileName = f.name,
                    ts = jo.optLong("ts", 0L),
                    module = mod,
                    moduleSource = modSrc,
                    exceptionClass = exc,
                    message = jo.optString("message", ""),
                    file = if (jo.isNull("file")) null else jo.optString("file"),
                    line = if (jo.isNull("line")) null else jo.optInt("line"),
                    function = if (jo.isNull("function")) null else jo.optString("function"),
                    stackSignature = jo.optString("stack_signature", "")
                ))
            } catch (_: Exception) { /* skip this file; the others still show */ }
        }
        return out.sortedByDescending { it.ts }
    }

    /**
     * Full text of one crash file, for the detail dialog. Null when the
     * name is not a plain file name inside the crashes dir, or unreadable.
     */
    fun crashJsonText(fileName: String): String? {
        if (fileName.contains("/") || fileName.contains("..")) return null
        val dir = bridgeDir(appCtx) ?: return null
        return try { File(File(dir, CRASHES_DIR), fileName).readText() } catch (_: Exception) { null }
    }

    /** Test-only: clears the in-memory rings and the id counter. */
    fun resetForTests() {
        synchronized(lock) {
            ring.clear()
            crumbs.clear()
            counter.set(0)
        }
    }

    private fun evictIfNeededLocked() {
        while (ring.size > MAX_EVENTS) {
            // Definite errors are evicted last: drop the oldest non-ERROR
            // first; only when the ring is all ERROR drop the oldest one.
            val idx = ring.indexOfFirst { it.status != Status.ERROR }
            if (idx >= 0) ring.removeAt(idx) else ring.removeFirst()
        }
    }

    /**
     * Records one event. The module is ALWAYS passed explicitly by the
     * caller — never guessed here. The message is sanitized before it is
     * stored. A repeat of the same signature only bumps `occurrences`.
     * ERROR events are also persisted (when an app context is known);
     * without one (JVM tests) the ring is memory-only.
     */
    fun log(
        module: Module,
        status: Status,
        kind: Kind,
        message: String,
        throwable: Throwable? = null,
        context: Map<String, Any> = emptyMap()
    ): Event {
        val now = System.currentTimeMillis()
        val cleanMsg = sanitize(message).take(MAX_MESSAGE_CHARS)
        val (file, line, fn) = if (throwable != null) extractLocation(throwable) else Triple(null, null, null)
        val frames = if (throwable != null) {
            throwable.stackTrace.take(MAX_STACK_FRAMES).map { Frame(it.className, it.methodName, it.fileName, it.lineNumber) }
        } else emptyList()
        val sig = if (throwable != null) signatureOf(throwable) else module.name + "|" + kind.name + "|" + cleanMsg
        val locSrc = if (throwable != null && file != null) LocationSource.STACK_TRACE else LocationSource.NONE
        // Fix 5: context values are sanitized before storage (and again on
        // output in eventToJson). Non-string values pass through unchanged.
        val cleanContext = context.mapValues { (_, v) -> if (v is String) sanitize(v) else v }
        val causes = if (throwable != null) causeChain(throwable) else emptyList()
        val crumbsCopy = snapshotBreadcrumbs()
        val result: Event
        synchronized(lock) {
            val idx = ring.indexOfFirst { it.stackSignature == sig && it.module == module && it.kind == kind }
            if (idx >= 0) {
                val old = ring[idx]
                val updated = old.copy(occurrences = old.occurrences + 1, lastSeen = now, message = cleanMsg)
                ring[idx] = updated
                result = updated
            } else {
                val id = "$now-${counter.incrementAndGet()}"
                val ev = Event(id, now, module, ModuleSource.EXPLICIT, status, kind, cleanMsg, file, line, fn, locSrc, frames, sig, 1, now, now, crumbsCopy, cleanContext, causes)
                ring.add(ev)
                evictIfNeededLocked()
                result = ev
            }
        }
        if (result.status == Status.ERROR && result.occurrences == 1) persistEvent(result)
        return result
    }

    /** Records one breadcrumb (a step leading up to an error). */
    fun breadcrumb(kind: String, text: String) {
        val clean = sanitize(text).take(200)
        synchronized(lock) {
            crumbs.add(Breadcrumb(System.currentTimeMillis(), kind, clean))
            while (crumbs.size > MAX_BREADCRUMBS) crumbs.removeFirst()
        }
        // Mirror into the existing timeline store (best effort, never fatal).
        try {
            appCtx?.let { History.addTimeline(it, kind, clean) }
        } catch (_: Exception) {
        }
    }

    fun init(ctx: Context) {
        if (appCtx == null) appCtx = ctx.applicationContext
    }

    // ================= persistence (on-device) =================

    private fun bridgeDir(ctx: Context?): File? {
        return try {
            val override = testDir
            if (override != null) {
                if (!override.exists()) override.mkdirs()
                if (override.isDirectory) override else null
            } else {
                val c = ctx ?: return null
                val d = File(c.filesDir, DIR_NAME)
                if (!d.exists()) d.mkdirs()
                if (d.isDirectory) d else null
            }
        } catch (_: Exception) { null }
    }

    // Phase 2: the report builder reuses the stored event JSON (one field
    // list, no drift) and maps the two enum fields to the lowercase values
    // the report Schema v1 requires. Was private; no logic changed.
    fun eventToJson(ev: Event): JSONObject {
        val o = JSONObject()
        o.put("schema_version", 1)
        o.put("event_id", ev.eventId)
        o.put("ts", ev.ts)
        o.put("module", ev.module.name)
        o.put("module_source", ev.moduleSource.name)
        o.put("status", ev.status.name)
        o.put("kind", ev.kind.name)
        o.put("message", ev.message)
        if (ev.file != null) o.put("file", ev.file) else o.put("file", JSONObject.NULL)
        if (ev.line != null) o.put("line", ev.line) else o.put("line", JSONObject.NULL)
        if (ev.function != null) o.put("function", ev.function) else o.put("function", JSONObject.NULL)
        o.put("location_source", ev.locationSource.name)
        o.put("stack_trace", framesToJson(ev.stackTrace))
        o.put("stack_signature", ev.stackSignature)
        o.put("occurrences", ev.occurrences)
        o.put("first_seen", ev.firstSeen)
        o.put("last_seen", ev.lastSeen)
        val ba = JSONArray()
        for (b in ev.breadcrumbs) ba.put(b)
        o.put("breadcrumbs", ba)
        val co = JSONObject()
        for ((k, v) in ev.context) {
            when (v) {
                // Fix 5: sanitize again on output (defense in depth; the
                // values were already sanitized at log time).
                is String -> co.put(k, sanitize(v))
                is Number -> co.put(k, v)
                is Boolean -> co.put(k, v)
                else -> co.put(k, sanitize(v.toString()))
            }
        }
        o.put("context", co)
        val ca = JSONArray()
        for (ci in ev.causedBy) {
            val cjo = JSONObject()
            cjo.put("class", ci.cls)
            cjo.put("message", ci.message)
            cjo.put("stack_trace", framesToJson(ci.frames))
            ca.put(cjo)
        }
        o.put("caused_by", ca)
        return o
    }

    private fun parseEvent(o: JSONObject): Event? {
        return try {
            val frames = ArrayList<Frame>()
            val arr = o.optJSONArray("stack_trace")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val fo = arr.optJSONObject(i) ?: continue
                    frames.add(Frame(fo.optString("class", "?"), fo.optString("method", "?"), if (fo.isNull("file")) null else fo.optString("file"), fo.optInt("line", -1)))
                }
            }
            val ctxMap = HashMap<String, Any>()
            val co = o.optJSONObject("context")
            if (co != null) {
                val keys = co.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = co.opt(k)
                    if (v is String || v is Number || v is Boolean) ctxMap[k] = v
                }
            }
            val crumbsList = ArrayList<String>()
            val ba = o.optJSONArray("breadcrumbs")
            if (ba != null) for (i in 0 until ba.length()) crumbsList.add(ba.optString(i, ""))
            val causesList = ArrayList<CauseInfo>()
            val ca = o.optJSONArray("caused_by")
            if (ca != null) {
                for (i in 0 until ca.length()) {
                    val cjo = ca.optJSONObject(i) ?: continue
                    val cframes = ArrayList<Frame>()
                    val fa = cjo.optJSONArray("stack_trace")
                    if (fa != null) {
                        for (j in 0 until fa.length()) {
                            val fo = fa.optJSONObject(j) ?: continue
                            cframes.add(Frame(fo.optString("class", "?"), fo.optString("method", "?"), if (fo.isNull("file")) null else fo.optString("file"), fo.optInt("line", -1)))
                        }
                    }
                    causesList.add(CauseInfo(cjo.optString("class", "?"), cjo.optString("message", ""), cframes))
                }
            }
            Event(
                eventId = o.optString("event_id", "${o.optLong("ts", 0)}-x"),
                ts = o.optLong("ts", 0),
                module = Module.valueOf(o.optString("module", "SYSTEM")),
                moduleSource = ModuleSource.valueOf(o.optString("module_source", "UNKNOWN")),
                status = Status.valueOf(o.optString("status", "UNKNOWN")),
                kind = Kind.valueOf(o.optString("kind", "EXCEPTION")),
                message = o.optString("message", ""),
                file = if (o.isNull("file")) null else o.optString("file"),
                line = if (o.isNull("line")) null else o.optInt("line"),
                function = if (o.isNull("function")) null else o.optString("function"),
                locationSource = LocationSource.valueOf(o.optString("location_source", "NONE")),
                stackTrace = frames,
                stackSignature = o.optString("stack_signature", ""),
                occurrences = o.optInt("occurrences", 1),
                firstSeen = o.optLong("first_seen", o.optLong("ts", 0)),
                lastSeen = o.optLong("last_seen", o.optLong("ts", 0)),
                breadcrumbs = crumbsList,
                context = ctxMap,
                causedBy = causesList
            )
        } catch (_: Exception) { null }
    }

    private fun persistEvent(ev: Event) {
        // Fix 3: the whole append + cap enforcement runs under fileLock,
        // so a concurrent ERROR log can never interleave with the
        // read-modify-write of enforceCaps and lose an event.
        synchronized(fileLock) {
            try {
                val dir = bridgeDir(appCtx) ?: return
                val line = eventToJson(ev).toString()
                if (line.toByteArray(Charsets.UTF_8).size > MAX_EVENT_BYTES) return
                File(dir, EVENTS_NAME).appendText(line + "\n")
                // v2.11.2 (ایراد ۱۶): enforceCaps دیگر برای هر رویداد کل
                // فایل را نمی‌خواند/بازنویسی نمی‌کند — فقط هر ۲۰ persist
                // یک‌بار، یا وقتی فایل رویدادها از 512KB گذشت.
                persistCount++
                val eventsFile = File(dir, EVENTS_NAME)
                if (persistCount % 20 == 0 || eventsFile.length() > 512L * 1024) enforceCaps(dir)
            } catch (_: Exception) { }
        }
    }

    // Enforces every cap from spec §13. Oldest first: crash files, then
    // event lines. Caller must hold fileLock (persistEvent, recordCrash).
    // Never throws.
    private fun enforceCaps(dir: File) {
        try {
            val cd = File(dir, CRASHES_DIR)
            val crashes = cd.listFiles()?.filter { it.name.endsWith(".json") }?.sortedBy { it.lastModified() } ?: emptyList()
            if (crashes.size > MAX_CRASH_FILES) {
                for (f in crashes.take(crashes.size - MAX_CRASH_FILES)) {
                    try { f.delete() } catch (_: Exception) { }
                }
            }
            val ef = File(dir, EVENTS_NAME)
            if (ef.exists()) {
                val cutoff = System.currentTimeMillis() - MAX_EVENT_AGE_MS
                val kept = ef.readLines().mapNotNull { line ->
                    try {
                        val o = JSONObject(line)
                        if (o.optLong("ts", 0) >= cutoff) line else null
                    } catch (_: Exception) { null }
                }.takeLast(MAX_EVENTS)
                val tmp = File(dir, EVENTS_NAME + ".tmp")
                tmp.writeText(kept.joinToString("\n") + if (kept.isEmpty()) "" else "\n")
                if (!tmp.renameTo(ef)) {
                    try { ef.delete() } catch (_: Exception) { }
                    tmp.renameTo(ef)
                }
            }
            var total = 0L
            try {
                total = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            } catch (_: Exception) { }
            if (total > MAX_BRIDGE_BYTES) {
                val remaining = cd.listFiles()?.filter { it.name.endsWith(".json") }?.sortedBy { it.lastModified() } ?: emptyList()
                for (f in remaining) {
                    if (total <= MAX_BRIDGE_BYTES) break
                    val sz = f.length()
                    if (f.delete()) total -= sz
                }
            }
            if (total > MAX_BRIDGE_BYTES && ef.exists()) {
                val kept = ef.readLines().takeLast(50)
                ef.writeText(kept.joinToString("\n") + if (kept.isEmpty()) "" else "\n")
            }
        } catch (_: Exception) { }
    }

    /** Deletes stale *.tmp files left by a killed process (fix 4). Only
     *  inside the Bridge dir and its crashes subdir; only ".tmp" names —
     *  a valid .json/.jsonl file can never match. Safe to run at startup:
     *  a .tmp is only ever an in-progress write from a dead process. */
    private fun cleanTempFiles(dir: File) {
        try {
            val targets = ArrayList<File>()
            dir.listFiles()?.forEach { f -> if (f.isFile && f.name.endsWith(".tmp")) targets.add(f) }
            val cd = File(dir, CRASHES_DIR)
            cd.listFiles()?.forEach { f -> if (f.isFile && f.name.endsWith(".tmp")) targets.add(f) }
            for (f in targets) {
                try { f.delete() } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    /** Loads persisted events and crashes into the ring (startup). */
    fun loadPersistedState(ctx: Context) {
        init(ctx)
        // File reads happen under fileLock; the ring merge happens after,
        // under `lock` — the two locks are never held at the same time.
        val loaded = ArrayList<Event>()
        synchronized(fileLock) {
            try {
                val dir = bridgeDir(ctx) ?: return
                cleanTempFiles(dir)
                val f = File(dir, EVENTS_NAME)
                if (f.exists()) {
                    for (line in f.readLines().takeLast(MAX_EVENTS)) {
                        try { parseEvent(JSONObject(line))?.let { loaded.add(it) } } catch (_: Exception) { }
                    }
                }
                val cd = File(dir, CRASHES_DIR)
                val files = cd.listFiles()?.filter { it.name.endsWith(".json") }?.sortedBy { it.lastModified() } ?: emptyList()
                for (cf in files) {
                    try { parseEvent(JSONObject(cf.readText()))?.let { loaded.add(it) } } catch (_: Exception) { }
                }
            } catch (_: Exception) { }
        }
        for (ev in loaded) addPersisted(ev)
    }

    private fun addPersisted(ev: Event) {
        synchronized(lock) {
            if (ring.none { it.stackSignature == ev.stackSignature && it.module == ev.module && it.kind == ev.kind }) {
                ring.add(ev)
            }
            evictIfNeededLocked()
        }
    }

    // ================= crash handler =================

    /**
     * Installs the Bridge crash handler (idempotent). The previous handler
     * is saved and always chained afterwards, so a crash still crashes.
     * Call once from Application.onCreate; re-asserting from MainActivity
     * is a harmless no-op.
     */
    fun installCrashHandler(ctx: Context) {
        init(ctx)
        if (!handlerInstalled.compareAndSet(false, true)) return
        previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try { recordCrash(thread, throwable) } catch (_: Exception) { }
            try {
                val prev = previousHandler
                if (prev != null) {
                    prev.uncaughtException(thread, throwable)
                } else {
                    android.os.Process.killProcess(android.os.Process.myPid())
                    kotlin.system.exitProcess(10)
                }
            } catch (_: Exception) {
                try { android.os.Process.killProcess(android.os.Process.myPid()) } catch (_: Exception) { }
            }
        }
    }

    // Phase 2: the exception class is stored explicitly so the crash list
    // can show it (the message alone does not always carry the class name).
    // Additive only: one new field, old crash files simply lack it.
    private fun crashJson(now: Long, threadName: String, mod: Module, modSrc: ModuleSource, msg: String, exceptionClass: String, file: String?, line: Int?, fn: String?, sig: String, frames: List<Frame>, causes: List<CauseInfo>, crumbs: List<String>): JSONObject {
        val o = JSONObject()
        o.put("schema_version", 1)
        o.put("ts", now)
        o.put("thread", threadName)
        o.put("module", mod.name)
        o.put("module_source", modSrc.name)
        o.put("status", "ERROR")
        o.put("kind", "CRASH")
        o.put("message", msg)
        o.put("exception", exceptionClass)
        if (file != null) o.put("file", file) else o.put("file", JSONObject.NULL)
        if (line != null) o.put("line", line) else o.put("line", JSONObject.NULL)
        if (fn != null) o.put("function", fn) else o.put("function", JSONObject.NULL)
        o.put("location_source", if (file != null) "STACK_TRACE" else "NONE")
        o.put("stack_signature", sig)
        o.put("stack_trace", framesToJson(frames))
        // Fix 1: the steps leading up to the crash.
        val ba = JSONArray()
        for (b in crumbs) ba.put(b)
        o.put("breadcrumbs", ba)
        // Fix 2: the cause chain (max 3 levels, cycle-safe, sanitized).
        val ca = JSONArray()
        for (ci in causes) {
            val cjo = JSONObject()
            cjo.put("class", ci.cls)
            cjo.put("message", ci.message)
            cjo.put("stack_trace", framesToJson(ci.frames))
            ca.put(cjo)
        }
        o.put("caused_by", ca)
        return o
    }

    /**
     * Records one crash atomically (temp file + rename) and without
     * duplicates (same signature inside 10 minutes writes no new file).
     * Every step is guarded: a failure here must never stop the crash
     * from being chained to the previous handler. Sensitive data is
     * sanitized BEFORE the file is written.
     */
    private fun recordCrash(thread: Thread, t: Throwable) {
        try {
            val now = System.currentTimeMillis()
            val sig = signatureOf(t)
            val (file, line, fn) = extractLocation(t)
            val (mod, modSrc) = inferModule(t)
            val frames = t.stackTrace.take(MAX_STACK_FRAMES).map { Frame(it.className, it.methodName, it.fileName, it.lineNumber) }
            val msg = sanitize(t.message ?: t.javaClass.simpleName).take(MAX_MESSAGE_CHARS)
            // Fix 1: snapshot the breadcrumbs BEFORE touching the files.
            // snapshotBreadcrumbs() never throws; if it somehow returned
            // nothing, the crash is still recorded — only the context is lost.
            val crumbsCopy = snapshotBreadcrumbs()
            // Fix 2: cause chain, max 3 levels, cycle-safe, sanitized.
            val causes = causeChain(t)
            val baseDir = bridgeDir(appCtx) ?: return
            val dir = File(baseDir, CRASHES_DIR).apply { if (!exists()) mkdirs() }
            // Fix 3: the whole file section (dedup read, write, caps)
            // runs under fileLock. The memory lock was already released
            // by snapshotBreadcrumbs(); the two locks never nest.
            synchronized(fileLock) {
                // Dedup first: the same crash inside 10 minutes is not new.
                val existing = dir.listFiles()?.filter { it.name.endsWith(".json") } ?: emptyList()
                for (f in existing) {
                    try {
                        val eo = JSONObject(f.readText())
                        if (eo.optString("stack_signature") == sig && isDuplicateCrash(eo.optLong("ts", 0), now, true)) return
                    } catch (_: Exception) { }
                }
                var text = crashJson(now, thread.name, mod, modSrc, msg, t.javaClass.simpleName, file, line, fn, sig, frames, causes, crumbsCopy).toString()
                if (text.toByteArray(Charsets.UTF_8).size > MAX_CRASH_BYTES) {
                    text = crashJson(now, thread.name, mod, modSrc, msg, t.javaClass.simpleName, file, line, fn, sig, frames.take(10), causes.map { it.copy(frames = emptyList()) }, crumbsCopy).toString()
                }
                if (text.toByteArray(Charsets.UTF_8).size > MAX_CRASH_BYTES) {
                    text = crashJson(now, thread.name, mod, modSrc, msg, t.javaClass.simpleName, file, line, fn, sig, emptyList(), emptyList(), emptyList()).toString()
                }
                val tmp = File(dir, "crash-$now.tmp")
                val dst = File(dir, "crash-$now-${Integer.toHexString(sig.hashCode())}.json")
                tmp.writeText(text)
                if (!tmp.renameTo(dst)) {
                    try { tmp.delete() } catch (_: Exception) { }
                    dst.writeText(text)
                }
                enforceCaps(baseDir)
            }
        } catch (_: Exception) { }
    }

    // ================= health snapshot (on-device, on demand) =================

    private fun countOf(db: android.database.sqlite.SQLiteDatabase, sql: String): Long? {
        return try {
            db.rawQuery(sql, null).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
        } catch (_: Exception) { null }
    }

    /**
     * Read-only snapshot of component health. Must be called OFF the main
     * thread: the DB section is skipped on the main thread (integrity
     * stays "not_checked") instead of risking a UI stall. A failure to
     * read one part never fails the whole snapshot — that part reports
     * null / "not_checked" / "UNKNOWN".
     */
    // Pure decision for the last gaming session's display text, used by
    // healthSnapshot: a session row with no
    // samples, or an unfinished session still holding the defaults
    // (received 0, avg 0, loss 0), carries no real measurement -> "no_data".
    // A finished all-drops session has loss 100, so it still shows.
    // "none" means no session row exists at all.
    fun gamingSessionText(session: History.GamingSession?, samplesLast: Long?): String {
        if (session == null) return "none"
        // samplesLast is Long? because the count query can fail (null) —
        // null means "unknown", not zero, so it does NOT force no_data
        // (same as the old inline `gamingSamplesLast == 0L` check).
        return if (samplesLast == 0L || (session.received == 0 && session.avgMs == 0.0 && session.loss == 0.0)) "no_data"
        else "${session.profile} • ${session.region} • avg ${"%.0f".format(session.avgMs)}ms • loss ${"%.1f".format(session.loss)}% • score ${session.score ?: "—"}"
    }

    fun healthSnapshot(ctx: Context, serviceRunning: Boolean): Health {
        val now = System.currentTimeMillis()
        val hb = try { HistoryEngine.lastHeartbeat(ctx) } catch (_: Exception) { 0L }
        val hbAge = if (hb > 0) (now - hb) / 1000 else null
        val lc = try { HistoryEngine.lastCheck(ctx) } catch (_: Exception) { null }
        val wAge = try {
            val u = WidgetStats.snapshot(ctx).updatedAtMs
            if (u > 0) (now - u) / 1000 else null
        } catch (_: Exception) { null }
        var integrity = "not_checked"
        var integrityDetail = ""
        var samples: Long? = null
        var pingPoints: Long? = null
        var gamingSessions: Long? = null
        var gamingSamplesLast: Long? = null
        var lastSessionText = "none"
        if (Looper.getMainLooper().thread != Thread.currentThread()) {
            try {
                val db = HistoryDb.getReadDb(ctx)
                db.rawQuery("PRAGMA integrity_check", null).use { c ->
                    if (c.moveToFirst()) {
                        val v = c.getString(0) ?: ""
                        if (v == "ok") {
                            integrity = "ok"
                        } else {
                            integrity = "fail"
                            integrityDetail = sanitize(v).take(200)
                        }
                    } else {
                        integrity = "fail"
                        integrityDetail = "empty result"
                    }
                }
                samples = countOf(db, "SELECT COUNT(*) FROM samples")
                pingPoints = countOf(db, "SELECT COUNT(*) FROM ping_points")
                gamingSessions = countOf(db, "SELECT COUNT(*) FROM gaming_sessions")
                val lastSession = try { HistoryEngine.gamingSessions(ctx).maxByOrNull { it.started } } catch (_: Exception) { null }
                if (lastSession != null) {
                    gamingSamplesLast = countOf(db, "SELECT COUNT(*) FROM gaming_samples WHERE session_id=${lastSession.id}")
                    // ChatGPT review round 2, item 5: the no_data decision
                    // lives in the pure gamingSessionText() (JVM-tested) —
                    // healthSnapshot calls that exact function, so the JVM
                    // tests cover the snapshot's own decision. The DB/Context
                    // plumbing around it (reading the session row + counting
                    // its samples) still needs the device.
                    lastSessionText = gamingSessionText(lastSession, gamingSamplesLast)
                }
            } catch (e: Exception) {
                if (integrity == "not_checked") integrityDetail = e.javaClass.simpleName
            }
        }
        val journal = try { History.restoreJournalState(ctx) } catch (_: Exception) { "UNKNOWN" }
        val diag = try { sanitize(History.lastRestoreDiag).take(200) } catch (_: Exception) { "" }
        // Phase 2: the same counts, structured, for the health-row mapping
        // and the report (the formatted string cannot be parsed reliably).
        var labTotal: Int? = null
        var labPassed: Int? = null
        var labFailed: Int? = null
        var labNotTested: Int? = null
        val lastLab = try {
            val run = Lab.loadRuns(ctx).maxByOrNull { it.timestamp }
            if (run == null) {
                "none"
            } else {
                val passed = run.results.count { it.pass == true }
                val failed = run.results.count { it.pass == false }
                val notTested = run.results.count { it.pass == null }
                labTotal = run.results.size
                labPassed = passed
                labFailed = failed
                labNotTested = notTested
                val failing = run.results.filter { it.pass == false }.take(5).joinToString(", ") { it.name }
                "v${run.version} • ${run.section} • ${run.results.size} tests • $passed pass • $failed fail • $notTested not tested" +
                    if (failing.isNotEmpty()) " • failing: $failing" else ""
            }
        } catch (_: Exception) { "unreadable" }
        val freeMb = try { ctx.filesDir.freeSpace / 1024 / 1024 } catch (_: Exception) { null }
        return Health(
            serviceRunning = serviceRunning,
            monitoringOn = serviceRunning,
            lastHeartbeatAgeS = hbAge,
            lastCheckPingAvg = lc?.pingAvg,
            lastCheckLossPct = lc?.lossPct,
            lastCheckIntlPct = lc?.intlPct,
            lastCheckDomPct = lc?.domPct,
            lastCheckScore = lc?.scoreTotal,
            lastCheckTime = lc?.checkedAt?.takeIf { it > 0 },
            widgetLastRefreshAgeS = wAge,
            dbIntegrity = integrity,
            dbIntegrityDetail = integrityDetail,
            dbSamples = samples,
            dbPingPoints = pingPoints,
            dbGamingSessions = gamingSessions,
            dbGamingSamplesLast = gamingSamplesLast,
            restoreJournalState = journal,
            lastRestoreDiag = diag,
            lastGamingSession = lastSessionText,
            lastLabRun = lastLab,
            lastLabTotal = labTotal,
            lastLabPassed = labPassed,
            lastLabFailed = labFailed,
            lastLabNotTested = labNotTested,
            storageFreeMb = freeMb
        )
    }
}
