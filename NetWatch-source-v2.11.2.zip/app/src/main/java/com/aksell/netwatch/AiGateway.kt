package com.aksell.netwatch

import android.content.Context

// AI Gateway (architecture §3) — the independent bridge between AiCore
// and the providers. It owns: the provider registry, the active-provider
// choice and Retry / Backoff. It never analyses and never builds a
// packet — that is AiCore's job.
//
// Policy numbers (architecture §3-2):
// - HTTP: 10s connect / 30s read, max 3 attempts (1 + 2), backoff 2s
//   then 5s. Retry only on IO/timeout/429/5xx — never on 400/401/403
//   (those need the user: wrong key, Gemini 403).
// - One provider is real today (Share, user-paced): there is no daily
//   cap, no total timeout, no async send and no cancellation to own —
//   the dead code for those was removed (issue 24). The service owns
//   the single running round (MonitorService.aiBusy / aiFuture).
object AiGateway {

    const val CONNECT_TIMEOUT_MS = 10_000
    const val READ_TIMEOUT_MS = 30_000
    const val MAX_ATTEMPTS = 3

    // Backoff per retry: after attempt 1 wait 2s, after attempt 2 wait 5s;
    // attempt 3 is the last one (0 = no more retries). Pure.
    fun backoffMs(attempt: Int): Long = when (attempt) {
        1 -> 2000L
        2 -> 5000L
        else -> 0L
    }

    /** Retryable error codes only. 400/401/403/parse/provider problems
     *  need the user, not another attempt. Pure. */
    fun shouldRetry(code: String): Boolean {
        return code == "timeout" || code == "http_429" || code == "network" ||
            code == "io" || code.startsWith("http_5")
    }

    /** Provider availability today. Pure — the caller passes the real
     *  state (Drive connected? key entered?). Phase 2: only Share is
     *  available; Drive needs Phase 3, OpenRouter Phase 4, Gemini is
     *  403-blocked (Phase 5). */
    fun availability(id: String, driveConnected: Boolean, openRouterKeySet: Boolean): Pair<Boolean, String?> {
        return when (id) {
            AiCore.PROVIDER_SHARE -> true to null
            AiCore.PROVIDER_DRIVE -> if (driveConnected) true to null
                else false to "Drive وصل نیست — فاز ۳ (صندوق Drive) هنوز ساخته نشده است"
            AiCore.PROVIDER_OPENROUTER -> if (openRouterKeySet) true to null
                else false to "کلید OpenRouter در اپ وارد نشده — فاز ۴"
            AiCore.PROVIDER_GEMINI -> false to "Gemini فعلاً 403 است («سهمیه رایگان برای این پروژه در دسترس نیست») — فاز ۵ (مسدود)"
            else -> false to "ارائه‌دهنده ناشناخته: $id"
        }
    }

    fun providers(): List<AiProvider> = listOf(ShareProvider)

    fun providerById(id: String): AiProvider? = providers().firstOrNull { it.id == id }

    /** Blocking send with the retry loop. Runs on the caller's thread —
     *  the service calls it from a NetExecutor task. Returns the first
     *  Answered/Pending, or the last Failed after the retries. */
    fun sendSync(ctx: Context?, providerId: String, request: AiCore.AiRequest): AiResult {
        val provider = providerById(providerId)
            ?: return AiResult.Failed(AiError("provider_disabled", "ارائه‌دهنده ناشناخته: $providerId", 0, false))
        val (ok, reason) = availability(providerId, driveConnected = false, openRouterKeySet = false)
        if (!ok || !provider.isAvailable) {
            return AiResult.Failed(AiError("provider_disabled", reason ?: "ارائه‌دهنده در دسترس نیست", 0, false))
        }
        var attempt = 0
        var lastError: AiError? = null
        while (attempt < MAX_ATTEMPTS) {
            attempt++
            val result = try {
                if (ctx != null && provider is ContextAwareProvider) provider.sendWithContext(ctx, request)
                else provider.send(request)
            } catch (e: InterruptedException) {
                // Cancel means stop, not a network error: no retry, no sleep.
                Thread.currentThread().interrupt()
                return AiResult.Failed(AiError("network", "ارسال لغو شد", attempt, false))
            } catch (e: Exception) {
                AiResult.Failed(AiError("network", "خطای داخلی دروازه: ${e.javaClass.simpleName}", attempt, true))
            }
            when (result) {
                is AiResult.Answered -> return result
                is AiResult.Pending -> return result
                is AiResult.Failed -> {
                    lastError = result.error
                    if (!shouldRetry(result.error.code) || attempt >= MAX_ATTEMPTS) {
                        return AiResult.Failed(result.error.copy(attempts = attempt))
                    }
                    val wait = backoffMs(attempt)
                    if (wait > 0) {
                        try { Thread.sleep(wait) } catch (_: InterruptedException) {
                            // Cancel means stop, not a network error: return
                            // at once, non-retryable, without sleeping.
                            Thread.currentThread().interrupt()
                            return AiResult.Failed(result.error.copy(attempts = attempt, retryable = false))
                        }
                    }
                }
            }
        }
        return AiResult.Failed(lastError?.copy(attempts = attempt)
            ?: AiError("network", "بدون پاسخ", attempt, false))
    }
}
