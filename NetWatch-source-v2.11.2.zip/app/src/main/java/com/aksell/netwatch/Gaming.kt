package com.aksell.netwatch

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import java.util.concurrent.TimeUnit

data class GameProfile(val id: String, val name: String, val pkg: String)
data class Region(val id: String, val name: String, val hosts: List<String>)
data class PingResult(
    val host: String, val sent: Int, val received: Int, val lossPct: Double,
    val minMs: Double, val avgMs: Double, val maxMs: Double,
    val p50: Double, val p90: Double, val p95: Double, val p99: Double,
    val jitterMs: Double, val spikes: Int, val burstLoss: Int, val times: List<Double>
)

object Gaming {
    val profiles = listOf(
        GameProfile("codm", "Call of Duty Mobile", "com.activision.callofduty.shooter"),
        GameProfile("pubg", "PUBG Mobile", "com.tencent.ig"),
        GameProfile("warzone", "Call of Duty Warzone Mobile", "com.activision.callofduty.warzone"),
        GameProfile("custom", "بازی دیگر (مقصد اختصاصی)", "")
    )
    // IMPORTANT: these are public benchmark endpoints (anycast DNS/CDN), NOT real COD servers.
    // Activision does not publish CODM server IPs; inventing one would be fake. In-game ping is recorded separately.
    val regions = listOf(
        Region("me", "Middle East", listOf("1.1.1.1", "8.8.8.8", "9.9.9.9")),
        Region("eu", "Europe", listOf("8.8.8.8", "1.0.0.1", "9.9.9.9", "8.8.4.4")),
        Region("asia", "Asia", listOf("1.1.1.1", "8.8.4.4", "9.9.9.9")),
        Region("na", "North America", listOf("8.8.8.8", "1.1.1.1", "9.9.9.9"))
    )

    // Percentile method (unified everywhere): nearest-rank, rank = ceil(p/100 * n), 1-indexed.
    // e.g. [42,48,50,55,72] n=5: P50 = 3rd = 50, P90 = 5th = 72. Samples < 10 have low statistical validity (shown in UI).
    fun percentile(sorted: List<Double>, p: Double): Double {
        if (sorted.isEmpty()) return 0.0
        val rank = kotlin.math.ceil(p / 100.0 * sorted.size).toInt().coerceIn(1, sorted.size)
        return sorted[rank - 1]
    }

    // Bounded ping via Diagnostics.pingLines: the process is killed after
    // count*2+5s, so a hung ping can never hang this thread (the old code used
    // waitFor() with NO timeout). If the ping binary is missing, the result is
    // honestly empty (100% loss) — never faked with a re-measured sample.
    fun pingHost(host: String, count: Int = 20): PingResult {
        return try {
            val run = Diagnostics.pingLines(host, count)
            if (run.binaryMissing) {
                return PingResult(host, count, 0, 100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0, emptyList())
            }
            val times = run.times
            // Issue 10: burst is counted from icmp_seq gaps (the old code
            // counted lines containing "timeout", which toybox ping never
            // prints for a lost packet — burst was always 0). The seq base
            // is not assumed; see Diagnostics.seqBurst.
            val burst = Diagnostics.seqBurst(run.raw, count, run.completed)
            // Received = distinct icmp_seq values seen (a duplicate reply
            // must not count twice); falls back to the reply count when
            // ping printed no seq numbers at all.
            val seqCount = Diagnostics.parseIcmpSeqs(run.raw).toSet().size
            val received = if (seqCount > 0) seqCount else times.size
            val sorted = times.sorted()
            val avg = if (times.isEmpty()) 0.0 else times.average()
            // Jitter definition: FIRST the mdev of ping's own rtt summary
            // line (the same definition as Diagnostics.pingStats); only if
            // ping printed no rtt line, the mean absolute successive
            // difference of the reply times. That fallback is NOT RFC 3550
            // interarrival jitter; it is labelled as such in the UI.
            val jitter = Diagnostics.mdevJitter(run.raw)
                ?: if (times.size > 1) (1 until times.size).map { abs(times[it] - times[it - 1]) }.average() else 0.0
            val spikes = times.count { it > 150 || (avg > 0 && it > avg * 2) }
            PingResult(host, count, received, if (count == 0) 0.0 else (count - received) * 100.0 / count,
                sorted.firstOrNull() ?: 0.0, avg, sorted.lastOrNull() ?: 0.0,
                percentile(sorted, 50.0), percentile(sorted, 90.0), percentile(sorted, 95.0), percentile(sorted, 99.0),
                jitter, spikes, burst, times)
        } catch (e: Exception) {
            PingResult(host, count, 0, 100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0, emptyList())
        }
    }

    // TCP fallback when ICMP is blocked
    fun tcpPing(host: String, port: Int = 443, count: Int = 10): PingResult {
        val times = mutableListOf<Double>()
        repeat(count) {
            val t = Diagnostics.tcpTime(host, port)
            if (t.ok) times.add(t.ms.toDouble())
            try { Thread.sleep(200) } catch (e: Exception) {}
        }
        val sorted = times.sorted()
        val avg = if (times.isEmpty()) 0.0 else times.average()
        var jitter = 0.0
        if (times.size > 1) jitter = (1 until times.size).map { abs(times[it] - times[it - 1]) }.average()
        return PingResult("$host:$port (TCP)", count, times.size, (count - times.size) * 100.0 / count,
            sorted.firstOrNull() ?: 0.0, avg, sorted.lastOrNull() ?: 0.0,
            percentile(sorted, 50.0), percentile(sorted, 90.0), percentile(sorted, 95.0), percentile(sorted, 99.0), jitter, times.count { it > 150 }, 0, times)
    }

    data class Bufferbloat(
        val idleMs: Double,
        val loadedMs: Double,
        val increaseMs: Double,
        val grade: String,
        val score: Int?,                  // null = measurement not valid
        val loadApplied: Boolean = false, // did the download really load the link
        val throughputMbps: Double = 0.0,
        val valid: Boolean = false,
        val note: String = ""
    )
    // Bufferbloat: the download keeps running until the loaded ping finishes, so
    // the "loaded" samples are really measured under load. Throughput during the
    // ping window is recorded; if the load was too small the result is flagged
    // as not valid instead of graded. Median (p50) is used so one outlier sample
    // cannot skew the result. Takes ~20-40s; call only on a background thread.
    // NOTE: the download can use tens of MB of mobile data (capped at 50 MB).
    fun bufferbloat(
        target: String = "1.1.1.1",
        idleCount: Int = 10,
        loadedCount: Int = 10,
        minLoadMbps: Double = 1.0,
        shouldStop: (() -> Boolean)? = null
    ): Bufferbloat {
        val idle = pingHost(target, idleCount)
        if (shouldStop?.invoke() == true) {
            return Bufferbloat(0.0, 0.0, 0.0, "-", null, note = "تست Bufferbloat توسط کاربر متوقف شد")
        }
        if (idle.received < idleCount / 2) {
            return Bufferbloat(0.0, 0.0, 0.0, "-", null, note = "پینگ بی‌بار ناکافی است (${idle.received}/$idleCount)")
        }
        val bytes = java.util.concurrent.atomic.AtomicLong(0)
        val connRef = java.util.concurrent.atomic.AtomicReference<HttpURLConnection?>(null)
        val pingDone = java.util.concurrent.atomic.AtomicBoolean(false)
        val capHit = java.util.concurrent.atomic.AtomicBoolean(false)
        // The download runs on the shared managed executor (not a raw Thread):
        // it is cancellable and never leaks a thread when the test is stopped.
        // Issue 11: the download re-GETs in a loop until the loaded ping
        // finishes. One connection ends early on fast links (50 MB drains
        // before the ~10 s ping window ends) and the rest of the window
        // would be measured unloaded. The total stays capped at 50 MB; if
        // the cap is hit while the ping window is still running, the load
        // did NOT cover the window (loadApplied=false, see below).
        val dlFuture = NetExecutor.submit {
            while (!pingDone.get() && shouldStop?.invoke() != true) {
                if (bytes.get() >= 50_000_000L) { if (!pingDone.get()) capHit.set(true); break }
                try {
                    val conn = URL("https://speed.cloudflare.com/__down?bytes=200000000").openConnection() as HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    connRef.set(conn)
                    conn.inputStream.use { ins ->
                        val buf = ByteArray(16 * 1024)
                        while (!pingDone.get() && shouldStop?.invoke() != true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            bytes.addAndGet(n.toLong())
                            if (bytes.get() >= 50_000_000L) { if (!pingDone.get()) capHit.set(true); break } // data cap: 50 MB
                        }
                    }
                } catch (_: Exception) {
                    // Deliberate disconnect or network error; bytes read so
                    // far stay valid. Brief pause before re-GETting so a
                    // persistently failing link cannot hot-loop.
                    try { Thread.sleep(300) } catch (_: Exception) {}
                }
            }
        }
        Thread.sleep(1000) // let the queue fill before pinging under load
        val bytesBefore = bytes.get()
        val windowStart = System.nanoTime()
        val loaded = pingHost(target, loadedCount)
        pingDone.set(true)
        val windowSec = (System.nanoTime() - windowStart) / 1e9
        val bytesAfter = bytes.get()
        connRef.get()?.disconnect()   // stop the download once the ping is done
        try { dlFuture.get(3, TimeUnit.SECONDS) } catch (_: Exception) { NetExecutor.cancel(dlFuture) }
        val throughputMbps = if (windowSec > 0) (bytesAfter - bytesBefore) * 8.0 / 1e6 / windowSec else 0.0
        val loadApplied = throughputMbps >= minLoadMbps
        val validLoaded = loaded.received >= loadedCount / 2
        if (!validLoaded) {
            return Bufferbloat(idle.p50, 0.0, 0.0, "-", null, loadApplied, throughputMbps, false,
                "پینگ زیر بار ناکافی است (${loaded.received}/$loadedCount)")
        }
        val idleMs = idle.p50
        val loadedMs = loaded.p50
        val inc = loadedMs - idleMs
        // Issue 11: the 50 MB cap ran out before the ping window ended,
        // so the link was unloaded for the tail of the window — the
        // result is not valid even if the measured throughput looked high.
        if (capHit.get()) {
            return Bufferbloat(idleMs, loadedMs, inc, "?", null, false, throughputMbps, false,
                "سقف داده تمام شد (50MB) قبل از پایان پنجره پینگ؛ بار کامل اعمال نشد")
        }
        val (grade, score) = when {
            inc < 20 -> "A" to 100
            inc < 50 -> "B" to 80
            inc < 100 -> "C" to 60
            inc < 200 -> "D" to 40
            else -> "F" to 20
        }
        return if (!loadApplied) {
            Bufferbloat(idleMs, loadedMs, inc, "?", null, false, throughputMbps, false,
                "بار شبکه کافی اعمال نشد (${"%.1f".format(throughputMbps)} Mbps)؛ نتیجه قابل اتکا نیست")
        } else {
            Bufferbloat(idleMs, loadedMs, inc, grade, score, true, throughputMbps, true,
                "اندازه‌گیری معتبر با ${"%.1f".format(throughputMbps)} Mbps بار")
        }
    }

    fun bufferbloatGradeForTest(idleMs: Double, loadedMs: Double): Pair<String, Double> {
        val inc = loadedMs - idleMs
        val grade = when { inc < 20 -> "A"; inc < 50 -> "B"; inc < 100 -> "C"; inc < 200 -> "D"; else -> "F" }
        return grade to inc
    }
    // Gaming score 0-100, thresholds shown in UI. Benchmark ping, NOT in-game ping.
    // total is NULL while bufferbloat has not been measured: an unmeasured
    // component gets no assumed points (the old code gave a fake 5/10).
    data class Score(val total: Int?, val latency: Int, val jitter: Int, val loss: Int, val stability: Int, val loaded: Int?)
    fun score(p: PingResult, bb: Bufferbloat?): Score {
        val lat = Quality.pingPoints(p.avgMs, 35) // shared cutoffs with Quality.compute (max 40 there)
        val jit = when { p.jitterMs < 5 -> 20; p.jitterMs < 10 -> 16; p.jitterMs < 20 -> 11; p.jitterMs < 40 -> 6; else -> 2 }
        val loss = when { p.lossPct == 0.0 -> 25; p.lossPct < 1 -> 20; p.lossPct < 3 -> 14; p.lossPct < 5 -> 8; else -> 2 }
        val stab = when { p.spikes == 0 -> 10; p.spikes <= 2 -> 7; p.spikes <= 5 -> 4; else -> 1 }
        val load = bb?.score?.let { it * 10 / 100 }
        val total = if (load == null) null else (lat + jit + loss + stab + load).coerceIn(0, 100)
        return Score(total, lat, jit, loss, stab, load)
    }

    fun saveLast(ctx: Context, p: PingResult, bb: Bufferbloat?, score: Score, profile: String, region: String, conn: String) {
        History.withGate(ctx) {
        ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit()
            .putString("last", "${System.currentTimeMillis()}|${p.avgMs}|${p.jitterMs}|${p.lossPct}|${p.p95}|${bb?.grade ?: "-"}|${score.total ?: ""}|$profile|$region|$conn|${p.minMs}|${p.maxMs}")
            .apply()
        val old = ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).getString("log", "") ?: ""
        val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date())
        val line = "$dateStr | $profile | $region | avg ${"%.0f".format(p.avgMs)}ms jitter ${"%.1f".format(p.jitterMs)} loss ${"%.1f".format(p.lossPct)}% P50 ${"%.0f".format(p.p50)} P90 ${"%.0f".format(p.p90)} P95 ${"%.0f".format(p.p95)} score ${score.total?.toString() ?: "—"}/100"
        ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit().putString("log", (line + "\n" + old).lines().take(100).joinToString("\n")).apply()
        }
    }

    fun lastSummary(ctx: Context): String = History.withGate(ctx) { ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).getString("last", "") ?: "" }

    // ---- Bufferbloat persistence (v2.9.6, widget tile) ----
    // Stored record: "bb_last" = ts|idle|loaded|increase|grade|score|valid|note
    // in the "gaming" prefs. The note is sanitised (| -> ¦, newline -> space)
    // so the pipe format can never break. A malformed record parses to null
    // (never measured), never a crash and never a fake grade.
    data class StoredBufferbloat(val ts: Long, val bb: Bufferbloat)

    fun formatBufferbloatRecord(ts: Long, bb: Bufferbloat): String =
        "$ts|${bb.idleMs}|${bb.loadedMs}|${bb.increaseMs}|${bb.grade}|${bb.score ?: ""}|${bb.valid}|${bb.note.replace("|", "¦").replace("\n", " ")}"

    fun parseBufferbloatRecord(raw: String): StoredBufferbloat? {
        if (raw.isBlank()) return null
        val a = raw.split("|")
        if (a.size != 8) return null
        val ts = a[0].toLongOrNull() ?: return null
        val idle = a[1].toDoubleOrNull() ?: return null
        val loaded = a[2].toDoubleOrNull() ?: return null
        val inc = a[3].toDoubleOrNull() ?: return null
        val grade = a[4]
        val score = a[5].toIntOrNull()
        val valid = a[6].toBooleanStrictOrNull() ?: return null
        val note = a[7]
        return StoredBufferbloat(ts, Bufferbloat(idle, loaded, inc, grade, score, valid = valid, note = note))
    }

    // Unconditional: called even when there is no last ping, so a
    // bufferbloat result is never lost through the saveLast path.
    fun saveBufferbloat(ctx: Context, bb: Bufferbloat) {
        History.withGate(ctx) {
            ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit()
                .putString("bb_last", formatBufferbloatRecord(System.currentTimeMillis(), bb))
                .apply()
        }
    }

    fun lastBufferbloat(ctx: Context): StoredBufferbloat? = History.withGate(ctx) {
        parseBufferbloatRecord(ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).getString("bb_last", "") ?: "")
    }

    // In-progress flag: stores the start timestamp. Testing is stale after
    // 10 minutes (e.g. the activity was killed mid-test) — a stale flag
    // never shows "Testing" forever.
    fun setBufferbloatTesting(ctx: Context, testing: Boolean) {
        History.withGate(ctx) {
            ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit()
                .putLong("bb_testing_since", if (testing) System.currentTimeMillis() else 0L)
                .apply()
        }
    }

    fun isBufferbloatTesting(ctx: Context): Boolean = History.withGate(ctx) {
        val since = ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).getLong("bb_testing_since", 0L)
        since > 0 && System.currentTimeMillis() - since < 10 * 60 * 1000L
    }
    fun log(ctx: Context): String = History.withGate(ctx) { ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).getString("log", "") ?: "" }
    fun saveMatch(ctx: Context, profile: String, mode: String, inGamePing: String, note: String) {
        History.withGate(ctx) {
        val old = ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).getString("matches", "") ?: ""
        val line = "${History.timeStr(System.currentTimeMillis())} | $profile | $mode | پینگ داخل بازی: $inGamePing | $note"
        ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit().putString("matches", (line + "\n" + old).lines().take(100).joinToString("\n")).apply()
        }
    }
    fun matches(ctx: Context): String = History.withGate(ctx) { ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).getString("matches", "") ?: "" }

    // ---- v2.9.9: session-based background gaming monitoring ----
    // Pure session statistics, computed from the recorded sample series
    // (time order, -1.0 = drop). The SAME rules as the old activity loop:
    // a spike is a reply > 150ms or > 2x the running average (including
    // the sample itself); burst = longest run of consecutive drops;
    // jitter = mean absolute successive difference of successful replies.
    // Pure so the service can finish a session from the DB after a kill
    // and so the JVM tests can prove the math without a device.
    data class SessionStats(
        val sent: Int, val received: Int, val lossPct: Double,
        val avgMs: Double, val minMs: Double, val maxMs: Double,
        val jitterMs: Double, val p50: Double, val p90: Double, val p95: Double, val p99: Double,
        val spikes: Int, val burst: Int, val times: List<Double>
    )

    fun sessionStats(samples: List<Double>): SessionStats {
        val times = samples.filter { it >= 0.0 }
        val drops = samples.size - times.size
        val sent = samples.size
        val received = times.size
        val loss = if (sent == 0) 100.0 else drops * 100.0 / sent
        if (times.isEmpty()) {
            return SessionStats(sent, 0, loss, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, drops, emptyList())
        }
        val sorted = times.sorted()
        val avg = times.average()
        var jitter = 0.0
        if (times.size > 1) jitter = (1 until times.size).map { abs(times[it] - times[it - 1]) }.average()
        // Spike rule (same as the old live loop): running average INCLUDING
        // the current sample; burst = longest run of consecutive drops.
        var spikes = 0
        var burst = 0
        var curBurst = 0
        val running = mutableListOf<Double>()
        for (t in samples) {
            if (t < 0.0) { curBurst++; if (curBurst > burst) burst = curBurst; continue }
            curBurst = 0
            running.add(t)
            val avgSoFar = running.average()
            if (t > 150 || t > avgSoFar * 2) spikes++
        }
        return SessionStats(sent, received, loss, avg, sorted.first(), sorted.last(), jitter,
            percentile(sorted, 50.0), percentile(sorted, 90.0), percentile(sorted, 95.0), percentile(sorted, 99.0),
            spikes, burst, times)
    }

    // Session durations offered by the UI (minutes). Anything else is
    // coerced to 1 minute — a session never runs unbounded.
    fun durationToMs(min: Int): Long = when (min) { 1, 5, 15, 30 -> min * 60 * 1000L; else -> 60 * 1000L }
}
