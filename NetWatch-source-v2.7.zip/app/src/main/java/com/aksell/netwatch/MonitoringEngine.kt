package com.aksell.netwatch

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean

// Monitoring Engine — owns the *policy* of when measurements run. The
// Android mechanics stay where Android requires them (MainActivity's 1s tick
// Handler, MonitorService's Foreground Service loops), but every decision —
// "should a check run now?", "is one already running?", "is the Live state
// fresh?" — is answered here, in one place, with pure testable functions.
// Before v2.7 the same guards were duplicated in MainActivity, MonitorService
// and GamingActivity and could disagree; now there is one source of truth.
//
// Cadence policy (battery/data):
// - Full check (40+ probes): manual only, or an explicit user schedule.
// - Light check (8 probes): timer + background service, at the user interval.
// - Live ping: one real ICMP ping every 5s, only while monitoring runs and
//   the user switched it on. Never two live pings on top of each other.
object MonitoringEngine {

    // Single-flight guards shared by the Activity and the Service. An
    // AtomicBoolean (not a plain static boolean) so a check started from one
    // place is visible to the other.
    private val checkRunning = AtomicBoolean(false)
    private val liveRunning = AtomicBoolean(false)

    // Returns true only if no check is running right now; the caller owns
    // the matching releaseCheck() in a finally block.
    fun tryAcquireCheck(): Boolean = checkRunning.compareAndSet(false, true)
    fun releaseCheck() { checkRunning.set(false) }
    fun isCheckRunning(): Boolean = checkRunning.get()

    fun tryAcquireLive(): Boolean = liveRunning.compareAndSet(false, true)
    fun releaseLive() { liveRunning.set(false) }
    fun isLiveRunning(): Boolean = liveRunning.get()

    // Pure policy: enough time passed since the last cycle AND nothing is
    // running AND monitoring is wanted. JVM-testable, no Context needed.
    fun shouldRunCycle(lastCycleMs: Long, nowMs: Long, intervalSec: Int, wantMonitoring: Boolean): Boolean {
        if (!wantMonitoring) return false
        if (checkRunning.get()) return false
        if (intervalSec <= 0) return false
        return nowMs - lastCycleMs >= intervalSec * 1000L
    }

    // Pure policy: a live ping is due only when monitoring runs, the user
    // switched live ping on, the interval elapsed, and no live ping is in
    // flight (a slow ping must never stack another one on top of it).
    fun livePingDue(lastLiveMs: Long, nowMs: Long, monitoringOn: Boolean, liveOn: Boolean): Boolean {
        if (!monitoringOn || !liveOn) return false
        if (liveRunning.get()) return false
        return nowMs - lastLiveMs >= 5000L
    }

    // The "Live" pill is honest only when the service's heartbeat is fresh:
    // a real measurement landed in the last 15 seconds. A switch left on
    // after the service died never shows Live.
    fun heartbeatFresh(ctx: Context): Boolean =
        History.livePingOn(ctx) && System.currentTimeMillis() - History.lastHeartbeat(ctx) < 15_000

    fun livePingOn(ctx: Context): Boolean = History.livePingOn(ctx)
    fun setLivePing(ctx: Context, on: Boolean) = History.setLivePing(ctx, on)

    // The background service reports its state here (set in onCreate /
    // onDestroy). The engine never imports the Service class — the dependency
    // goes one way only: Service -> Engine. The widget and the UI read the
    // state through here, not through a static flag of their own.
    @Volatile private var serviceRunningFlag = false
    fun setServiceRunning(v: Boolean) { serviceRunningFlag = v }
    fun serviceRunning(): Boolean = serviceRunningFlag
}
