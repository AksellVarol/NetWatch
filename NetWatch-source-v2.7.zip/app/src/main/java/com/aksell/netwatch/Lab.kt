package com.aksell.netwatch

import android.content.Context
import kotlin.math.abs

data class TestResult(val name: String, val method: String, val expected: String, val actual: String, val pass: Boolean?, val error: String = "", val date: String = "")
// pass: true=Pass, false=Fail, null=Not Tested

object Lab {
    data class Stats(val min: Double, val avg: Double, val max: Double, val p50: Double, val p90: Double, val p95: Double, val p99: Double, val jitter: Double, val lossPct: Double)
    fun computeStats(times: List<Double>, sent: Int): Stats {
        val s = times.sorted()
        fun pct(p: Double): Double { if (s.isEmpty()) return 0.0; val rank = kotlin.math.ceil(p / 100.0 * s.size).toInt().coerceIn(1, s.size); return s[rank - 1] }
        var j = 0.0
        if (times.size > 1) j = (1 until times.size).map { abs(times[it] - times[it - 1]) }.average()
        return Stats(s.firstOrNull() ?: 0.0, if (times.isEmpty()) 0.0 else times.average(), s.lastOrNull() ?: 0.0, pct(50.0), pct(90.0), pct(95.0), pct(99.0), j, if (sent == 0) 0.0 else (sent - times.size) * 100.0 / sent)
    }

    fun unitTests(): List<TestResult> {
        val out = mutableListOf<TestResult>()
        fun t(name: String, expected: String, actual: String, ok: Boolean) { out.add(TestResult(name, "Unit — ورودی ثابت، بدون شبکه", expected, actual, ok, date = History.timeStr(System.currentTimeMillis()))) }
        // Fixed input: [42,48,50,55,72], sent 5
        val st = computeStats(listOf(42.0, 48.0, 50.0, 55.0, 72.0), 5)
        t("Ping Avg/Min/Max", "avg 53.4, min 42, max 72", "avg ${"%.1f".format(st.avg)}, min ${st.min}, max ${st.max}", st.avg == 53.4 && st.min == 42.0 && st.max == 72.0)
        t("P50/P90/P95/P99 (nearest-rank)", "P50 50, P90 72, P95 72, P99 72", "P50 ${st.p50}, P90 ${st.p90}, P95 ${st.p95}, P99 ${st.p99}", st.p50 == 50.0 && st.p90 == 72.0 && st.p95 == 72.0 && st.p99 == 72.0)
        t("اعتبار آماری نمونه کم", "n=5 → اعتبار پایین (در UI هم نمایش داده می‌شود)", "n=5", true)
        // Statistical validation: 100 values 1..100 -> P50=51, P90=91, P95=96 (nearest-rank on (p/100)*(n-1))
        val big = Lab.computeStats((1..100).map { it.toDouble() }, 100)
        t("اعتبارسنجی آماری (۱ تا ۱۰۰)", "P50 50, P90 90, P95 95", "P50 ${big.p50}, P90 ${big.p90}, P95 ${big.p95}", big.p50 == 50.0 && big.p90 == 90.0 && big.p95 == 95.0)
        // Division by zero guard
        val empty = Lab.computeStats(emptyList(), 0)
        t("تقسیم بر صفر (داده خالی)", "همه صفر، بدون Crash", "avg ${empty.avg}, loss ${empty.lossPct}%", empty.avg == 0.0 && empty.lossPct == 0.0)
        t("Jitter", "jitter 7.5 (diffs 6,2,5,17 -> mean 30/4)", "jitter ${"%.1f".format(st.jitter)}", st.jitter == 7.5)
        t("Packet Loss", "loss 0% (5/5)", "loss ${st.lossPct}%", st.lossPct == 0.0)
        val st2 = computeStats(listOf(40.0, 45.0), 5)
        t("Packet Loss با بسته گمشده", "loss 60% (2/5)", "loss ${st2.lossPct}%", st2.lossPct == 60.0)
        // Bufferbloat grade: idle 48, loaded 60 -> +12ms -> A
        val bb = Gaming.bufferbloatGradeForTest(48.0, 60.0)
        t("Bufferbloat Grade", "افزایش 12ms → A", "درجه ${bb.first} (افزایش ${bb.second}ms)", bb.first == "A")
        val bb2 = Gaming.bufferbloatGradeForTest(48.0, 180.0)
        t("Bufferbloat Grade بد", "افزایش 132ms → D", "درجه ${bb2.first}", bb2.first == "D")
        // Score: perfect ping 40ms, jitter 3, loss 0, no spikes, bb A(100) -> 35+20+25+10+10=100
        val pr = PingResult("test", 20, 20, 0.0, 40.0, 40.0, 45.0, 40.0, 41.0, 42.0, 44.0, 3.0, 0, 0, listOf(40.0))
        val sc = Gaming.score(pr, Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100))
        t("Network Score کامل", "100/100", "${sc.total}/100", sc.total == 100)
        val bad = PingResult("test", 20, 10, 50.0, 100.0, 200.0, 400.0, 180.0, 300.0, 350.0, 390.0, 50.0, 8, 3, listOf(200.0))
        val sc2 = Gaming.score(bad, Gaming.Bufferbloat(200.0, 400.0, 200.0, "F", 20))
        t("Network Score بد", "کمتر از 40", "${sc2.total}/100", sc2.total != null && sc2.total < 40)
        // v2.6: bufferbloat unmeasured -> total is null, never a fake 5/10.
        val scNoBb = Gaming.score(pr, null)
        t("Gaming Score — بدون Bufferbloat", "total == null (امتیاز فرضی ندارد)", "total=${scNoBb.total}", scNoBb.total == null)
        val scBb = Gaming.score(pr, Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100))
        t("Gaming Score — با Bufferbloat", "total == 100", "total=${scBb.total}", scBb.total == 100)
        // v2.6: dnsTime on an IP literal is N/A, not a 0ms DNS success.
        val dnsIp = Diagnostics.dnsTime("1.1.1.1")
        t("dnsTime — IP مستقیم", "ok=false، note شامل N/A", "ok=${dnsIp.ok}، ${dnsIp.note}", !dnsIp.ok && dnsIp.note.contains("N/A"))
        // v2.6: ChartData — pure chart math (empty / 1 / 2 / 60 / >60, irregular
        // timestamps, failed points split segments, outliers, range filters).
        val now = System.currentTimeMillis()
        val cdEmpty = ChartData.stats(emptyList())
        t("Chart — خالی", "valid=0، min/avg/max=0", "valid=${cdEmpty.valid}", cdEmpty.valid == 0 && cdEmpty.min == 0.0 && cdEmpty.avg == 0.0 && cdEmpty.max == 0.0)
        val cdOne = ChartData.stats(listOf(now to 42.0))
        t("Chart — یک نمونه", "min=avg=max=42", "min=${cdOne.min} avg=${cdOne.avg} max=${cdOne.max}", cdOne.min == 42.0 && cdOne.avg == 42.0 && cdOne.max == 42.0)
        val cdTwo = ChartData.stats(listOf(now to 40.0, now + 5000 to 60.0))
        t("Chart — دو نمونه", "min=40 avg=50 max=60", "avg=${cdTwo.avg}", cdTwo.min == 40.0 && cdTwo.avg == 50.0 && cdTwo.max == 60.0)
        val sixty = (0 until 60).map { now + it * 1000L to (40.0 + it) }
        val cd60 = ChartData.stats(sixty)
        t("Chart — ۶۰ نمونه", "min=40 avg=69.5 max=99", "avg=${cd60.avg} max=${cd60.max}", cd60.valid == 60 && cd60.min == 40.0 && cd60.avg == 69.5 && cd60.max == 99.0)
        val over = (0 until 120).map { now + it * 1000L to 50.0 }
        val cdOver = ChartData.stats(over)
        t("Chart — بیش از ۶۰ نمونه", "valid=120 (بدون برش)", "valid=${cdOver.valid}", cdOver.valid == 120 && cdOver.avg == 50.0)
        val irregular = listOf(now to 50.0, now + 137000 to 60.0, now + 900000 to 70.0)
        val cdIr = ChartData.stats(irregular)
        t("Chart — Timestamp نامنظم", "آمار از مقدارها، نه فاصله‌ها", "avg=${cdIr.avg}", cdIr.avg == 60.0)
        val withFail = listOf(now to 40.0, now + 1000 to -1.0, now + 2000 to 50.0, now + 3000 to -1.0, now + 4000 to 60.0)
        val segs = ChartData.segments(withFail)
        val cdFail = ChartData.stats(withFail)
        t("Chart — نمونه ناموفق بین موفق‌ها", "۳ قطعه جدا + failed=2، آمار فقط موفق‌ها", "segments=${segs.size} failed=${cdFail.failed} avg=${cdFail.avg}", segs.size == 3 && cdFail.failed == 2 && cdFail.avg == 50.0)
        val outlier = (0 until 20).map { now + it * 1000L to 50.0 } + listOf(now + 21000 to 986.0)
        val ym = ChartData.yMax(outlier.map { it.second })
        t("Chart — yMax با مقدار پرت", "P95=50 → yMax=100 (نه 986×1.2)", "yMax=$ym", ym == 100.0)
        val nanPts = listOf(now to 40.0, now + 1000 to Double.NaN, now + 2000 to 60.0)
        val cdNan = ChartData.stats(nanPts)
        t("Chart — NaN", "NaN مثل ناموفق شمرده شود", "valid=${cdNan.valid} failed=${cdNan.failed}", cdNan.valid == 2 && cdNan.failed == 1)
        val day = 24L * 3600 * 1000
        val mixed = listOf(now - 40 * day to 40.0, now - 5 * day to 50.0, now - 1 * 3600 * 1000 to 60.0, now to 70.0)
        val r24 = ChartData.inRange(mixed, now - day)
        val r7 = ChartData.inRange(mixed, now - 7 * day)
        val r30 = ChartData.inRange(mixed, now - 30 * day)
        t("Chart — فیلتر 24h/7d/30d", "24h=2، 7d=3، 30d=3", "24h=${r24.size} 7d=${r7.size} 30d=${r30.size}", r24.size == 2 && r7.size == 3 && r30.size == 3)
        // Quality Score Phase 1 (v1.9): ScoreResult sealed + Coverage Gate 70%
        val q1 = Quality.compute(40.0, 3.0, 0.0, 100)
        t("Quality Score — همه معتبر", "Complete, Total 100, coverage 100٪", "Total ${(q1 as? Quality.ScoreResult.Complete)?.total}, ${(q1 as? Quality.ScoreResult.Complete)?.coverage}", q1 is Quality.ScoreResult.Complete && q1.total == 100 && q1.coverage == 1.0)
        // Old v1.8 bug case: ping missing -> normalized 100/100. Now: coverage 60% < 70% -> InsufficientData, NO total.
        val q2 = Quality.compute(0.0, 3.0, 0.0, 100, pingValid = false)
        t("Quality Score — فقط Ping فاقد داده", "InsufficientData, coverage 60٪, بدون عدد کل", "نوع ${q2::class.simpleName}, coverage ${(q2 as? Quality.ScoreResult.InsufficientData)?.coverage}", q2 is Quality.ScoreResult.InsufficientData && q2.coverage == 0.6)
        val q3 = Quality.compute(100.0, 0.0, 2.0, 85, jitterValid = false)
        t("Quality Score — فقط Jitter فاقد داده", "Complete, Total 65 (52/80 نرمال‌شده)، coverage 80٪", "Total ${(q3 as? Quality.ScoreResult.Complete)?.total}", q3 is Quality.ScoreResult.Complete && q3.total == 65 && q3.coverage == 0.8)
        val q4 = Quality.compute(0.0, 0.0, 0.0, 90, pingValid = false, jitterValid = false)
        t("Quality Score — چند مؤلفه فاقد داده", "InsufficientData, coverage 40٪", "نوع ${q4::class.simpleName}", q4 is Quality.ScoreResult.InsufficientData && q4.coverage == 0.4)
        val q5 = Quality.compute(0.0, 0.0, 0.0, 0, pingValid = false, jitterValid = false, lossValid = false, stabValid = false)
        t("Quality Score — هیچ مؤلفه‌ای داده ندارد", "NotAvailable", "نوع ${q5::class.simpleName}", q5 is Quality.ScoreResult.NotAvailable)
        // Fix 1: avgMs <= 0 with pingValid=true must be N/A, not score 0
        val q6 = Quality.compute(0.0, 3.0, 0.0, 100)
        t("Quality Score — avgMs صفر", "Ping N/A (نه صفر)، coverage 60٪ -> InsufficientData", "Ping ${(q6 as? Quality.ScoreResult.InsufficientData)?.parts?.ping ?: "N/A"}", q6 is Quality.ScoreResult.InsufficientData && q6.parts.ping == null)
        // Coverage Gate exact boundary (70 is unreachable with weights 40/20/25/15, tested directly)
        t("Coverage Gate — مرز دقیق 70٪", "70/100 -> Complete", "gate(70,100)=${Quality.coverageGate(70, 100)}", Quality.coverageGate(70, 100))
        t("Coverage Gate — زیر مرز 69٪", "69/100 -> Insufficient", "gate(69,100)=${Quality.coverageGate(69, 100)}", !Quality.coverageGate(69, 100))
        t("Coverage Gate — پوشش کامل", "100/100 -> Complete", "gate(100,100)=${Quality.coverageGate(100, 100)}", Quality.coverageGate(100, 100))
        t("Coverage Gate — وزن صفر", "0/0 -> Insufficient", "gate(0,0)=${Quality.coverageGate(0, 0)}", !Quality.coverageGate(0, 0))
        // Shared ping table (#11): for any ping, Gaming's latency part must equal
        // Quality's ping part scaled 35/40 (rounded). Same cutoffs, same relative score.
        val sharedOk = listOf(30.0, 60.0, 100.0, 150.0, 250.0).all { ms ->
            val qp = Quality.pingPoints(ms, 40)
            val prx = PingResult("test", 20, 20, 0.0, ms, ms, ms, ms, ms, ms, ms, 0.0, 0, 0, listOf(ms))
            val gs = Gaming.score(prx, Gaming.Bufferbloat(ms, ms, 0.0, "A", 100))
            gs.latency == (qp * 35 + 20) / 40
        }
        t("Ping Points مشترک (Gaming/Quality)", "برای هر ping، بخش Gaming = گرد شده Quality × 35/40", if (sharedOk) "یکسان ✅" else "متفاوت ❌", sharedOk)
        // v2.7 engines — pure, JVM-testable policy (no network, no Context):
        // MonitoringEngine single-flight: acquire, refuse while held, release.
        // If a real check is running right now (background service), the guard
        // is legitimately held — that is NOT TESTED, not a failure, and the
        // test must not release a guard it does not own.
        val acq1 = MonitoringEngine.tryAcquireCheck()
        val acqHeldByOther = !acq1
        val acq2 = if (acq1) MonitoringEngine.tryAcquireCheck() else false
        if (acq1) MonitoringEngine.releaseCheck()
        val acq3 = MonitoringEngine.tryAcquireCheck()
        if (acq3) MonitoringEngine.releaseCheck()
        out.add(TestResult("MonitoringEngine — Single-flight", "Unit — ورودی ثابت، بدون شبکه",
            "اول true، دومی false، بعد از release دوباره true",
            if (acqHeldByOther) "یک بررسی واقعی در حال اجراست — گارد در اختیار تست نیست" else "acq=$acq1/$acq2/$acq3",
            if (acqHeldByOther) null else (acq1 && !acq2 && acq3), "", History.timeStr(System.currentTimeMillis())))
        // MonitoringEngine cadence policy (pure time math).
        val cycOk = MonitoringEngine.shouldRunCycle(0, 31000, 30, true)
        val cycSoon = MonitoringEngine.shouldRunCycle(0, 10000, 30, true)
        val cycOff = MonitoringEngine.shouldRunCycle(0, 31000, 30, false)
        val cycZero = MonitoringEngine.shouldRunCycle(0, 31000, 0, true)
        t("MonitoringEngine — زمان‌بندی چرخه", "31s بعد از 30s مجاز؛ 10s نه؛ خاموش نه؛ فاصله ۰ نه", "31s=$cycOk 10s=$cycSoon off=$cycOff iv0=$cycZero", cycOk && !cycSoon && !cycOff && !cycZero)
        val liveOk = MonitoringEngine.livePingDue(0, 6000, true, true)
        val liveSoon = MonitoringEngine.livePingDue(0, 2000, true, true)
        val liveOff = MonitoringEngine.livePingDue(0, 6000, true, false)
        val liveNoMon = MonitoringEngine.livePingDue(0, 6000, false, true)
        t("MonitoringEngine — زمان‌بندی Live Ping", "6s بعد مجاز؛ 2s نه؛ سوییچ خاموش نه؛ مانیتورینگ خاموش نه", "6s=$liveOk 2s=$liveSoon off=$liveOff noMon=$liveNoMon", liveOk && !liveSoon && !liveOff && !liveNoMon)
        // NetworkEngine single-flight: a second submit for the same key is
        // refused while the first is still running.
        val single1 = NetworkEngine.submitSingle("lab-test-key") { try { Thread.sleep(300) } catch (e: Exception) {} }
        val single2 = NetworkEngine.submitSingle("lab-test-key") {}
        val singleRunning = NetworkEngine.isRunning("lab-test-key")
        Thread.sleep(500)
        val singleAfter = NetworkEngine.isRunning("lab-test-key")
        t("NetworkEngine — Single-flight", "اول true، دومی false، در حال اجرا true، بعد از پایان false", "1st=$single1 2nd=$single2 running=$singleRunning after=$singleAfter", single1 && !single2 && singleRunning && !singleAfter)
        // AnalyticsEngine delegates to the same functions the UI used to call
        // directly — identical values, one API.
        val aeScore = AnalyticsEngine.gamingScore(pr, Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100))
        t("AnalyticsEngine — Gaming Score", "همان Gaming.score مستقیم (total=100)", "total=${aeScore.total}", aeScore.total == sc.total && aeScore.total == 100)
        val aeQ = AnalyticsEngine.qualityScore(40.0, 3.0, 0.0, 100)
        t("AnalyticsEngine — Quality Score", "همان Quality.compute مستقیم (Complete, 100)", "نوع ${aeQ::class.simpleName}", aeQ is Quality.ScoreResult.Complete && aeQ.total == 100)
        val aeStats = AnalyticsEngine.burstStats(listOf(42.0, 48.0, 50.0, 55.0, 72.0), 5)
        t("AnalyticsEngine — Burst Stats", "avg 53.4 مثل Lab.computeStats", "avg ${"%.1f".format(aeStats.avg)}", aeStats.avg == 53.4)
        val aeChart = AnalyticsEngine.chartStats(listOf(now to 40.0, now + 1000 to -1.0, now + 2000 to 60.0))
        t("AnalyticsEngine — Chart Stats", "failed=1، avg فقط موفق‌ها=50", "failed=${aeChart.failed} avg=${aeChart.avg}", aeChart.failed == 1 && aeChart.avg == 50.0)
        // v2.4: old 3-field samples parse with -1 metrics; new 6-field samples keep values.
        val sOld = History.parseSample("1700000000000,35,40")
        val sNew = History.parseSample("1700000000000,35,40,120.5,8.2,0.0")
        t("Sample قدیمی (۳ فیلد)", "بدون پینگ/جیتر/قطعی = -1", if (sOld != null && sOld.avgMs == -1.0 && sOld.lossPct == -1.0) "سازگار ✅" else "خراب ❌", sOld != null && sOld.avgMs == -1.0)
        t("Sample جدید (۶ فیلد)", "مقادیر حفظ شوند", if (sNew != null && sNew.avgMs == 120.5 && sNew.jitterMs == 8.2) "درست ✅" else "خراب ❌", sNew != null && sNew.avgMs == 120.5 && sNew.jitterMs == 8.2)
        // v2.4: timeline lines parse into time/kind/text.
        val evs = History.parseTimeline("12:30 [outage-start] شروع اختلال در 12:30 — دسترسی ۳۰٪\n12:45 [network-change] تغییر شبکه")
        t("Timeline parse", "نوع و زمان جدا شوند", if (evs.size == 2 && evs[0].kind == "outage-start" && evs[1].time == "12:45") "درست ✅" else "خراب ❌", evs.size == 2 && evs[0].kind == "outage-start" && evs[1].time == "12:45")
        // v2.4: one status vocabulary — same score, same word, app and widget alike.
        val stOk = Quality.widgetStatus(85, "Complete") == "Connected" && Quality.widgetStatus(60, "Complete") == "Degraded" && Quality.widgetStatus(30, "Complete") == "Offline" && Quality.widgetStatus(null, "InsufficientData") == "Degraded"
        t("Widget Status از امتیاز", "۸۵→Connected، ۶۰→Degraded، ۳۰→Offline", if (stOk) "یکسان ✅" else "متفاوت ❌", stOk)
        // Chart: values must be in 0..100 and count preserved
        val chart = listOf(42.0, 48.0, 72.0).map { (it / 2).toInt().coerceIn(0, 100) }
        t("صحت داده نمودار", "[21, 24, 36]", chart.toString(), chart == listOf(21, 24, 36))
        return out
    }

    fun save(ctx: Context, results: List<TestResult>) {
        val p = ctx.getSharedPreferences("lab", Context.MODE_PRIVATE)
        val old = p.getString("results", "") ?: ""
        val text = results.joinToString("\n") { "${it.date} | ${it.name} | ${if (it.pass == true) "PASS" else if (it.pass == false) "FAIL" else "NOT TESTED"} | expected: ${it.expected} | actual: ${it.actual} | ${it.error}" }
        p.edit().putString("results", (text + "\n" + old).lines().take(200).joinToString("\n")).apply()
    }
    fun load(ctx: Context): String = ctx.getSharedPreferences("lab", Context.MODE_PRIVATE).getString("results", "") ?: ""
}
