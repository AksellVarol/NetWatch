// NetWatch — settings.gradle.kts (v2.11.3, issue 01)
// Project-level settings: plugin repositories, project name, included modules.

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "NetWatch"
include(":app")
