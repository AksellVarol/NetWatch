// NetWatch — root build.gradle.kts (v2.11.3, issue 01)
// Declares the plugin versions used by every module. Nothing is applied here;
// the :app module applies the plugins it needs.
//
// Versions (chosen as one compatible trio — see README.md "Build versions"):
//   Android Gradle Plugin 8.5.2  — requires Gradle >= 8.7 and JDK 17
//   Kotlin Gradle Plugin  1.9.24  — newest 1.9.x patch; compatible with AGP 8.5
//                                   and Gradle 8.7, and avoids the Kotlin 2.0
//                                   (K2 compiler) switch for this old-style,
//                                   coroutine-free, zero-dependency codebase.

plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
