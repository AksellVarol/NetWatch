package com.aksell.netwatch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

// Lab pure-logic tests — JVM unit tests (no Android, no network, no Context).
//
// Issue 03 (v2.11.3, Lab group): the pure assertions of Lab.unitTests()
// (Lab.kt) are mirrored here as JUnit4 tests so they run on the JVM in
// `testDebugUnitTest` instead of only on-device. This file DUPLICATES the
// assertions — it does not move production logic: Lab.kt stays in src/main
// because production code still calls it (AnalyticsEngine.burstStats ->
// Lab.computeStats; Bridge / BridgeActivity / AiCore -> Lab.loadRuns;
// LabActivity -> Lab.unitTests() / save / saveRun / mergeRerun /
// groupBadge / runAllSummary / summarizeDoh / summarizeUdp /
// classificationConsistent). Lab.unitTests() itself is NOT called from
// here: it also runs executor / single-flight / socket-FD / live-network
// checks that need a device and would fail or flake on the JVM.
//
// What is intentionally NOT in src/test (stays on-device in LabActivity):
// - MonitoringEngine / NetworkEngine / NetExecutor single-flight, race,
//   cancel and thread-count tests (real executors, android.os.Handler).
// - History DB round-trip, backup/restore, streaming, crash-recovery,
//   migration and large-RAM groups (Context + SQLite + files).
// - Lab.save / load / saveRun / loadRuns / removeRun (SharedPreferences
//   + org.json — android.jar stubs throw on the JVM).
// - Bridge-device and Gaming-lifecycle groups (Context, services).
//
// Requires (build.gradle belongs to another group — NOT added here):
//   testImplementation "junit:junit:4.13.2"
// History.staleSidecarAction is `internal`; unit tests in the same module
// can call it (Gradle test compilation uses friend paths).
class LabPureTests {

    // ---- Lab.computeStats ----

    @Test fun computeStats_fixedInput() {
        val st = Lab.computeStats(listOf(42.0, 48.0, 50.0, 55.0, 72.0), 5)
        assertEquals(53.4, st.avg, 0.0)
        assertEquals(42.0, st.min, 0.0)
        assertEquals(72.0, st.max, 0.0)
        assertEquals(50.0, st.p50, 0.0)
        assertEquals(72.0, st.p90, 0.0)
        assertEquals(72.0, st.p95, 0.0)
        assertEquals(72.0, st.p99, 0.0)
        assertEquals(7.5, st.jitter, 0.0) // diffs 6,2,5,17 -> mean 30/4
        assertEquals(0.0, st.lossPct, 0.0)
        assertEquals(50.0, st.median, 0.0)
    }

    @Test fun computeStats_percentiles1to100() {
        val big = Lab.computeStats((1..100).map { it.toDouble() }, 100)
        assertEquals(50.0, big.p50, 0.0)
        assertEquals(90.0, big.p90, 0.0)
        assertEquals(95.0, big.p95, 0.0)
        assertEquals(99.0, big.p99, 0.0)
    }

    @Test fun computeStats_empty() {
        val empty = Lab.computeStats(emptyList(), 0)
        assertEquals(0.0, empty.avg, 0.0)
        assertEquals(0.0, empty.lossPct, 0.0)
        assertEquals(0.0, empty.stdDev, 0.0)
        assertEquals(0.0, empty.median, 0.0)
    }

    @Test fun computeStats_lossWithMissingPacket() {
        val st2 = Lab.computeStats(listOf(40.0, 45.0), 5)
        assertEquals(60.0, st2.lossPct, 0.0) // loss 60% (2/5)
    }

    @Test fun computeStats_medianAndStdDev() {
        val med1 = Lab.computeStats(listOf(10.0, 20.0, 30.0, 40.0, 50.0), 5)
        assertEquals(30.0, med1.median, 0.0)
        assertTrue(abs(med1.stdDev - 14.14213562) < 0.001) // population, /n: sqrt(200)
        val med2 = Lab.computeStats(listOf(10.0, 20.0, 30.0, 40.0), 4)
        assertEquals(25.0, med2.median, 0.0) // mean of 20 and 30
        val st = Lab.computeStats(listOf(42.0, 48.0, 50.0, 55.0, 72.0), 5)
        assertTrue(abs(st.stdDev - 10.19) < 0.01) // variance 103.84
        assertEquals(50.0, st.median, 0.0)
    }

    @Test fun computeStats_singleAndIdentical() {
        val single = Lab.computeStats(listOf(42.0), 1)
        assertEquals(42.0, single.avg, 0.0)
        assertEquals(42.0, single.min, 0.0)
        assertEquals(42.0, single.max, 0.0)
        assertEquals(42.0, single.median, 0.0)
        assertEquals(0.0, single.jitter, 0.0)
        assertEquals(0.0, single.stdDev, 0.0)
        val same = Lab.computeStats(listOf(50.0, 50.0, 50.0), 3)
        assertEquals(50.0, same.avg, 0.0)
        assertEquals(50.0, same.median, 0.0)
        assertEquals(0.0, same.stdDev, 0.0)
        assertEquals(0.0, same.lossPct, 0.0)
        val empty = Lab.computeStats(emptyList(), 0)
        assertEquals(0.0, Lab.computeStats(listOf(7.0), 1).stdDev, 0.0)
        assertEquals(0.0, empty.stdDev, 0.0)
    }

    @Test fun computeStats_invalidSamplesIgnored() {
        // NaN / +Inf / -Inf / negative samples never poison value stats;
        // loss stays a COUNT ratio (sent vs received), clamped to 0..100.
        val nanSt = Lab.computeStats(listOf(40.0, Double.NaN, 60.0), 3)
        assertEquals(50.0, nanSt.avg, 0.0)
        assertEquals(40.0, nanSt.min, 0.0)
        assertEquals(60.0, nanSt.max, 0.0)
        assertEquals(50.0, nanSt.median, 0.0)
        assertEquals(0.0, nanSt.lossPct, 0.0)
        val infSt = Lab.computeStats(listOf(40.0, Double.POSITIVE_INFINITY, 60.0), 3)
        assertEquals(50.0, infSt.avg, 0.0)
        assertEquals(40.0, infSt.min, 0.0)
        assertEquals(60.0, infSt.max, 0.0)
        val negInfSt = Lab.computeStats(listOf(40.0, Double.NEGATIVE_INFINITY, 60.0), 3)
        assertEquals(50.0, negInfSt.avg, 0.0)
        assertEquals(0.0, negInfSt.lossPct, 0.0)
        val allNanSt = Lab.computeStats(listOf(Double.NaN, Double.NaN), 2)
        assertEquals(0.0, allNanSt.avg, 0.0)
        assertEquals(0.0, allNanSt.min, 0.0)
        assertEquals(0.0, allNanSt.max, 0.0)
        assertEquals(0.0, allNanSt.lossPct, 0.0) // 2 samples received
        val negSt = Lab.computeStats(listOf(-5.0, 40.0, 50.0), 3)
        assertEquals(45.0, negSt.avg, 0.0)
        assertEquals(40.0, negSt.min, 0.0)
        assertEquals(50.0, negSt.max, 0.0)
        assertEquals(0.0, negSt.lossPct, 0.0)
    }

    @Test fun computeStats_lossClamping() {
        // received > sent -> loss clamped to 0, never negative.
        val overRecv = Lab.computeStats(listOf(40.0, 45.0, 50.0, 55.0, 60.0), 3)
        assertEquals(0.0, overRecv.lossPct, 0.0)
        // sent=0 with data -> loss 0, no division by zero.
        val sentZero = Lab.computeStats(listOf(40.0, 50.0), 0)
        assertEquals(0.0, sentZero.lossPct, 0.0)
        assertEquals(45.0, sentZero.avg, 0.0)
        // empty with sent>0 -> loss 100%, other stats 0.
        val emptySent = Lab.computeStats(emptyList(), 5)
        assertEquals(100.0, emptySent.lossPct, 0.0)
        assertEquals(0.0, emptySent.avg, 0.0)
        assertEquals(0.0, emptySent.min, 0.0)
        assertEquals(0.0, emptySent.max, 0.0)
    }

    // ---- Lab.classificationConsistent + Quality.classifyDisruption ----

    private fun synthProbes(okFlags: List<Boolean>): List<ProbeResult> =
        okFlags.mapIndexed { i, ok ->
            ProbeResult("p$i", "پروب $i", "HTTPS", ok, if (ok) 50 else 0, if (ok) "OK" else "Fail", false, "intl")
        }

    @Test fun classification_allOkIsHealthy() {
        val probes = synthProbes(listOf(true, true, true))
        val cls = Quality.classifyDisruption(probes, "", true, true, 100, 100)
        assertEquals("سالم", cls.type)
        assertTrue(Lab.classificationConsistent(probes, cls))
    }

    @Test fun classification_noneOkIsFullOutage() {
        val probes = synthProbes(listOf(false, false, false))
        val cls = Quality.classifyDisruption(probes, "", true, true, 0, 0)
        assertTrue(cls.type.contains("قطعی کامل"))
        assertTrue(Lab.classificationConsistent(probes, cls))
    }

    @Test fun classification_noneOkPlusGatewayDownIsStillFullOutage() {
        // runall-fixes §4: the all-fail rule wins over the gateway branch.
        val probes = synthProbes(listOf(false, false, false))
        val cls = Quality.classifyDisruption(probes, "", false, false, 0, 0)
        assertEquals("قطعی کامل", cls.type)
        assertTrue(cls.confidence >= 80)
        assertFalse(cls.type.contains("Gateway"))
        assertTrue(Lab.classificationConsistent(probes, cls))
    }

    @Test fun classification_real2203DataAll41ProbesFailed() {
        val real2203 = Probes.defs.map {
            ProbeResult(it.id, it.name, it.detail, false, 0, "Fail", it.domestic, it.category)
        }
        assertEquals(41, real2203.size)
        val cls = Quality.classifyDisruption(real2203, "", false, false, 0, 0)
        assertEquals("قطعی کامل", cls.type)
        assertTrue(cls.confidence >= 80)
        assertTrue(Lab.classificationConsistent(real2203, cls))
    }

    @Test fun classification_emptyListIsNeverHealthy() {
        val cls = Quality.classifyDisruption(emptyList(), "", true, true, 0, 0)
        assertTrue(cls.type.contains("بدون داده کافی"))
        assertFalse(cls.type == "سالم")
        assertFalse(Lab.classificationConsistent(emptyList(), cls))
        val clsGwDown = Quality.classifyDisruption(emptyList(), "", false, false, 0, 0)
        assertTrue(clsGwDown.type.contains("بدون داده کافی"))
        assertFalse(clsGwDown.type.contains("قطعی کامل"))
        assertFalse(clsGwDown.type.contains("Gateway"))
        assertFalse(Lab.classificationConsistent(emptyList(), clsGwDown))
    }

    @Test fun classification_mixedIsNeitherHealthyNorOutage() {
        val probes = synthProbes(listOf(true, true, false))
        val cls = Quality.classifyDisruption(probes, "", true, true, 66, 66)
        assertFalse(cls.type == "سالم")
        assertFalse(cls.type.contains("قطعی کامل"))
        assertTrue(Lab.classificationConsistent(probes, cls))
    }

    @Test fun classification_inconsistencyIsDetected() {
        val allOk = synthProbes(listOf(true, true, true))
        val mixed = synthProbes(listOf(true, true, false))
        val noneOk = synthProbes(listOf(false, false, false))
        assertFalse(Lab.classificationConsistent(allOk, Quality.Classification("قطعی کامل", 85, "")))
        assertFalse(Lab.classificationConsistent(mixed, Quality.Classification("سالم", 95, "")))
        assertFalse(Lab.classificationConsistent(noneOk, Quality.Classification("سالم", 95, "")))
        assertFalse(Lab.classificationConsistent(emptyList(), Quality.Classification("سالم", 95, "")))
    }

    // ---- Lab.summarizeDoh / summarizeUdp ----

    @Test fun summarizeDoh_countsByDetail() {
        // "DoH" lives in ProbeDef.detail, NEVER in name (v2.9.4 LAB bug).
        assertEquals(3, Probes.defs.count { it.detail == "DoH" })
        assertEquals(0, Probes.defs.count { it.name.contains("DoH") })
        val synth = listOf(
            ProbeResult("cfdns", "DNS کلادفلر 1.1.1.1", "DoH", true, 120, "DoH OK", false, "dns"),
            ProbeResult("gdns", "DNS گوگل 8.8.8.8", "DoH", false, 5000, "Timeout اتصال/خواندن", false, "dns"),
            ProbeResult("quad9", "DNS کواد۹ 9.9.9.9", "DoH", false, 5000, "TLS Handshake ناموفق", false, "dns")
        )
        val sum = Lab.summarizeDoh(synth)
        assertEquals(1, sum.first)
        assertEquals(3, sum.second)
        assertTrue(sum.third.contains("کلادفلر"))
        assertTrue(sum.third.contains("Timeout"))
    }

    @Test fun summarizeUdp_countsByDetailPrefix() {
        val synth = listOf(
            ProbeResult("udp-cf", "UDP DNS کلادفلر", "UDP :53", true, 40, "پاسخ موفق DNS", false, "dns"),
            ProbeResult("udp-gg", "UDP DNS گوگل", "UDP :53", false, 4000, "timeout: پاسخ DNS نرسید", false, "dns")
        )
        val sum = Lab.summarizeUdp(synth)
        assertEquals(1, sum.first)
        assertEquals(2, sum.second)
    }

    // ---- Lab.mergeRerun / groupBadge / runAllSummary ----

    private fun badgeRes(name: String, pass: Boolean?) = TestResult(name, "m", "e", "a", pass, "", "t", 1)

    @Test fun mergeRerun_replacesOnlyTheRerunTest() {
        val base = listOf(
            TestResult("Merge Test — A", "m", "e", "a1", true, "", "t", 10),
            TestResult("Merge Test — B", "m", "e", "b1", true, "", "t", 20),
            TestResult("Merge Test — C", "m", "e", "c1", null, "", "t", 30)
        )
        val fresh = TestResult("Merge Test — B", "m", "e", "b2", false, "دلیل تازه", "t2", 99)
        val merged = Lab.mergeRerun(base, fresh)
        assertEquals(3, merged.size)
        assertEquals(base[0], merged[0])
        assertEquals(base[2], merged[2])
        assertEquals(fresh, merged[1])
    }

    @Test fun mergeRerun_appendsUnknownTest() {
        val base = listOf(
            TestResult("Merge Test — A", "m", "e", "a1", true, "", "t", 10),
            TestResult("Merge Test — B", "m", "e", "b1", true, "", "t", 20)
        )
        val appended = Lab.mergeRerun(base, TestResult("Merge Test — D", "m", "e", "d1", true, "", "t", 5))
        assertEquals(3, appended.size)
        assertEquals(base, appended.take(2))
        assertEquals("Merge Test — D", appended[2].name)
    }

    @Test fun groupBadge_rules() {
        assertEquals("PASS", Lab.groupBadge(listOf(badgeRes("A", true), badgeRes("B", true))).first)
        assertEquals("FAIL", Lab.groupBadge(listOf(badgeRes("A", true), badgeRes("B", false), badgeRes("C", true))).first)
        assertEquals("PARTIAL", Lab.groupBadge(listOf(badgeRes("A", true), badgeRes("B", null))).first)
        assertEquals("NOT TESTED", Lab.groupBadge(listOf(badgeRes("A", null), badgeRes("B", null))).first)
        assertEquals("NOT TESTED", Lab.groupBadge(emptyList()).first)
        assertEquals("FAIL", Lab.groupBadge(listOf(badgeRes("A", false), badgeRes("B", null))).first)
        // Cross-check (v2.9.6 bug): badge must come from the COMPLETE list.
        val groupA = listOf(badgeRes("Restore — A", true), badgeRes("Restore — B", false))
        val groupB = listOf(badgeRes("Large-RAM — A", true), badgeRes("Large-RAM — B", true))
        assertEquals("FAIL", Lab.groupBadge(groupA).first)
        assertEquals("PASS", Lab.groupBadge(groupB).first)
        assertEquals("FAIL", Lab.groupBadge(groupA + groupB).first)
    }

    @Test fun runAllSummary_rules() {
        val full = Lab.runAllSummary(listOf(badgeRes("A", true), badgeRes("B", true), badgeRes("C", true)))
        assertTrue(full.complete)
        assertEquals(3, full.total)
        assertEquals(3, full.passed)
        assertEquals(0, full.failed)
        assertEquals(0, full.untested)
        assertEquals(0, full.timeouts)
        val withUntested = Lab.runAllSummary(listOf(badgeRes("A", true), badgeRes("B", null), badgeRes("C", true)))
        assertFalse(withUntested.complete)
        assertEquals(1, withUntested.untested)
        val withTimeout = Lab.runAllSummary(
            listOf(TestResult("G — تایم‌اوت", "m", "e", "a", false, "TIMEOUT", "t", 1), badgeRes("H", true))
        )
        assertFalse(withTimeout.complete)
        assertEquals(1, withTimeout.timeouts)
        // The reported case: 217 total, 189 pass, 20 fail, 8 untested.
        val reported = (1..189).map { badgeRes("P$it", true) } +
            (1..20).map { badgeRes("F$it", false) } +
            (1..8).map { badgeRes("S$it", null) }
        val sumReported = Lab.runAllSummary(reported)
        assertEquals(217, sumReported.total)
        assertEquals(189, sumReported.passed)
        assertEquals(20, sumReported.failed)
        assertEquals(8, sumReported.untested)
        assertFalse(sumReported.complete)
        assertFalse(Lab.runAllSummary(emptyList()).complete)
    }

    // ---- Quality score / coverage gate / widget status ----

    @Test fun qualityScore_allValid() {
        val q1 = Quality.compute(40.0, 3.0, 0.0, 100)
        assertTrue(q1 is Quality.ScoreResult.Complete)
        assertEquals(100, (q1 as Quality.ScoreResult.Complete).total)
        assertEquals(1.0, q1.coverage, 0.0)
    }

    @Test fun qualityScore_missingPingIsInsufficient() {
        val q2 = Quality.compute(0.0, 3.0, 0.0, 100, pingValid = false)
        assertTrue(q2 is Quality.ScoreResult.InsufficientData)
        assertEquals(0.6, (q2 as Quality.ScoreResult.InsufficientData).coverage, 0.0)
    }

    @Test fun qualityScore_missingJitterNormalizes() {
        // 52/80 normalized -> total 65, coverage 80%.
        val q3 = Quality.compute(100.0, 0.0, 2.0, 85, jitterValid = false)
        assertTrue(q3 is Quality.ScoreResult.Complete)
        assertEquals(65, (q3 as Quality.ScoreResult.Complete).total)
        assertEquals(0.8, q3.coverage, 0.0)
    }

    @Test fun qualityScore_multipleMissingAndNone() {
        val q4 = Quality.compute(0.0, 0.0, 0.0, 90, pingValid = false, jitterValid = false)
        assertTrue(q4 is Quality.ScoreResult.InsufficientData)
        assertEquals(0.4, (q4 as Quality.ScoreResult.InsufficientData).coverage, 0.0)
        val q5 = Quality.compute(0.0, 0.0, 0.0, 0, pingValid = false, jitterValid = false, lossValid = false, stabValid = false)
        assertTrue(q5 is Quality.ScoreResult.NotAvailable)
    }

    @Test fun qualityScore_zeroAvgIsNA() {
        val q6 = Quality.compute(0.0, 3.0, 0.0, 100)
        assertTrue(q6 is Quality.ScoreResult.InsufficientData)
        assertEquals(null, (q6 as Quality.ScoreResult.InsufficientData).parts.ping)
    }

    @Test fun coverageGate_boundaries() {
        assertTrue(Quality.coverageGate(70, 100))
        assertFalse(Quality.coverageGate(69, 100))
        assertTrue(Quality.coverageGate(100, 100))
        assertFalse(Quality.coverageGate(0, 0))
    }

    @Test fun widgetStatus_oneVocabulary() {
        assertEquals("Connected", Quality.widgetStatus(85, "Complete"))
        assertEquals("Degraded", Quality.widgetStatus(60, "Complete"))
        assertEquals("Offline", Quality.widgetStatus(30, "Complete"))
        assertEquals("Degraded", Quality.widgetStatus(null, "InsufficientData"))
    }

    @Test fun sharedPingTable_gamingEqualsQuality() {
        // For any ping, Gaming's latency part must equal Quality's ping
        // part scaled 35/40 (rounded). Same cutoffs, same relative score.
        val sharedOk = listOf(30.0, 60.0, 100.0, 150.0, 250.0).all { ms ->
            val qp = Quality.pingPoints(ms, 40)
            val prx = PingResult("test", 20, 20, 0.0, ms, ms, ms, ms, ms, ms, ms, 0.0, 0, 0, listOf(ms))
            val gs = Gaming.score(prx, Gaming.Bufferbloat(ms, ms, 0.0, "A", 100))
            gs.latency == (qp * 35 + 20) / 40
        }
        assertTrue(sharedOk)
    }

    @Test fun percentile_agreementLabAndGaming() {
        val pct100 = (1..100).map { it.toDouble() }
        assertEquals(50.0, Lab.computeStats(pct100, 100).p50, 0.0)
        assertEquals(95.0, Lab.computeStats(pct100, 100).p95, 0.0)
        assertEquals(50.0, Gaming.percentile(pct100, 50.0), 0.0)
        assertEquals(90.0, Gaming.percentile(pct100, 90.0), 0.0)
        assertEquals(95.0, Gaming.percentile(pct100, 95.0), 0.0)
        assertEquals(99.0, Gaming.percentile(pct100, 99.0), 0.0)
    }

    // ---- Gaming score / bufferbloat ----

    private fun perfectPing() = PingResult("test", 20, 20, 0.0, 40.0, 40.0, 45.0, 40.0, 41.0, 42.0, 44.0, 3.0, 0, 0, listOf(40.0))

    @Test fun gamingScore_perfect() {
        val sc = Gaming.score(perfectPing(), Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100))
        assertEquals(100, sc.total)
    }

    @Test fun gamingScore_bad() {
        val bad = PingResult("test", 20, 10, 50.0, 100.0, 200.0, 400.0, 180.0, 300.0, 350.0, 390.0, 50.0, 8, 3, listOf(200.0))
        val sc2 = Gaming.score(bad, Gaming.Bufferbloat(200.0, 400.0, 200.0, "F", 20))
        assertTrue(sc2.total != null && sc2.total < 40)
    }

    @Test fun gamingScore_noBufferbloatIsNull() {
        assertEquals(null, Gaming.score(perfectPing(), null).total)
        assertEquals(100, Gaming.score(perfectPing(), Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100)).total)
    }

    @Test fun bufferbloatGrade() {
        assertEquals("A", Gaming.bufferbloatGradeForTest(48.0, 60.0).first) // +12ms
        assertEquals("D", Gaming.bufferbloatGradeForTest(48.0, 180.0).first) // +132ms
    }

    // ---- ChartData (pure java, no Android) ----

    @Test fun chartStats_cases() {
        val now = System.currentTimeMillis()
        val cdEmpty = ChartData.stats(emptyList())
        assertEquals(0, cdEmpty.valid)
        assertEquals(0.0, cdEmpty.min, 0.0)
        assertEquals(0.0, cdEmpty.avg, 0.0)
        assertEquals(0.0, cdEmpty.max, 0.0)
        val cdOne = ChartData.stats(listOf(now to 42.0))
        assertEquals(42.0, cdOne.min, 0.0)
        assertEquals(42.0, cdOne.avg, 0.0)
        assertEquals(42.0, cdOne.max, 0.0)
        val cdTwo = ChartData.stats(listOf(now to 40.0, now + 5000 to 60.0))
        assertEquals(40.0, cdTwo.min, 0.0)
        assertEquals(50.0, cdTwo.avg, 0.0)
        assertEquals(60.0, cdTwo.max, 0.0)
        val sixty = (0 until 60).map { now + it * 1000L to (40.0 + it) }
        val cd60 = ChartData.stats(sixty)
        assertEquals(60, cd60.valid)
        assertEquals(40.0, cd60.min, 0.0)
        assertEquals(69.5, cd60.avg, 0.0)
        assertEquals(99.0, cd60.max, 0.0)
        val over = (0 until 120).map { now + it * 1000L to 50.0 }
        val cdOver = ChartData.stats(over)
        assertEquals(120, cdOver.valid)
        assertEquals(50.0, cdOver.avg, 0.0)
    }

    @Test fun chartStats_irregularFailedNaN() {
        val now = System.currentTimeMillis()
        val irregular = listOf(now to 50.0, now + 137000 to 60.0, now + 900000 to 70.0)
        assertEquals(60.0, ChartData.stats(irregular).avg, 0.0)
        val withFail = listOf(now to 40.0, now + 1000 to -1.0, now + 2000 to 50.0, now + 3000 to -1.0, now + 4000 to 60.0)
        assertEquals(3, ChartData.segments(withFail).size)
        val cdFail = ChartData.stats(withFail)
        assertEquals(2, cdFail.failed)
        assertEquals(50.0, cdFail.avg, 0.0)
        val nanPts = listOf(now to 40.0, now + 1000 to Double.NaN, now + 2000 to 60.0)
        val cdNan = ChartData.stats(nanPts)
        assertEquals(2, cdNan.valid)
        assertEquals(1, cdNan.failed)
    }

    @Test fun chartYMax_outlierDoesNotFlattenChart() {
        val now = System.currentTimeMillis()
        val outlier = (0 until 20).map { now + it * 1000L to 50.0 } + listOf(now + 21000 to 986.0)
        assertEquals(100.0, ChartData.yMax(outlier.map { it.second }), 0.0) // P95=50 -> yMax=100, not 986*1.2
    }

    @Test fun chartInRange_filters() {
        val now = System.currentTimeMillis()
        val day = 24L * 3600 * 1000
        val mixed = listOf(now - 40 * day to 40.0, now - 5 * day to 50.0, now - 1 * 3600 * 1000 to 60.0, now to 70.0)
        assertEquals(2, ChartData.inRange(mixed, now - day).size)
        assertEquals(3, ChartData.inRange(mixed, now - 7 * day).size)
        assertEquals(3, ChartData.inRange(mixed, now - 30 * day).size)
    }

    @Test fun chartTimeLabels_secondResolution() {
        // 1_700_000_000_000L = 22:13:20 UTC; +30s is still the same minute,
        // so HH:mm would give identical labels — HH:mm:ss must differ.
        val lblT0 = 1_700_000_000_000L
        val lblT1 = lblT0 + 30_000L
        val oldFmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US)
        assertEquals(oldFmt.format(java.util.Date(lblT0)), oldFmt.format(java.util.Date(lblT1)))
        val labels = ChartData.timeLabels(lblT0, lblT1)
        assertTrue(labels.size >= 2)
        assertFalse(labels.first() == labels.last())
        assertTrue(labels.all { it.matches(Regex("\\d{2}:\\d{2}:\\d{2}")) })
        assertEquals(1, ChartData.timeLabels(lblT0, lblT0).size)
        val lblLong = ChartData.timeLabels(lblT0, lblT0 + 90_000L)
        assertTrue(lblLong.size in 2..3)
        assertFalse(lblLong.first() == lblLong.last())
        val lblMid = ChartData.timeLabels(lblT0, lblT0 + 60_000L)
        assertTrue(lblMid.size >= 2)
        assertFalse(lblMid.first() == lblMid.last())
    }

    @Test fun chartValues_scaled0to100() {
        val chart = listOf(42.0, 48.0, 72.0).map { (it / 2).toInt().coerceIn(0, 100) }
        assertEquals(listOf(21, 24, 36), chart)
    }

    // ---- History pure parsers / ranges (no Context) ----

    @Test fun historyParseSample_oldAndNew() {
        val sOld = History.parseSample("1700000000000,35,40")
        assertTrue(sOld != null && sOld.avgMs == -1.0 && sOld.lossPct == -1.0)
        val sNew = History.parseSample("1700000000000,35,40,120.5,8.2,0.0")
        assertTrue(sNew != null && sNew.avgMs == 120.5 && sNew.jitterMs == 8.2)
    }

    @Test fun historyParseTimeline() {
        val evs = History.parseTimeline("12:30 [outage-start] شروع اختلال در 12:30 — دسترسی ۳۰٪\n12:45 [network-change] تغییر شبکه")
        assertEquals(2, evs.size)
        assertEquals("outage-start", evs[0].kind)
        assertEquals("12:45", evs[1].time)
    }

    @Test fun historyRange_millisAndCutoff() {
        assertEquals(24L * 60 * 60 * 1000, History.HistoryRange.H24.millis)
        assertEquals(7L * 24 * 60 * 60 * 1000, History.HistoryRange.D7.millis)
        assertEquals(30L * 24 * 60 * 60 * 1000, History.HistoryRange.D30.millis)
        val fixedNow = 1_700_000_000_000L
        assertEquals(fixedNow - 86_400_000L, History.HistoryRange.H24.cutoff(fixedNow))
        assertEquals(fixedNow - 604_800_000L, History.HistoryRange.D7.cutoff(fixedNow))
        assertEquals(fixedNow - 2_592_000_000L, History.HistoryRange.D30.cutoff(fixedNow))
    }

    @Test fun historyRange_selectionWithFixedTimestamps() {
        val fixedNow = 1_700_000_000_000L
        val h = 3_600_000L
        val d = 24 * h
        val pts = listOf(fixedNow - 1 * h to 40.0, fixedNow - 25 * h to 50.0, fixedNow - 8 * d to 60.0, fixedNow - 31 * d to 70.0)
        fun inRangeCount(range: History.HistoryRange): Int = pts.count { it.first >= range.cutoff(fixedNow) }
        assertEquals(1, inRangeCount(History.HistoryRange.H24))
        assertEquals(2, inRangeCount(History.HistoryRange.D7))
        assertEquals(3, inRangeCount(History.HistoryRange.D30))
    }

    @Test fun staleSidecarAction_onlyAfterCleanOpenAndCheck() {
        assertTrue(History.staleSidecarAction(true, true, true))
        assertFalse(History.staleSidecarAction(false, true, true))
        assertFalse(History.staleSidecarAction(true, false, true))
        assertFalse(History.staleSidecarAction(true, true, false))
    }

    // ---- Diagnostics.dnsTime IP literal (early return, no network) ----

    @Test fun dnsTime_ipLiteralIsNA() {
        val dnsIp = Diagnostics.dnsTime("1.1.1.1")
        assertFalse(dnsIp.ok)
        assertTrue(dnsIp.note.contains("N/A"))
    }

    // ---- AnalyticsEngine delegates (same values as the direct calls) ----

    @Test fun analyticsEngine_delegatesMatchDirectCalls() {
        val pr = perfectPing()
        val aeScore = AnalyticsEngine.gamingScore(pr, Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100))
        assertEquals(100, aeScore.total)
        assertEquals(Gaming.score(pr, Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100)).total, aeScore.total)
        val aeQ = AnalyticsEngine.qualityScore(40.0, 3.0, 0.0, 100)
        assertTrue(aeQ is Quality.ScoreResult.Complete)
        assertEquals(100, (aeQ as Quality.ScoreResult.Complete).total)
        val aeStats = AnalyticsEngine.burstStats(listOf(42.0, 48.0, 50.0, 55.0, 72.0), 5)
        assertEquals(53.4, aeStats.avg, 0.0)
        val now = System.currentTimeMillis()
        val aeChart = AnalyticsEngine.chartStats(listOf(now to 40.0, now + 1000 to -1.0, now + 2000 to 60.0))
        assertEquals(1, aeChart.failed)
        assertEquals(50.0, aeChart.avg, 0.0)
    }
}
