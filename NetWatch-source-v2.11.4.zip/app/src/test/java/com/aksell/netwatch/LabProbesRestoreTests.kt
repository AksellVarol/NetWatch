package com.aksell.netwatch

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// Lab pure-logic tests, part 2: DoH JSON parsing (Probes) and the
// RestoreStream pure helpers. JVM unit tests — no Android, no network,
// no Context, no SQLite.
//
// Mirror of the matching assertions in Lab.unitTests() (Lab.kt, v2.9.5 /
// v2.9.4). Probes.parseDohJson is deliberately regex-based, NOT org.json,
// so it runs on the JVM where android.jar's org.json is a stub that
// throws (see the comment above parseDohJson in Probes.kt).
// RestoreStream.isIntegerLiteral / decideRecovery / exceedsCap /
// readBounded touch only kotlin/java.io — the Android JsonReader path
// (streamIntoStaging) is NOT exercised here; it stays on-device.
//
// Requires (build.gradle belongs to another group — NOT added here):
//   testImplementation "junit:junit:4.13.2"
class LabProbesRestoreTests {

    // ---- Probes.parseDohJson ----

    @Test fun dohParse_validAnswer() {
        val good = Probes.parseDohJson(
            "{\"Status\":0,\"TC\":false,\"RD\":true,\"RA\":true,\"AD\":false,\"CD\":false," +
                "\"Question\":[{\"name\":\"google.com.\",\"type\":1}]," +
                "\"Answer\":[{\"name\":\"google.com.\",\"type\":1,\"TTL\":300,\"data\":\"142.250.180.14\"}]}"
        )
        assertTrue(good.ok)
        assertEquals(listOf("142.250.180.14"), good.answers)
    }

    @Test fun dohParse_rejectsNonZeroStatus() {
        val bad = Probes.parseDohJson("{\"Status\":2,\"Answer\":[]}")
        assertFalse(bad.ok)
        assertTrue(bad.error.contains("Status=2"))
    }

    @Test fun dohParse_rejectsMissingOrEmptyAnswer() {
        assertFalse(Probes.parseDohJson("{\"Status\":0}").ok)
        assertFalse(Probes.parseDohJson("{\"Status\":0,\"Answer\":[]}").ok)
    }

    @Test fun dohParse_rejectsCnameOnly() {
        val cname = Probes.parseDohJson(
            "{\"Status\":0,\"Answer\":[{\"name\":\"x.\",\"type\":5,\"TTL\":300,\"data\":\"y.example.\"}]}"
        )
        assertFalse(cname.ok) // only a CNAME (type 5) — no A record
    }

    @Test fun dohParse_rejectsBrokenJson() {
        assertFalse(Probes.parseDohJson("{bad json").ok)
    }

    // Strict IPv4 in DoH A records: each case is its own assertion —
    // a record with an invalid IP fails with the IP error.
    private fun dohIp(data: String) = Probes.parseDohJson(
        "{\"Status\":0,\"Answer\":[{\"name\":\"google.com.\",\"type\":1,\"TTL\":300,\"data\":\"$data\"}]}"
    )

    @Test fun dohParse_ipv4Cases() {
        val valid = dohIp("142.250.72.14")
        assertTrue(valid.ok)
        assertEquals(listOf("142.250.72.14"), valid.answers)
        val range = dohIp("999.1.1.1")
        assertFalse(range.ok)
        assertTrue(range.error.contains("IP نامعتبر"))
        val nonIp = dohIp("not-an-ip")
        assertFalse(nonIp.ok)
        assertTrue(nonIp.error.contains("IP نامعتبر"))
        assertFalse(dohIp("1.2.3").ok) // incomplete
        assertFalse(dohIp("1.2.3.4.5").ok) // extra part
        val empty = dohIp("")
        assertFalse(empty.ok)
        assertTrue(empty.error.contains("IP نامعتبر"))
        assertFalse(dohIp("01.2.3.4").ok) // leading zero
    }

    // ---- RestoreStream pure helpers ----

    private fun bounded(bytes: ByteArray, limit: Long): String {
        return try {
            val got = RestoreStream.readBounded(java.io.ByteArrayInputStream(bytes), limit)
            "ok:${got.size}"
        } catch (e: RestoreStream.SizeLimitExceeded) {
            "over-limit"
        }
    }

    @Test fun boundedReader_limits() {
        assertEquals("ok:100", bounded(ByteArray(100), 1000))
        assertEquals("ok:1000", bounded(ByteArray(1000), 1000)) // exactly at cap: accepted
        assertEquals("over-limit", bounded(ByteArray(1001), 1000))
        assertEquals("ok:65536", bounded(ByteArray(65536), 65536))
        assertEquals("over-limit", bounded(ByteArray(65537), 65536)) // chunk boundary
        assertEquals("ok:0", bounded(ByteArray(0), 1000))
        assertEquals("over-limit", bounded(ByteArray(1), 0))
    }

    @Test fun integerLiteral_form() {
        // "1" ok; "1.0", "1e3", "01", "+1", "\"1\"" rejected.
        val cases = listOf(
            "1" to true, "0" to true, "-5" to true, "-0" to true, "123456789" to true,
            "1.0" to false, "1e3" to false, "1E3" to false, "01" to false, "+1" to false, "\"1\"" to false,
            "" to false, " 1" to false, "1 " to false, "1.5e-3" to false, "--1" to false
        )
        for ((lit, want) in cases) {
            assertEquals("isIntegerLiteral(\"$lit\")", want, RestoreStream.isIntegerLiteral(lit))
        }
    }

    @Test fun recoveryDecisionTable() {
        val cases = listOf(
            Triple(null as String?, false, RestoreStream.RecoveryAction.NOTHING),
            Triple(null, true, RestoreStream.RecoveryAction.CLEAN_STAGING),
            Triple("STARTED", false, RestoreStream.RecoveryAction.ROLLBACK),
            Triple("STARTED", true, RestoreStream.RecoveryAction.ROLLBACK),
            Triple("COMMITTED", false, RestoreStream.RecoveryAction.ROLL_FORWARD),
            Triple("COMMITTED", true, RestoreStream.RecoveryAction.ROLL_FORWARD),
            Triple("GARBAGE", false, RestoreStream.RecoveryAction.NOTHING),
            Triple("GARBAGE", true, RestoreStream.RecoveryAction.CLEAN_STAGING)
        )
        for ((state, staging, want) in cases) {
            assertEquals("decideRecovery($state, $staging)", want, RestoreStream.decideRecovery(state, staging))
        }
    }

    @Test fun exceedsCap_knownSizeOnly() {
        assertFalse(RestoreStream.exceedsCap(null, 100)) // unknown -> rely on the during-read bound
        assertFalse(RestoreStream.exceedsCap(100, 100)) // exactly at cap
        assertTrue(RestoreStream.exceedsCap(101, 100))
        assertFalse(RestoreStream.exceedsCap(0, 0))
    }

    @Test fun restoreMaxBytes_is50MiB() {
        assertEquals(50L * 1024 * 1024, History.RESTORE_MAX_BYTES)
    }
}
