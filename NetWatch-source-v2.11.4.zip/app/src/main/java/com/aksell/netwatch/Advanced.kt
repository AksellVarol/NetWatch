package com.aksell.netwatch

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL

// Honest advanced diagnostics. Anything Android cannot measure is returned as Unknown, never faked.
object Advanced {
    data class Captive(val result: String)
    fun captivePortal(): Captive {
        var c: HttpURLConnection? = null
        return try {
            // عمداً HTTP است (چک captive portal باید HTTP باشد) و در
            // network_security_config.xml برای همین دامنه مجاز شده است.
            c = URL("http://connectivitycheck.gstatic.com/generate_204").openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000; c.instanceFollowRedirects = false
            val code = c.responseCode
            when (code) { 204 -> Captive("✅ No captive portal (204)"); 200 -> Captive("⚠️ پاسخ 200 — احتمال Captive Portal یا پروکسی"); else -> Captive("⚠️ کد $code — احتمال Captive Portal / redirect") }
        } catch (e: Exception) { Captive("نامشخص — ${e.javaClass.simpleName} (ممکن است فیلتر باشد، نه Captive Portal)") }
        finally { try { c?.disconnect() } catch (_: Exception) { /* disconnect در finally است؛ خطا یعنی اتصال از پیش بسته شده. */ } }
    }

    fun publicIpChange(ctx: Context): String {
        val g = Geo.fetch(ctx)
        if (!g.ok || g.ip.isBlank()) return "لوکیشن آی‌پی در دسترس نیست"
        val old = History.lastIp(ctx)
        History.setLastIp(ctx, g.ip)
        return if (old.isBlank()) "IP عمومی فعلی: ${g.ip} (${g.city}, ${g.country}) — اولین ثبت"
        else if (old == g.ip) "IP عمومی بدون تغییر: ${g.ip}"
        else "⚠️ IP عمومی عوض شد: $old ← ${g.ip}"
    }

    // NAT type needs a STUN server exchange; Android has no built-in STUN API and no bundled STUN client.
    fun natType(): String = "NAT Type: Unknown — برای تشخیص دقیق NAT به STUN نیاز است؛ در این نسخه STUN پیاده نشده و عددی حدس زده نمی‌شود."

    fun portTest(host: String, port: Int): String {
        val t = Diagnostics.tcpTime(host, port)
        return "TCP $host:$port — ${if (t.ok) "✅ باز (${t.ms}ms)" else "❌ ${t.note}"}"
    }

    // Micro-lag: spikes in a short 10-packet burst; loaded jitter: jitter of ping while downloading.
    fun microLag(): String {
        val r = Gaming.pingHost("1.1.1.1", 10)
        return "Micro-lag (۱۰ بسته): میانگین ${"%.0f".format(r.avgMs)}ms • اسپایک ${r.spikes} • جیتر ${"%.1f".format(r.jitterMs)}ms • Burst Loss ${r.burstLoss}"
    }
    // RTT تحت بار (نه جیتر): میانگین RTT پینگ در حالی که دانلود در جریان
    // است. نام قدیمی loadedJitter گمراه‌کننده بود — این تابع جیتر را
    // اندازه نمی‌گیرد، RTT تحت بار را نشان می‌دهد.
    fun loadedRtt(): String {
        val bb = Gaming.bufferbloat()
        return "RTT تحت بار: Idle ${"%.0f".format(bb.idleMs)}ms • Loaded ${"%.0f".format(bb.loadedMs)}ms • افزایش ${"%.0f".format(bb.increaseMs)}ms • درجه ${bb.grade}"
    }
    // Packet reordering cannot be measured with the system ping command (no sequence timing exposed) — say so.
    fun reordering(): String = "Packet Reordering: نامشخص — دستور ping سیستم زمان‌بندی توالی بسته‌ها را نمی‌دهد؛ بدون Raw Socket (نیاز به Root) قابل اندازه‌گیری دقیق نیست."
}
