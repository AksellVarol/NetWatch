package com.aksell.netwatch

import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future

// One managed executor for ALL network and heavy work in the app (v2.6).
// - Fixed small pool (4 threads): no unbounded thread creation and no new
//   Thread per 5-second tick anywhere in the app.
// - Every task runs off the main thread; results come back via runOnMain.
// - Callers keep the returned Future to cancel a running check (Stop button,
//   leaving a screen, starting a new check while one runs).
object NetExecutor {
    private const val TAG = "NetExecutor"
    private val pool: ExecutorService = Executors.newFixedThreadPool(4) { r ->
        Thread(r, "netwatch-net").apply { isDaemon = true }
    }
    // Dedicated single-thread pool for backup/restore file I/O + parsing
    // (v2.9.4, P0-2): a long restore must never starve the 4 network
    // threads or run on the main thread. Serialises restores by construction.
    private val restorePool: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "netwatch-restore").apply { isDaemon = true }
    }
    // Dedicated probe pool (v2.11.2, issue 4): probe fan-out runs here (8
    // threads), NOT on the shared 4-thread pool. The old code submitted 41
    // probes to the 4-thread pool and blocked the calling thread (itself a
    // pool thread) in awaitProbes, so only ~3 threads were left for 41
    // probes and the tail of the queue timed out spuriously. The caller
    // still blocks in awaitProbes, but it no longer holds a probe-pool
    // thread while doing so, and the pool is wide enough for the fan-out.
    private val probePool: ExecutorService = Executors.newFixedThreadPool(8) { r ->
        Thread(r, "netwatch-probe").apply { isDaemon = true }
    }
    // Dedicated pools (v2.11.4, NW-008): long, user-triggered jobs must
    // never sit on the shared 4-thread pool and starve MonitorService.
    // - labPool (2 threads, LAB only): one LAB section can hold a thread
    //   for up to 720s; it must not eat the network pool. LabActivity
    //   itself belongs to another group and still calls submit() — that
    //   group must switch its runSection to submitLab.
    // - benchPool (1 thread, DNS benchmark only): serial by construction,
    //   so two benchmark taps can never run in parallel.
    // - speedPool (3 threads, SpeedTest only): the caller holds 1 thread
    //   while the 2 parallel Range/POST halves hold the other 2, so the
    //   nested get(30s) can never block against the 4-thread pool.
    private val labPool: ExecutorService = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "netwatch-lab").apply { isDaemon = true }
    }
    private val benchPool: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "netwatch-bench").apply { isDaemon = true }
    }
    private val speedPool: ExecutorService = Executors.newFixedThreadPool(3) { r ->
        Thread(r, "netwatch-speed").apply { isDaemon = true }
    }
    fun submitLab(task: () -> Unit): Future<*> = labPool.submit(wrap(task))
    fun submitBench(task: () -> Unit): Future<*> = benchPool.submit(wrap(task))
    fun submitSpeed(task: () -> Unit): Future<*> = speedPool.submit(wrap(task))
    fun <T> submitSpeedCallable(task: () -> T): Future<T> = speedPool.submit(wrapCallable(task))
    fun submitRestore(task: () -> Unit): Future<*> = restorePool.submit(wrap(task))
    // Lazy: creating the main-thread Handler touches Looper.getMainLooper(),
    // which must only happen on a real device. Background-only callers
    // (submit/cancel) never pay for it, and JVM unit tests can use the pool.
    private val mainHandler by lazy { Handler(Looper.getMainLooper()) }

    // Issue 16: a task that throws used to vanish silently inside its
    // Future — the crash handler never saw it. Every task is wrapped so
    // the failure is logged (android.util.Log, NOT Bridge — Bridge would
    // recurse back here) and then rethrown, so the Future still holds it.
    private fun wrap(task: () -> Unit): () -> Unit = {
        try { task() } catch (e: Exception) { Log.e(TAG, "background task failed", e); throw e }
    }
    private fun <T> wrapCallable(task: () -> T): Callable<T> = Callable {
        try { task() } catch (e: Exception) { Log.e(TAG, "background task failed", e); throw e }
    }
    private fun wrapRunnable(r: Runnable): Runnable = Runnable {
        try { r.run() } catch (e: Exception) { Log.e(TAG, "background task failed", e); throw e }
    }

    fun submit(task: () -> Unit): Future<*> = pool.submit(wrap(task))
    // Execute a pre-built Runnable (e.g. a FutureTask whose identity must be
    // known BEFORE it is submitted — see NetworkEngine.submitSingle). The
    // pool still owns the thread; nothing here creates a new thread.
    fun execute(r: Runnable) { pool.execute(wrapRunnable(r)) }
    fun <T> submitCallable(task: () -> T): Future<T> = pool.submit(wrapCallable(task))
    fun runOnMain(task: () -> Unit) { mainHandler.post(task) }
    fun cancel(f: Future<*>?) { try { f?.cancel(true) } catch (e: Exception) {} }

    // Probe fan-out (issue 4): probes go to the dedicated 8-thread pool.
    // Returns null only if the pool rejected the task (e.g. shut down);
    // callers treat a null/missing result as a "تایم‌اوت" entry.
    fun submitProbe(task: () -> Unit): Future<*>? {
        return try { probePool.submit(wrap(task)) } catch (e: Exception) { Log.e(TAG, "probe submit failed", e); null }
    }
    fun cancelProbe(f: Future<*>?) { try { f?.cancel(true) } catch (e: Exception) {} }
}
