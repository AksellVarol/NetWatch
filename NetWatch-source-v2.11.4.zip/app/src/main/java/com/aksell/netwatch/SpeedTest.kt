package com.aksell.netwatch

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

// Manual Speed Test (v2.11.0 Phase 1). Runs ONLY when the user taps the button
// (after a data warning) — never automatic, never continuous. Download AND
// upload are real measurements against speed.cloudflare.com; the result
// stores the ACTUAL counted bytes, and the card shows the measured data
// consumption. No fake numbers: before any real test every value is "—".
object SpeedTest {
    const val DOWNLOAD_URL = "https://speed.cloudflare.com/__down?bytes=50000000"
    const val WARMUP_URL = "https://speed.cloudflare.com/__down?bytes=1000000"
    const val UPLOAD_URL = "https://speed.cloudflare.com/__up"
    const val MAX_DOWNLOAD_BYTES = 50_000_000L
    const val MAX_UPLOAD_BYTES = 20_000_000L
    const val MAX_TEST_MS = 10_000L
    const val BUFFER_SIZE = 64 * 1024
    const val PREFS_NAME = "speedtest"
    const val PREF_KEY = "speed_last"

    data class SpeedResult(
        val downloadMbps: Double,
        val uploadMbps: Double,
        val bytesDownloaded: Long,
        val bytesUploaded: Long,
        val timestampMs: Long
    )

    // Pure: bytes * 8 bits / seconds / 1e6. Non-positive input is "no measurement" -> 0.0.
    fun throughputMbps(bytes: Long, elapsedMs: Long): Double {
        if (bytes <= 0 || elapsedMs <= 0) return 0.0
        return bytes * 8.0 / (elapsedMs / 1000.0) / 1_000_000.0
    }

    // Prefs format (v2.11.0): dl|ul|bytesDown|bytesUp|ts — all five fields,
    // so the real data consumption survives a restart.
    fun formatResult(r: SpeedResult): String =
        "${r.downloadMbps}|${r.uploadMbps}|${r.bytesDownloaded}|${r.bytesUploaded}|${r.timestampMs}"

    fun parseResult(raw: String?): SpeedResult? {
        if (raw.isNullOrBlank()) return null
        val p = raw.split("|")
        if (p.size != 5) return null
        val dl = p[0].toDoubleOrNull() ?: return null
        val ul = p[1].toDoubleOrNull() ?: return null
        val down = p[2].toLongOrNull() ?: return null
        val up = p[3].toLongOrNull() ?: return null
        val ts = p[4].toLongOrNull() ?: return null
        if (dl < 0 || ul < 0 || down < 0 || up < 0 || ts < 0) return null
        return SpeedResult(dl, ul, down, up, ts)
    }

    fun saveResult(ctx: Context, r: SpeedResult) {
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(PREF_KEY, formatResult(r)).apply()
    }

    fun loadResult(ctx: Context): SpeedResult? =
        parseResult(ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(PREF_KEY, null))

    // Display helpers: "—" means "not measured yet", never a made-up number.
    fun formatSpeed(mbps: Double): String =
        if (mbps <= 0.0 || !mbps.isFinite()) "—" else "%.1f Mbps".format(mbps)

    fun formatDataUsage(bytesDownloaded: Long, bytesUploaded: Long): String {
        val totalMb = (bytesDownloaded + bytesUploaded) / 1_000_000.0
        return "مصرف داده: %.1f مگابایت".format(totalMb)
    }

    fun formatTestTime(ts: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ts))

    // Download (issue 23): warm-up + 2 parallel Range connections, timer
    // from the first byte read to the last byte read. Returns (actual bytes
    // read, elapsed ms). Call only on a background thread. Throws on
    // network failure (caller shows "ناموفق").
    // - Warm-up: one small (~1 MB) GET, NOT counted, so TCP slow-start
    //   does not pollute the measurement.
    // - Parallel: two connections, each one half of the 50 MB file via
    //   HTTP Range. If the server does not answer 206 to a Range request,
    //   falls back to a single connection (same first-byte timer).
    // - The timer starts at the first byte actually read (not at connect)
    //   and ends at the last byte read, across both connections.
    fun runDownload(): Pair<Long, Long> {
        // Warm-up is best-effort: if it fails, the test still runs.
        try {
            val wconn = URL(WARMUP_URL).openConnection() as HttpURLConnection
            wconn.connectTimeout = 10_000
            wconn.readTimeout = 10_000
            try {
                wconn.connect()
                wconn.inputStream.use { ins ->
                    val buf = ByteArray(BUFFER_SIZE)
                    var warm = 0L
                    while (warm < 1_000_000L) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        warm += n
                    }
                }
            } finally {
                wconn.disconnect()
            }
        } catch (_: Exception) { /* warm-up failed — measure anyway */ }

        val half = MAX_DOWNLOAD_BYTES / 2
        // NW-008: the halves run on the dedicated 3-thread speedPool, NOT
        // the shared 4-thread pool — the caller below blocks in get(30s)
        // while the halves run, so on the shared pool a busy moment could
        // time the halves out and fail the test for no reason.
        val futures = listOf(0L to half - 1, half to MAX_DOWNLOAD_BYTES - 1).map { (from, to) ->
            NetExecutor.submitSpeedCallable { downloadRange(from, to) }
        }
        val halves = mutableListOf<HalfDownload>()
        var parallelOk = true
        for (f in futures) {
            try {
                val h = f.get(30, TimeUnit.SECONDS)
                if (!h.rangeOk) parallelOk = false
                halves.add(h)
            } catch (_: Exception) {
                parallelOk = false
                try { f.cancel(true) } catch (_: Exception) { /* لغو task ناموفق بود — task در حال تمام‌شدن است و parallelOk از پیش false شده. */ }
            }
        }
        if (parallelOk && halves.size == 2) {
            val bytes = halves.sumOf { it.bytes }
            val first = halves.minOf { it.firstByteNs }
            val last = halves.maxOf { it.lastByteNs }
            val elapsedMs = if (first <= 0L || last <= first) 0L else (last - first) / 1_000_000L
            return bytes to elapsedMs
        }
        return downloadSingle()
    }

    private data class HalfDownload(val bytes: Long, val firstByteNs: Long, val lastByteNs: Long, val rangeOk: Boolean)

    private fun downloadRange(from: Long, to: Long): HalfDownload {
        val conn = URL(DOWNLOAD_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        conn.setRequestProperty("Range", "bytes=$from-$to")
        try {
            conn.connect()
            // No 206 means the server ignored Range: do not read a full
            // 50 MB body here — the caller falls back to one connection.
            if (conn.responseCode != 206) return HalfDownload(0L, 0L, 0L, false)
            val want = to - from + 1
            var bytes = 0L
            var firstByteNs = 0L
            var lastByteNs = 0L
            conn.inputStream.use { input ->
                val buf = ByteArray(BUFFER_SIZE)
                while (bytes < want) {
                    val n = input.read(buf, 0, minOf(buf.size.toLong(), want - bytes).toInt())
                    if (n < 0) break
                    if (firstByteNs == 0L) firstByteNs = System.nanoTime()
                    bytes += n
                    lastByteNs = System.nanoTime()
                    if ((lastByteNs - firstByteNs) / 1_000_000L >= MAX_TEST_MS) break
                }
            }
            return HalfDownload(bytes, firstByteNs, lastByteNs, true)
        } finally {
            conn.disconnect()
        }
    }

    // Single-connection download with the same first-byte timer.
    private fun downloadSingle(): Pair<Long, Long> {
        var bytes = 0L
        var firstByteNs = 0L
        var lastByteNs = 0L
        val conn = URL(DOWNLOAD_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        try {
            conn.connect()
            conn.inputStream.use { input ->
                val buf = ByteArray(BUFFER_SIZE)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (firstByteNs == 0L) firstByteNs = System.nanoTime()
                    bytes += n
                    lastByteNs = System.nanoTime()
                    if ((lastByteNs - firstByteNs) / 1_000_000L >= MAX_TEST_MS || bytes >= MAX_DOWNLOAD_BYTES) break
                }
            }
        } finally {
            conn.disconnect()
        }
        val elapsedMs = if (firstByteNs == 0L) 0L else (lastByteNs - firstByteNs) / 1_000_000L
        return bytes to elapsedMs
    }

    // Upload (issue 23): 2 parallel POSTs (10 MB each, 20 MB total).
    // Returns (actual bytes written, elapsed ms). The end of the
    // measurement is the server's FULL response (drain), not the end of
    // the write — bytes still sitting in the socket buffer are not
    // acknowledged yet, so counting to the end of write overstates the
    // speed, especially on fast links. The counted bytes are still the
    // bytes actually written. Call only on a background thread.
    fun runUpload(): Pair<Long, Long> {
        val half = MAX_UPLOAD_BYTES / 2
        // NW-008: same as runDownload — halves on speedPool, never the shared pool.
        val futures = listOf(0, 1).map {
            NetExecutor.submitSpeedCallable { uploadHalf(half) }
        }
        val halves = mutableListOf<HalfUpload>()
        var parallelOk = true
        for (f in futures) {
            try {
                halves.add(f.get(30, TimeUnit.SECONDS))
            } catch (_: Exception) {
                parallelOk = false
                try { f.cancel(true) } catch (_: Exception) { /* لغو task ناموفق بود — task در حال تمام‌شدن است و parallelOk از پیش false شده. */ }
            }
        }
        if (parallelOk && halves.size == 2) {
            val bytes = halves.sumOf { it.bytes }
            val start = halves.minOf { it.startNs }
            val end = halves.maxOf { it.endNs }
            return bytes to ((end - start) / 1_000_000L)
        }
        return uploadSingle()
    }

    private data class HalfUpload(val bytes: Long, val startNs: Long, val endNs: Long)

    private fun uploadHalf(maxBytes: Long): HalfUpload {
        val startNs = System.nanoTime()
        var bytes = 0L
        val conn = URL(UPLOAD_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        conn.doOutput = true
        conn.requestMethod = "POST"
        conn.setChunkedStreamingMode(BUFFER_SIZE)
        conn.setRequestProperty("Content-Type", "application/octet-stream")
        try {
            conn.connect()
            conn.outputStream.use { out ->
                val buf = ByteArray(BUFFER_SIZE) // zeros, reused
                while (bytes < maxBytes) {
                    val chunk = minOf(BUFFER_SIZE.toLong(), maxBytes - bytes).toInt()
                    out.write(buf, 0, chunk)
                    bytes += chunk
                    if ((System.nanoTime() - startNs) / 1_000_000L >= MAX_TEST_MS) break
                }
                out.flush()
            }
            // Drain the response so the request completes server-side;
            // the clock stops only after the full response is received.
            drainResponse(conn)
            return HalfUpload(bytes, startNs, System.nanoTime())
        } finally {
            conn.disconnect()
        }
    }

    // Single-connection upload with the same end-at-response rule.
    private fun uploadSingle(): Pair<Long, Long> {
        val startNs = System.nanoTime()
        var bytes = 0L
        val conn = URL(UPLOAD_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        conn.doOutput = true
        conn.requestMethod = "POST"
        conn.setChunkedStreamingMode(BUFFER_SIZE)
        conn.setRequestProperty("Content-Type", "application/octet-stream")
        try {
            conn.connect()
            conn.outputStream.use { out ->
                val buf = ByteArray(BUFFER_SIZE) // zeros, reused
                while (true) {
                    out.write(buf)
                    bytes += BUFFER_SIZE
                    if ((System.nanoTime() - startNs) / 1_000_000L >= MAX_TEST_MS || bytes >= MAX_UPLOAD_BYTES) break
                }
                out.flush()
            }
            // Drain the (small) response so the request completes server-side.
            drainResponse(conn)
        } finally {
            conn.disconnect()
        }
        return bytes to ((System.nanoTime() - startNs) / 1_000_000L)
    }

    private fun drainResponse(conn: HttpURLConnection) {
        try {
            conn.inputStream.use { input ->
                val buf = ByteArray(8192)
                while (input.read(buf) >= 0) { /* drain */ }
            }
        } catch (_: Exception) { /* error body or none — result still counts */ }
    }

    // Compose a result from the two phases; null if either phase failed.
    fun buildResult(down: Pair<Long, Long>?, up: Pair<Long, Long>?): SpeedResult? {
        if (down == null || up == null) return null
        return SpeedResult(
            throughputMbps(down.first, down.second),
            throughputMbps(up.first, up.second),
            down.first, up.first, System.currentTimeMillis()
        )
    }
}
