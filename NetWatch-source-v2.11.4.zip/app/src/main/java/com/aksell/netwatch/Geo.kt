package com.aksell.netwatch

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.TelephonyManager
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

data class GeoInfo(val ip: String, val country: String, val countryCode: String, val city: String, val isp: String, val ok: Boolean)

object Geo {
    // ip-api.com رایگان و بدون کلید است؛ موقعیت آی‌پی فعلی را می‌دهد.
    // اگر VPN روشن باشد، این همان لوکیشن خروجی VPN است؛ اگر خاموش باشد، لوکیشن واقعی اپراتور.
    //
    // رضایت (v2.11.2، ایراد ۲۲؛ NW-003 در v2.11.4): آی‌پی به سرویس‌های
    // ثالث فرستاده می‌شود، پس fetch(ctx) فقط وقتی رضایت داده شده باشد
    // شبکه را صدا می‌زند؛ در غیر این صورت GeoInfo(..., ok=false)
    // برمی‌گرداند. Context اجباری است — نسخهٔ بدون Context حذف شده تا
    // هیچ فراخواننده‌ای نتواند از چتر رضایت بیرون بزند.
    private const val GEO_PREF = "geo"
    private const val KEY_GEO_CONSENT = "geo_consent"
    private const val KEY_GEO_DECIDED = "geo_consent_decided"

    fun isConsentGiven(ctx: Context): Boolean {
        return try { ctx.getSharedPreferences(GEO_PREF, Context.MODE_PRIVATE).getBoolean(KEY_GEO_CONSENT, false) } catch (_: Exception) { false }
    }

    /** True once the user has answered the consent dialog (yes or no). */
    fun isDecisionMade(ctx: Context): Boolean {
        return try { ctx.getSharedPreferences(GEO_PREF, Context.MODE_PRIVATE).getBoolean(KEY_GEO_DECIDED, false) } catch (_: Exception) { false }
    }

    fun setConsent(ctx: Context, consent: Boolean) {
        try {
            ctx.getSharedPreferences(GEO_PREF, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_GEO_CONSENT, consent).putBoolean(KEY_GEO_DECIDED, true).apply()
        } catch (_: Exception) { }
    }

    fun fetch(ctx: Context): GeoInfo {
        // No consent means no lookup at all (never a fake location, and
        // no IP sent to a third party before the user agrees).
        if (!isConsentGiven(ctx)) return GeoInfo("", "", "", "", "", false)
        // Primary: ipapi.co (HTTPS). Fallback: ip-api (HTTP, allow-listed
        // for cleartext in network_security_config.xml) when ipapi.co does
        // not answer — common on filtered routes / VPN exits.
        // Both failing still shows an honest "not available", never a fake location.
        return fetchIpapiCo() ?: fetchIpApi() ?: GeoInfo("", "", "", "", "", false)
    }

    private fun fetchIpApi(): GeoInfo? {
        return try {
            val conn = URL("http://ip-api.com/json/?fields=status,country,countryCode,city,isp,query").openConnection() as HttpURLConnection
            conn.connectTimeout = 5000; conn.readTimeout = 5000
            // NW-016: read the body up to 8192 chars (same cap as
            // Diagnostics.dohIps / Probes.httpProbe) — readText() with no
            // cap could read an unbounded body.
            val body = BufferedReader(InputStreamReader(conn.inputStream)).use { br ->
                val sb = StringBuilder(); val cbuf = CharArray(2048); var total = 0
                while (total < 8192) {
                    val n = br.read(cbuf, 0, minOf(cbuf.size, 8192 - total))
                    if (n < 0) break
                    sb.append(cbuf, 0, n); total += n
                }
                sb.toString()
            }
            val o = org.json.JSONObject(body)
            if (o.optString("status", "") != "success") return null
            GeoInfo(o.optString("query", ""), o.optString("country", ""), o.optString("countryCode", ""), o.optString("city", ""), o.optString("isp", ""), true)
        } catch (e: Exception) { null }
    }

    private fun fetchIpapiCo(): GeoInfo? {
        return try {
            val conn = URL("https://ipapi.co/json/").openConnection() as HttpURLConnection
            conn.connectTimeout = 5000; conn.readTimeout = 5000
            // NW-016: read the body up to 8192 chars (same cap as
            // Diagnostics.dohIps / Probes.httpProbe) — readText() with no
            // cap could read an unbounded body.
            val body = BufferedReader(InputStreamReader(conn.inputStream)).use { br ->
                val sb = StringBuilder(); val cbuf = CharArray(2048); var total = 0
                while (total < 8192) {
                    val n = br.read(cbuf, 0, minOf(cbuf.size, 8192 - total))
                    if (n < 0) break
                    sb.append(cbuf, 0, n); total += n
                }
                sb.toString()
            }
            val o = org.json.JSONObject(body)
            val ip = o.optString("ip", ""); if (ip.isBlank()) return null
            GeoInfo(ip, o.optString("country_name", ""), o.optString("country_code", ""), o.optString("city", ""), o.optString("org", ""), true)
        } catch (e: Exception) { null }
    }

    fun operatorName(ctx: Context): String {
        return try {
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            val op = tm?.networkOperatorName ?: ""
            if (op.isNotBlank()) op else "—"
        } catch (e: Exception) { "—" }
    }

    // TelephonyManager.networkType بدون READ_PHONE_STATE روی API 30+ ممکن
    // است SecurityException بدهد (مجوز اضافه نمی‌شود — به‌جای آن null
    // برمی‌گردد و فراخواننده fallback می‌دهد).
    private fun safeNetworkType(tm: TelephonyManager?): Int? {
        return try { tm?.networkType } catch (e: SecurityException) { null }
    }

    fun connectionType(ctx: Context): String {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            // activeNetwork / getNetworkCapabilities فقط از API 23 به بعد
            // وجود دارند؛ روی API 21/22 خواندن آن‌ها NoSuchMethodError
            // (از نوع Error، نه Exception) می‌دهد، پس بیرون از گارد نروند.
            val net = if (Build.VERSION.SDK_INT >= 23) cm.activeNetwork else null
            val caps = if (net != null) cm.getNetworkCapabilities(net) else null
            // NW-011: pre-23 fallback — activeNetwork / getNetworkCapabilities
            // do not exist below API 23, so without this the type was always "—".
            @Suppress("DEPRECATION")
            val legacyType: Int? = if (Build.VERSION.SDK_INT < 23) cm.activeNetworkInfo?.takeIf { it.isConnected }?.type else null
            when {
                caps == null && legacyType == null -> "—"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true || legacyType == ConnectivityManager.TYPE_WIFI -> {
                    val freq = try {
                        @Suppress("DEPRECATION")
                        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager).connectionInfo.frequency
                    } catch (e: Exception) { 0 }
                    if (freq >= 5000) "Wi-Fi (5 GHz)" else if (freq > 0) "Wi-Fi (2.4 GHz)" else "Wi-Fi"
                }
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true || legacyType == ConnectivityManager.TYPE_MOBILE -> {
                    val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
                    when (safeNetworkType(tm)) {
                        TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
                        TelephonyManager.NETWORK_TYPE_NR -> "5G"
                        TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_HSPA -> "3G"
                        else -> "Mobile Data"
                    }
                }
                else -> "—"
            }
        } catch (e: Exception) { "—" }
    }

    fun vpnOn(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            if (Build.VERSION.SDK_INT >= 23) {
                val net = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(net) ?: return false
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            } else {
                // NW-011: pre-23 fallback — the active network's type
                // reports a VPN tunnel directly.
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.type == ConnectivityManager.TYPE_VPN
            }
        } catch (e: Exception) { false }
    }

    fun connectionInfo(ctx: Context): String {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = if (Build.VERSION.SDK_INT >= 23) cm.activeNetwork else null
            val caps = if (net != null) cm.getNetworkCapabilities(net) else null
            // NW-011: pre-23 fallback — Wi-Fi is not visible through
            // NetworkCapabilities below API 23 (mobile already falls back
            // to TelephonyManager below).
            @Suppress("DEPRECATION")
            val legacyWifi = Build.VERSION.SDK_INT < 23 && cm.activeNetworkInfo?.takeIf { it.isConnected }?.type == ConnectivityManager.TYPE_WIFI
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            val netType = safeNetworkType(tm)
            val op = try { tm?.networkOperatorName ?: "" } catch (e: Exception) { "" }
            // Underlying type: from network capabilities when available, otherwise
            // from TelephonyManager — mobile data is still determinable when the
            // active network read returns nothing (e.g. while a VPN tunnel is up).
            val underlying: String? = when {
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true || legacyWifi -> "Wi-Fi"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> when (netType) {
                    TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
                    TelephonyManager.NETWORK_TYPE_NR -> "5G"
                    TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_HSPA -> "3G"
                    else -> "داده همراه"
                }
                netType == TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
                netType == TelephonyManager.NETWORK_TYPE_NR -> "5G"
                netType == TelephonyManager.NETWORK_TYPE_HSPAP || netType == TelephonyManager.NETWORK_TYPE_HSPA -> "3G"
                tm != null && tm.simState == TelephonyManager.SIM_STATE_READY -> "داده همراه"
                else -> null
            }
            val vpn = vpnOn(ctx)
            val type = when {
                vpn && underlying != null -> "VPN ($underlying)"
                vpn -> "VPN"
                underlying != null -> underlying
                else -> "نامشخص"
            }
            val opSuffix = if (!vpn && op.isNotBlank()) " • $op" else ""
            val vpnSuffix = if (vpn) " • VPN روشن" else " • VPN خاموش"
            type + opSuffix + vpnSuffix
        } catch (e: Exception) { "نامشخص" }
    }
}
