package com.aksell.netwatch

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import org.json.JSONObject
import java.io.File

// ShareProvider — Muse via the Android Share loop (Phase 2, the first
// real connection; the development-time bridge until NetWatch is verified
// working correctly).
//
// How a round works:
// 1. AiCore builds the sanitized AiPacket (local analysis).
// 2. This provider writes the readable text + JSON into ONE .txt file in
//    Downloads/NetWatch (ExportHelper — same pattern as the Bridge page)
//    and returns Pending with the file Uri.
// 3. AiActivity launches the chooser (ACTION_SEND, text/plain) — the user
//    picks the Muse app. Nothing is sent automatically.
// 4. Muse's reply comes back with Long-press -> Share to NetWatch;
//    AiActivity hands the text to AiCore.receiveReply, which stores it.
// 5. The reply is usually rendered chat text, not raw JSON: AiCore
//    stores it with parse_failed=true and verdict "unknown" when no JSON
//    verdict is found — never a verdict that was not in the reply.
//
// No key, no server, no new permission. The packet is already sanitized
// by AiCore; the text is sanitized once more here (idempotent).
object ShareProvider : AiProvider, ContextAwareProvider {
    override val id: String = AiCore.PROVIDER_SHARE
    override val displayName: String = "Muse — اشتراک‌گذاری"
    override val isAvailable: Boolean = true
    override val unavailableReason: String? = null

    fun shareFileBase(requestId: String): String = "NETWATCH_AI_$requestId"

    /** Readable text for the .txt file: header + local verdict + findings
     *  with their exact locations + the full packet JSON. Pure. */
    fun buildShareText(packet: JSONObject): String {
        val ai = packet.optJSONObject("ai")
        val sb = StringBuilder()
        sb.append("NETWATCH — AI Analysis (for Muse)\n")
        sb.append("درخواست: ${ai?.optString("request_id", "—") ?: "—"}\n")
        sb.append("این یک گزارش تشخیصی Sanitize‌شده است (بدون IP، SSID، MAC، DNS، رمز یا توکن). ")
        sb.append("لطفاً فقط یک JSON با همین کلیدها برگردان: request_id (همین شناسه)، verdict (ok | degraded | outage | unknown)، cause (علت احتمالی به فارسی)، fix (راهکار به فارسی)، confidence (۰ تا ۱۰۰)، evidence (فهرست شواهد).\n\n")
        val cls = ai?.optJSONObject("local_classification")
        sb.append("حکم محلی: ${ai?.optString("local_verdict", "—") ?: "—"} • طبقه‌بندی: ${cls?.optString("type", "—") ?: "—"} (اطمینان ${cls?.optInt("confidence", -1) ?: -1}٪)\n")
        val pr = ai?.optJSONObject("probes")
        if (pr != null) {
            sb.append("پروب‌ها: ${pr.optInt("ok", 0)} از ${pr.optInt("total", 0)} موفق (داخلی ${pr.optInt("domestic_ok_pct", 0)}٪، بین‌الملل ${pr.optInt("intl_ok_pct", 0)}٪)\n")
        }
        val q = if (ai?.isNull("question") == false) ai.optString("question", "") else ""
        if (q.isNotBlank()) sb.append("سوال کاربر: $q\n")
        val fa = ai?.optJSONArray("findings")
        sb.append("\n== یافته‌ها ==\n")
        if (fa == null || fa.length() == 0) {
            sb.append("یافتهٔ مشخصی نیست.\n")
        } else {
            for (i in 0 until fa.length()) {
                val fo = fa.optJSONObject(i) ?: continue
                sb.append("${i + 1}. [${fo.optString("module", "—")}] ${fo.optString("title", "—")}\n")
                sb.append("   ${fo.optString("detail", "—")}\n")
                val loc = if (!fo.isNull("file")) "${fo.optString("file")}:${fo.optInt("line", -1)} • ${fo.optString("function", "—")}"
                else "بدون فایل/خط (شواهد فایل ندارد)"
                sb.append("   مکان: $loc\n")
                sb.append("   شواهد: ${fo.optString("evidence", "—")}\n")
            }
        }
        sb.append("\n--- JSON ---\n")
        // Compact JSON + 48 KB cap for the whole share text: if the packet
        // JSON would push the text over the cap, the JSON section is dropped
        // (the readable part above it is what the user pastes).
        val json = packet.toString()
        val maxBytes = 48 * 1024
        if ((sb.toString() + json).toByteArray(Charsets.UTF_8).size <= maxBytes) sb.append(json)
        else sb.append("[بریده شد — بزرگ‌تر از سقف]")
        return Bridge.sanitize(sb.toString())
    }

    // The architecture's interface has no Context: without one this
    // provider cannot write the share file, so it fails honestly instead
    // of pretending. The gateway calls sendWithContext on the device.
    override fun send(request: AiCore.AiRequest): AiResult {
        return AiResult.Failed(AiError("share_failed", "ShareProvider بدون Context اندروید نمی‌تواند فایل بسازد", 0, false))
    }

    /** The EXTRA_TEXT for the share intent (2.10.1 fix): the same readable
     *  text as the .txt file, rebuilt from the round's stored packet JSON.
     *  Pure — null when the stored JSON is missing or malformed, so the
     *  caller can fall back to a minimal text instead of failing. */
    fun shareTextForRound(packetJson: String): String? {
        if (packetJson.isBlank()) return null
        return try {
            buildShareText(JSONObject(packetJson))
        } catch (_: Exception) { null }
    }

    /** Deletes share files (NETWATCH_AI_*.txt) in Downloads/NetWatch older
     *  than 7 days. Best-effort: any failure is swallowed — cleanup must
     *  never break the share itself. API 29+ via MediaStore, API 21–28
     *  via the public Downloads/NetWatch folder. */
    private fun pruneOldShareFiles(ctx: Context) {
        try {
            val cutoff = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = ctx.contentResolver
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                resolver.query(
                    uri,
                    arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DATE_MODIFIED),
                    "${MediaStore.Downloads.DISPLAY_NAME} LIKE ? AND ${MediaStore.Downloads.RELATIVE_PATH}=?",
                    arrayOf("NETWATCH_AI_%.txt", "Download/NetWatch/"), null
                )?.use { c ->
                    val idIdx = c.getColumnIndex(MediaStore.Downloads._ID)
                    val modIdx = c.getColumnIndex(MediaStore.Downloads.DATE_MODIFIED)
                    val stale = ArrayList<Uri>()
                    while (c.moveToNext()) {
                        if (idIdx < 0 || modIdx < 0) continue
                        if (c.getLong(modIdx) * 1000L < cutoff) {
                            stale.add(ContentUris.withAppendedId(uri, c.getLong(idIdx)))
                        }
                    }
                    for (u in stale) {
                        try { resolver.delete(u, null, null) } catch (_: Exception) { /* حذف فایل اشتراک قدیمی best-effort است؛ ماندنش یعنی در پاک‌سازی بعدی دوباره امتحان می‌شود. */ }
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NetWatch")
                val files = try { dir.listFiles() } catch (_: Exception) { null } ?: return
                for (f in files) {
                    if (f.name.startsWith("NETWATCH_AI_") && f.name.endsWith(".txt") && f.lastModified() < cutoff) {
                        try { f.delete() } catch (_: Exception) { /* حذف فایل اشتراک قدیمی best-effort است؛ ماندنش یعنی در پاک‌سازی بعدی دوباره امتحان می‌شود. */ }
                    }
                }
            }
        } catch (e: Exception) {
            // پاک‌سازی فایل‌های اشتراک قدیمی best-effort است و نباید share را بشکند،
            // ولی شکست کل آن باید در logcat دیده شود.
            Log.w("AiProviders", "pruneOldShareFiles failed: ${e.javaClass.simpleName}", e)
        }
    }

    override fun sendWithContext(ctx: Context, request: AiCore.AiRequest): AiResult {
        val text = buildShareText(request.packet)
        pruneOldShareFiles(ctx)
        // The Downloads file is optional: sharing works from EXTRA_TEXT
        // alone (AiActivity rebuilds the text from the packet and serves
        // the file from cache). A failed save must NOT fail the round —
        // it stays Pending with a null share Uri.
        val res = try {
            ExportHelper.save(ctx, shareFileBase(request.requestId), "txt", "text/plain") { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
            }
        } catch (_: Exception) {
            return AiResult.Pending(request.requestId, "فایل ذخیره نشد ولی متن آماده است — با «ارسال به Muse» متن را بفرست.", null)
        }
        if (!res.ok || res.uri == null) {
            return AiResult.Pending(request.requestId, "فایل ذخیره نشد ولی متن آماده است — با «ارسال به Muse» متن را بفرست.", null)
        }
        return AiResult.Pending(request.requestId, "فایل آماده است — «ارسال به Muse» را بزن و اپ Muse را انتخاب کن.", res.uri.toString())
    }

    // The reply arrives through the Android share intent, not a file —
    // there is nothing to poll. AiCore.receiveReply handles the return.
    override fun poll(roundId: String): AiResult? = null

    override fun cancel(roundId: String) {
        // Nothing to cancel: the prepared file stays in Downloads/NetWatch.
    }
}
