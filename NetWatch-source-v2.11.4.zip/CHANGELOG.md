# Changelog — NetWatch

All notable changes to NetWatch, in release order. Only information that is
verified from the repository or from the fix work itself is listed; anything
unknown is marked «در دسترس نیست» rather than invented.

## v2.11.4 — 2026-11-28 (versionCode 40)

Fix round for the 16 issues NW-001–NW-016 from the v2.11.3 review
(`AUDIT-NetWatch-v2.11.3.md`, 2026-11-28; 2 critical, 7 serious,
7 medium). Status: 14 رفع شد، 2 جزئی (NW-009، NW-012)؛ NW-002 قبلاً در بازسازی v2.11.3 رفع شده بود.

- **NW-001 (p0, build) — رفع شد:** `package="com.aksell.netwatch"`,
  `<uses-sdk …/>`, `android:versionCode` and `android:versionName`
  removed from `app/src/main/AndroidManifest.xml` (only
  `xmlns:android` remains on the `<manifest>` tag). Namespace
  (`com.aksell.netwatch`), compileSdk 34, minSdk 21, targetSdk 34 and
  the version live only in `app/build.gradle.kts` (verified correct
  there before the edit).
- **NW-002 (p0, build) — قبلاً رفع شده در بازسازی v2.11.3:**
  `gradle/wrapper/gradle-wrapper.jar` (official Gradle 8.7,
  tag v8.7.0) is present together with `gradlew` / `gradlew.bat`;
  verified intact in this release with `unzip -t` (no errors).
  No change was needed and the jar was not rebuilt.
- **NW-003 (p1, privacy) — رفع شد:** `Geo.fetch(ctx: Context?)`
  became `Geo.fetch(ctx: Context)` (no-arg overload removed);
  `Quality.detectChange(ctx)` and `GamingActivity` use `Geo.fetch(ctx)`
  and show «—» when `geo.ok == false`; the single real `api.ipify.org`
  call in `LabActivity.fetchPublicIp()` is gated on
  `Geo.isConsentGiven(this)` (the audit's second cited line was a
  descriptive string, not a call).
- **NW-004 (p1, concurrency) — رفع شد:** `runCmdDetailed` now
  separates `InterruptedException` (restores the flag, destroys the
  process, returns cancel/timeout not startFailed); only an
  `IOException` containing «Cannot run program» means startFailed;
  `resetPingMissing()` runs at the start of `runAll()`/`runLight()`.
- **NW-005 (p1, ANR) — رفع شد:** `NetWatchWidget.refreshAll`
  moved off `runOnMain` to `NetExecutor.submit` (also widget
  `onUpdate`); `paintDashboard` now takes precomputed `graphPoints`
  and `connInfo`; widget uses new `History.lastSample()` (`LIMIT 1`)
  instead of `samplesFull()`; `onCreate`/`refreshHistory` reads moved
  to a background thread.
- **NW-006 (p1, battery/docs) — رفع شد:** `onCreate` now calls
  `lightCheck()` only; the full check runs only from the «بررسی»
  button. The About text already described this behaviour, so it
  needed no change.
- **NW-007 (p1, responsiveness) — رفع شد:** a 90-second overall
  deadline (`System.nanoTime()`) for `doCheck`, checked at stage
  boundaries; later stages are skipped with «در دسترس نیست — بودجه
  زمان»; `traceroute` reduced from 8 to 4 hops.
- **NW-008 (p1, resources) — رفع شد:** dedicated pools
  `labPool` (2 threads), `benchPool` (1 thread) and `speedPool`
  (3 threads); DNS benchmark capped at 20 rounds with
  `shouldStop` and tap-again-to-cancel; SpeedTest runs entirely
  on `speedPool`.
- **NW-009 (p1, tests/architecture) — جزئی:** `isFinishing ||
  isDestroyed` guard added in `runSection`'s `runOnMain`;
  `sectionFutures` are cancelled in `onDestroy`; `runSection`/RUN ALL
  moved to `labPool`. Full cancellation is not achieved
  (`runGroup`/`runTimed` swallow `InterruptedException`) and moving
  Lab to `src/debug` is impossible without breaking the release
  build (MainActivity, AiCore, Bridge reference it directly).
- **NW-010 (p2, UI honesty) — رفع شد:** the dialog now says
  «تا حدود ۷۰ مگابایت (۵۰ دانلود + ۲۰ آپلود + ~۱ warmup)».
  A «fast (10MB)» option was deliberately not added.
- **NW-011 (p2, minSdk) — رفع شد:** pre-API-23 branches with
  `@Suppress("DEPRECATION") cm.activeNetworkInfo` added in
  `Geo.kt` (connectionType, vpnOn, connectionInfo); minSdk stays 21.
- **NW-012 (p2, storage) — جزئی:** the write-side claim was
  **not confirmed** — caps already existed (`addLog` take(200),
  timeline 100 lines, blackbox 20 lines, hourly takeLast(96));
  no new cap was added. The Main-thread reads were fixed as
  part of NW-005.
- **NW-013 (p2, dead config) — رفع شد:** `res/xml/file_paths.xml`
  deleted; the `ExportFileProvider` comment now says the paths
  are hard-coded in `fileFor()`.
- **NW-014 (p2, dead config) — رفع شد:** the ineffective ProGuard
  rule `-keepclassmembers class com.aksell.netwatch.* { public void
  *(android.view.View); }` was removed from `app/proguard-rules.pro`
  (replaced by a NOTE explaining why). Verified first: no
  `android:onClick` exists in any of the 6 layouts — all clicks are
  set in Kotlin — so the rule, which only serves XML `onClick`
  handlers, was dead.
- **NW-015 (p2, sharing/permission) — رفع شد:** `ClipData.newUri`
  + `FLAG_GRANT_READ_URI_PERMISSION |
  FLAG_GRANT_PREFIX_URI_PERMISSION` in `ExportHelper`,
  `BridgeActivity` (both shares) and `AiActivity`.
- **NW-016 (p2, stability) — رفع شد:** the same
  `while (total < 8192)` loop as `Diagnostics.dohIps` /
  `Probes.httpProbe` copied into `Geo.fetchIpApi` and
  `Geo.fetchIpapiCo` (8,192-character cap).
- **Version bump:** `app/build.gradle.kts` only — versionCode 39 → 40,
  versionName 2.11.3 → 2.11.4. The Manifest no longer carries any
  version attributes (see NW-001).
- **Not verified in this environment:** no full Gradle compile was run
  (no Gradle/JDK/Android SDK in this environment) — build in Android
  Studio before releasing an APK (`./gradlew :app:assembleDebug`
  and `./gradlew testDebugUnitTest`) and run the in-app LAB tests.

## v2.11.3 — 2026-11-28 (versionCode 39)

Fix round for the 22-issue v2.11.2 audit (3 critical, 9 serious,
10 medium). All 22 were verified against the real code; 21 fixed,
1 partial (03 — LAB stays in the release binary, see below).

- **Build system (01, p0):** the archive now contains a complete
  Gradle project — `settings.gradle.kts`, root `build.gradle.kts`
  (AGP 8.5.2, Kotlin 1.9.24), `app/build.gradle.kts` (namespace
  `com.aksell.netwatch`, compileSdk 34, minSdk 21, targetSdk 34,
  versionCode 39, versionName 2.11.3), `gradle.properties`,
  `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.7),
  `app/proguard-rules.pro` (minimal R8 keep rules) and a minimal
  `.gitignore`. Zero third-party runtime dependencies, as before;
  test-only JUnit 4.13.2 for `src/test`.
  `gradle/wrapper/gradle-wrapper.jar` is **not** included: it must be
  generated once with `gradle wrapper --gradle-version 8.7` or by opening
  the project in Android Studio.
- **RTL (02, p0):** `android:supportsRtl="true"` in the Manifest;
  the manual `layoutDirection="rtl"` on sectionHome was removed.
- **LAB tests (03, p0) — partial:** 58 pure JVM unit tests added in
  `app/src/test` (LabPureTests 47, LabProbesRestoreTests 11).
  `LabActivity` stays in `src/main`: `MainActivity` calls it directly
  and the Manifest registers it, so moving it to `src/debug` would
  break the release build. `Lab.kt` also stays: its APIs are used by
  the production code (AnalyticsEngine, Bridge, AiCore).
- **Hourly percent (04, p1):** `addHourly` denominator is now
  `scored.size`, not `results.size`.
- **Probe waiting (05–07, p1):** `InterruptedException` restores the
  interrupt flag and breaks; Timeout/Execution/Cancellation are
  separated; a zero-timeout sweep over remaining futures fixes the
  visibility race; the deadline is now `ceil(n/8) × 10s` with
  cheapest probes first (full run 60s, light run 10s).
- **Monotonic clock (08, p1):** gaming end and Live freshness use
  `SystemClock.elapsedRealtime()`; wall-clock stays only for
  calendar history dates.
- **Notifications (09, p1):** separate IDs — monitor 1, alert 2,
  AI 3, gaming 4 (new); gaming notification is cancelled when a
  session ends.
- **Location permission (10, p1):** no longer requested
  unconditionally at startup; only on demand from the network-details
  view, with an explicit explanation dialog. Kept in the Manifest:
  SSID really is read via `WifiManager` and is unavailable without it.
- **Geo consent (11, p1):** public-IP fetch in WidgetStats is now
  gated on `Geo.isConsentGiven`; without consent no request is made
  and cached values are cleared.
- **AI share spoofing (12, p1):** 32KB cap on shared text, sender
  recorded, replies accepted only while a Pending round exists;
  `exported=true` kept on purpose — the Muse share flow needs it.
- **Strings & i18n (13, 15, p2):** `res/values/strings.xml` created
  (255 keys, mirrored in `values-fa` and `values-en`); layout texts
  moved to `@string`; English labels (Ping, Packet Loss, Download,
  Upload, Live, Connected, …) are now Persian; widget language follows
  `Locale.getDefault()`.
- **Accessibility (14, p2):** all 51 ImageViews now have a
  `contentDescription` (47) or `importantForAccessibility="no"` (4
  decorative widget items); was 4/51.
- **Empty catches (16, p2):** empty catches in the swept files went
  from 47 to 0 (21 now log, 26 kept empty with a reason comment);
  `lightCheck` failures are now logged via `History.addLog`.
- **CSV export (17, p2):** numbers with `Locale.US`, UTF-8 BOM
  prefix, quoted text fields.
- **DoH parsing (18, p2):** `parseDohJson` now uses `org.json`;
  the regex parser remains only as fallback (JVM test stubs).
- **Non-null assertions (19, p2):** both flagged `!!` removed
  (`History.kt:812`, `BridgeActivity.kt:262`).
- **Widget size (20, p2):** compact 4×3 widget — `minHeight` 780dp
  → 220dp, `targetCellHeight` 12 → 3; tall layout stays available
  via resize.
- **Docs (21, p2):** `README.md` and this `CHANGELOG.md` added at
  the archive root (build instructions, project structure, version table).
- **Backup errors (22, p2):** `History.backupToUriReason` returns the
  exact Persian reason (disk full / not writable / permission
  revoked); the backup Toast in MainActivity shows it.
- **Version bump:** `AndroidManifest.xml` versionCode 38 → 39,
  versionName 2.11.2 → 2.11.3.
- **Not verified in this environment:** no full Gradle compile was run
  (no Gradle/JDK in this environment) — build in Android Studio before
  releasing an APK and run the in-app LAB tests.

## v2.11.2 — 2026-11-28 (versionCode 38)

Fix round for 26 audited issues (v2.11.1 → v2.11.2; source commit
27 Nov 2026). Source zip: 456,866 bytes, 108 files. APK / SHA-256:
در دسترس نیست.

- Cleartext traffic limited to three domains (`ip-api.com`,
  `example.com`, `connectivitycheck.gstatic.com`) via
  `network_security_config.xml`; Geo tries HTTPS `ipapi.co` first.
- Runtime permission requests added (notifications on Android 13+,
  storage on API ≤ 28, location for SSID).
- AI Share no longer fails the whole round when writing to Downloads
  fails (falls back to text-only share); old AI files older than 7 days
  are cleaned up.
- Separate 8-thread probe pool (no more thread starvation); probe
  timeout handling fixed.
- Restore now preserves the AI tables (`ai_analyses`, `ai_chats`).
- AI reply routing fixed (no attaching to the wrong round; stale
  Pending rounds expire after 24 h); share Intent is processed once.
- `onDestroy` no longer cancels the service background check.
- API 26/23 calls guarded by `SDK_INT` branches (minSdk stays 21).
- `TelephonyManager.networkType` wrapped against `SecurityException`;
  no `READ_PHONE_STATE` permission added.
- Ping loss/jitter/burst recomputed from `icmp_seq` (not from printed
  text); informational probes excluded from the health percentage.
- Bufferbloat download loop, service `startForeground` ordering,
  reconnect threshold, separate AI notification ID, DB migration to
  version 4 with `onDowngrade`, Bridge persist throttling, binary
  Quad9 DoH (RFC 8484), TLS hostname verification, VPN-aware gateway
  classification, balanced-JSON reply parsing, `allowBackup=false`,
  Geo JSON parsing + user consent, SpeedTest timing fixes, dead code
  removed (AiGateway caps, 9 `selfTests()` functions), `clearAll`
  no longer wipes settings.
- One UI spelling fix («تاریخه» → «تاریخچه»); no other Persian UI
  strings changed.

## v2.11.1 (versionCode 37)

Last repo source before the v2.11.2 fix round (commit 27 Nov 2026).
No changelog details available for this version. APK / SHA-256:
در دسترس نیست.

## v2.9.9

Session-based background gaming monitoring (gaming session loop moved
to `MonitorService`). Details from code comments only. APK / SHA-256:
در دسترس نیست.

## v2.9.8

Restore path: sidecar reconcile / fresh recovery for restore
(`History.kt`). Details from code comments only. APK / SHA-256:
در دسترس نیست.

## v2.9.7

Chart time-axis labels with second resolution; packet-loss strip
(`ChartData.kt`, `GraphView.kt`). Details from code comments only.
APK / SHA-256: در دسترس نیست.
