package com.aksell.netwatch

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Future

// Network Engine — the single public API for every network measurement in the
// app. The actual measurement code lives in its workers (Diagnostics for
// sockets/processes, Probes for probe definitions, Gaming for ping bursts);
// this object is the boundary: one place for method labels, timeouts and
// single-flight guards, so no caller can run the same measurement twice or
// mix ICMP and TCP results.
//
// Design decisions (deliberate, see the v2.7 architecture report):
// - No coroutines dependency: NetExecutor (fixed pool + Future cancellation)
//   already provides the required timeout/cancellation semantics. Adding
//   kotlinx-coroutines would grow the APK for no functional gain.
// - No new threads are created here: everything runs on NetExecutor.
// - Every function is bounded: the workers kill processes and close sockets
//   on timeout; nothing here can block forever.
object NetworkEngine {

    // How a ping was measured. ICMP and TCP results are never mixed: the
    // method travels with the result (PingResult.host carries "(TCP)").
    enum class Method { ICMP, TCP }

    // Single-flight registry: one in-flight measurement per key. A second
    // request for the same key is refused instead of stacking a duplicate.
    //
    // v2.8 race fix: the old code checked `inFlight[key]`, then submitted,
    // then stored the Future — two threads could both pass the check and both
    // run, and the first task's finally could delete the second task's entry.
    // Now the FutureTask itself is created BEFORE submission and claimed
    // atomically with putIfAbsent, so the claim and the identity are one
    // indivisible step: at most one task per key can ever be submitted.
    // Removal is value-checked (`remove(key, ft)`) so a finished task can
    // never delete a newer task's entry. Cancellation removes the entry first
    // and then cancels, so a task cancelled before it starts can never leak
    // its entry (a cancelled FutureTask simply never runs).
    private val inFlight = ConcurrentHashMap<String, java.util.concurrent.FutureTask<Unit>>()

    // Returns the Future when the task was accepted, null when the same key
    // is already running. Callers keep the Future to cancel it (Stop button,
    // onDestroy); the registry entry is removed automatically on completion.
    fun submitSingle(key: String, task: () -> Unit): java.util.concurrent.Future<*>? {
        while (true) {
            lateinit var ft: java.util.concurrent.FutureTask<Unit>
            ft = java.util.concurrent.FutureTask<Unit>({
                try { task() } finally { inFlight.remove(key, ft) }
            }, Unit)
            val prev = inFlight.putIfAbsent(key, ft)
            if (prev == null) {
                NetExecutor.execute(ft)
                return ft
            }
            if (prev.isDone) {
                // Previous task finished but its finally has not removed the
                // entry yet — replace it only if it is still the same one.
                if (inFlight.replace(key, prev, ft)) {
                    NetExecutor.execute(ft)
                    return ft
                }
                continue // lost the replace race — retry the claim
            }
            return null // same key already running
        }
    }

    fun cancelSingle(key: String) {
        inFlight.remove(key)?.cancel(true)
    }

    fun isRunning(key: String): Boolean = inFlight[key]?.isDone == false

    // True when the system's ping binary is missing (not the same as "no
    // internet" — callers must report it honestly).
    fun pingMissing(): Boolean = Diagnostics.pingMissing

    // Real ICMP ping burst. Returns an empty result (received=0, loss=100%)
    // when nothing answers — never a fake 0ms.
    fun ping(host: String, count: Int = 20): PingResult = Gaming.pingHost(host, count)

    // TCP connect-time burst, used ONLY when ICMP is blocked. The result is
    // labelled "(TCP)" in PingResult.host so the UI can never present it as
    // an ICMP ping.
    fun tcpPing(host: String, port: Int = 443, count: Int = 10): PingResult =
        Gaming.tcpPing(host, port, count)

    // One-shot ping statistics (avg/min/max/jitter/loss) for the dashboard.
    // Bounded by Diagnostics.pingLines; never returns a fake 0ms.
    fun pingStats(host: String): PingStats = Diagnostics.pingStats(host)

    // Single ping, null when unanswered (used by the live-ping loop).
    fun pingOnce(host: String = "1.1.1.1"): Double? = Diagnostics.pingOnce(host)

    fun tcp(host: String, port: Int): Timed = Diagnostics.tcpTime(host, port)
    fun tls(host: String, port: Int = 443): Timed = Diagnostics.tlsTime(host, port)

    // DNS the honest way: a real query to a resolver. An IP literal needs no
    // resolution and returns ok=false with an "N/A" note — never 0ms success.
    fun dns(host: String, resolver: String = "1.1.1.1"): Timed = Diagnostics.dnsTime(host, resolver)
    fun udpDns(serverIp: String, hostname: String = "google.com"): Timed = Diagnostics.udpDns(serverIp, hostname)

    // Real DNS-over-TLS: TLS handshake to :853, then a DNS query over the TLS
    // stream with the response validated. Not a bare TCP connect.
    fun dot(serverIp: String, hostname: String = "google.com"): Timed = Diagnostics.dotQuery(serverIp, hostname)

    // QUIC: no valid handshake exists in this app, so the status stays
    // Unknown with a reason — never a fake Success.
    fun quic(host: String): Diagnostics.QuicResult = Diagnostics.quicStatus(host)

    // Full probe set (40+, manual only) or the light set (8 probes, for the
    // timer and the background service). One call, one policy.
    fun runProbes(light: Boolean): List<ProbeResult> =
        if (light) Probes.runLight() else Probes.runAll()

    // Route diagnostics (best-effort on a non-root phone; "unavailable" is
    // reported honestly when the ping binary cannot do it).
    fun traceroute(host: String = "8.8.8.8"): String = Diagnostics.traceroute(host)
    fun mtuTest(host: String = "1.1.1.1"): String = Diagnostics.mtuTest(host)

    // DNS-over-HTTPS answers for one hostname, from one DoH endpoint.
    fun dohIps(dohUrl: String, host: String): List<String> = Diagnostics.dohIps(dohUrl, host)

    fun summarize(results: List<ProbeResult>, filtering: String): Probes.Summary =
        Probes.summarize(results, filtering)

    fun networkInfo(ctx: android.content.Context): String = NetworkInfo.summary(ctx)
}
