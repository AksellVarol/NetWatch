package com.aksell.netwatch

import android.content.Context
import kotlin.math.abs
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

data class TestResult(val name: String, val method: String, val expected: String, val actual: String, val pass: Boolean?, val error: String = "", val date: String = "")
// pass: true=Pass, false=Fail, null=Not Tested

object Lab {
    data class Stats(val min: Double, val avg: Double, val max: Double, val p50: Double, val p90: Double, val p95: Double, val p99: Double, val jitter: Double, val lossPct: Double)
    fun computeStats(times: List<Double>, sent: Int): Stats {
        val s = times.sorted()
        fun pct(p: Double): Double { if (s.isEmpty()) return 0.0; val rank = kotlin.math.ceil(p / 100.0 * s.size).toInt().coerceIn(1, s.size); return s[rank - 1] }
        var j = 0.0
        if (times.size > 1) j = (1 until times.size).map { abs(times[it] - times[it - 1]) }.average()
        return Stats(s.firstOrNull() ?: 0.0, if (times.isEmpty()) 0.0 else times.average(), s.lastOrNull() ?: 0.0, pct(50.0), pct(90.0), pct(95.0), pct(99.0), j, if (sent == 0) 0.0 else (sent - times.size) * 100.0 / sent)
    }

    fun unitTests(): List<TestResult> {
        val out = mutableListOf<TestResult>()
        fun t(name: String, expected: String, actual: String, ok: Boolean) { out.add(TestResult(name, "Unit — ورودی ثابت، بدون شبکه", expected, actual, ok, date = History.timeStr(System.currentTimeMillis()))) }
        // Fixed input: [42,48,50,55,72], sent 5
        val st = computeStats(listOf(42.0, 48.0, 50.0, 55.0, 72.0), 5)
        t("Ping Avg/Min/Max", "avg 53.4, min 42, max 72", "avg ${"%.1f".format(st.avg)}, min ${st.min}, max ${st.max}", st.avg == 53.4 && st.min == 42.0 && st.max == 72.0)
        t("P50/P90/P95/P99 (nearest-rank)", "P50 50, P90 72, P95 72, P99 72", "P50 ${st.p50}, P90 ${st.p90}, P95 ${st.p95}, P99 ${st.p99}", st.p50 == 50.0 && st.p90 == 72.0 && st.p95 == 72.0 && st.p99 == 72.0)
        t("اعتبار آماری نمونه کم", "n=5 → اعتبار پایین (در UI هم نمایش داده می‌شود)", "n=5", true)
        // Statistical validation: 100 values 1..100 -> P50=51, P90=91, P95=96 (nearest-rank on (p/100)*(n-1))
        val big = Lab.computeStats((1..100).map { it.toDouble() }, 100)
        t("اعتبارسنجی آماری (۱ تا ۱۰۰)", "P50 50, P90 90, P95 95", "P50 ${big.p50}, P90 ${big.p90}, P95 ${big.p95}", big.p50 == 50.0 && big.p90 == 90.0 && big.p95 == 95.0)
        // Division by zero guard
        val empty = Lab.computeStats(emptyList(), 0)
        t("تقسیم بر صفر (داده خالی)", "همه صفر، بدون Crash", "avg ${empty.avg}, loss ${empty.lossPct}%", empty.avg == 0.0 && empty.lossPct == 0.0)
        t("Jitter", "jitter 7.5 (diffs 6,2,5,17 -> mean 30/4)", "jitter ${"%.1f".format(st.jitter)}", st.jitter == 7.5)
        t("Packet Loss", "loss 0% (5/5)", "loss ${st.lossPct}%", st.lossPct == 0.0)
        val st2 = computeStats(listOf(40.0, 45.0), 5)
        t("Packet Loss با بسته گمشده", "loss 60% (2/5)", "loss ${st2.lossPct}%", st2.lossPct == 60.0)
        // Bufferbloat grade: idle 48, loaded 60 -> +12ms -> A
        val bb = Gaming.bufferbloatGradeForTest(48.0, 60.0)
        t("Bufferbloat Grade", "افزایش 12ms → A", "درجه ${bb.first} (افزایش ${bb.second}ms)", bb.first == "A")
        val bb2 = Gaming.bufferbloatGradeForTest(48.0, 180.0)
        t("Bufferbloat Grade بد", "افزایش 132ms → D", "درجه ${bb2.first}", bb2.first == "D")
        // Score: perfect ping 40ms, jitter 3, loss 0, no spikes, bb A(100) -> 35+20+25+10+10=100
        val pr = PingResult("test", 20, 20, 0.0, 40.0, 40.0, 45.0, 40.0, 41.0, 42.0, 44.0, 3.0, 0, 0, listOf(40.0))
        val sc = Gaming.score(pr, Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100))
        t("Network Score کامل", "100/100", "${sc.total}/100", sc.total == 100)
        val bad = PingResult("test", 20, 10, 50.0, 100.0, 200.0, 400.0, 180.0, 300.0, 350.0, 390.0, 50.0, 8, 3, listOf(200.0))
        val sc2 = Gaming.score(bad, Gaming.Bufferbloat(200.0, 400.0, 200.0, "F", 20))
        t("Network Score بد", "کمتر از 40", "${sc2.total}/100", sc2.total != null && sc2.total < 40)
        // v2.6: bufferbloat unmeasured -> total is null, never a fake 5/10.
        val scNoBb = Gaming.score(pr, null)
        t("Gaming Score — بدون Bufferbloat", "total == null (امتیاز فرضی ندارد)", "total=${scNoBb.total}", scNoBb.total == null)
        val scBb = Gaming.score(pr, Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100))
        t("Gaming Score — با Bufferbloat", "total == 100", "total=${scBb.total}", scBb.total == 100)
        // v2.6: dnsTime on an IP literal is N/A, not a 0ms DNS success.
        val dnsIp = Diagnostics.dnsTime("1.1.1.1")
        t("dnsTime — IP مستقیم", "ok=false، note شامل N/A", "ok=${dnsIp.ok}، ${dnsIp.note}", !dnsIp.ok && dnsIp.note.contains("N/A"))
        // v2.6: ChartData — pure chart math (empty / 1 / 2 / 60 / >60, irregular
        // timestamps, failed points split segments, outliers, range filters).
        val now = System.currentTimeMillis()
        val cdEmpty = ChartData.stats(emptyList())
        t("Chart — خالی", "valid=0، min/avg/max=0", "valid=${cdEmpty.valid}", cdEmpty.valid == 0 && cdEmpty.min == 0.0 && cdEmpty.avg == 0.0 && cdEmpty.max == 0.0)
        val cdOne = ChartData.stats(listOf(now to 42.0))
        t("Chart — یک نمونه", "min=avg=max=42", "min=${cdOne.min} avg=${cdOne.avg} max=${cdOne.max}", cdOne.min == 42.0 && cdOne.avg == 42.0 && cdOne.max == 42.0)
        val cdTwo = ChartData.stats(listOf(now to 40.0, now + 5000 to 60.0))
        t("Chart — دو نمونه", "min=40 avg=50 max=60", "avg=${cdTwo.avg}", cdTwo.min == 40.0 && cdTwo.avg == 50.0 && cdTwo.max == 60.0)
        val sixty = (0 until 60).map { now + it * 1000L to (40.0 + it) }
        val cd60 = ChartData.stats(sixty)
        t("Chart — ۶۰ نمونه", "min=40 avg=69.5 max=99", "avg=${cd60.avg} max=${cd60.max}", cd60.valid == 60 && cd60.min == 40.0 && cd60.avg == 69.5 && cd60.max == 99.0)
        val over = (0 until 120).map { now + it * 1000L to 50.0 }
        val cdOver = ChartData.stats(over)
        t("Chart — بیش از ۶۰ نمونه", "valid=120 (بدون برش)", "valid=${cdOver.valid}", cdOver.valid == 120 && cdOver.avg == 50.0)
        val irregular = listOf(now to 50.0, now + 137000 to 60.0, now + 900000 to 70.0)
        val cdIr = ChartData.stats(irregular)
        t("Chart — Timestamp نامنظم", "آمار از مقدارها، نه فاصله‌ها", "avg=${cdIr.avg}", cdIr.avg == 60.0)
        val withFail = listOf(now to 40.0, now + 1000 to -1.0, now + 2000 to 50.0, now + 3000 to -1.0, now + 4000 to 60.0)
        val segs = ChartData.segments(withFail)
        val cdFail = ChartData.stats(withFail)
        t("Chart — نمونه ناموفق بین موفق‌ها", "۳ قطعه جدا + failed=2، آمار فقط موفق‌ها", "segments=${segs.size} failed=${cdFail.failed} avg=${cdFail.avg}", segs.size == 3 && cdFail.failed == 2 && cdFail.avg == 50.0)
        val outlier = (0 until 20).map { now + it * 1000L to 50.0 } + listOf(now + 21000 to 986.0)
        val ym = ChartData.yMax(outlier.map { it.second })
        t("Chart — yMax با مقدار پرت", "P95=50 → yMax=100 (نه 986×1.2)", "yMax=$ym", ym == 100.0)
        val nanPts = listOf(now to 40.0, now + 1000 to Double.NaN, now + 2000 to 60.0)
        val cdNan = ChartData.stats(nanPts)
        t("Chart — NaN", "NaN مثل ناموفق شمرده شود", "valid=${cdNan.valid} failed=${cdNan.failed}", cdNan.valid == 2 && cdNan.failed == 1)
        val day = 24L * 3600 * 1000
        val mixed = listOf(now - 40 * day to 40.0, now - 5 * day to 50.0, now - 1 * 3600 * 1000 to 60.0, now to 70.0)
        val r24 = ChartData.inRange(mixed, now - day)
        val r7 = ChartData.inRange(mixed, now - 7 * day)
        val r30 = ChartData.inRange(mixed, now - 30 * day)
        t("Chart — فیلتر 24h/7d/30d", "24h=2، 7d=3، 30d=3", "24h=${r24.size} 7d=${r7.size} 30d=${r30.size}", r24.size == 2 && r7.size == 3 && r30.size == 3)
        // Quality Score Phase 1 (v1.9): ScoreResult sealed + Coverage Gate 70%
        val q1 = Quality.compute(40.0, 3.0, 0.0, 100)
        t("Quality Score — همه معتبر", "Complete, Total 100, coverage 100٪", "Total ${(q1 as? Quality.ScoreResult.Complete)?.total}, ${(q1 as? Quality.ScoreResult.Complete)?.coverage}", q1 is Quality.ScoreResult.Complete && q1.total == 100 && q1.coverage == 1.0)
        // Old v1.8 bug case: ping missing -> normalized 100/100. Now: coverage 60% < 70% -> InsufficientData, NO total.
        val q2 = Quality.compute(0.0, 3.0, 0.0, 100, pingValid = false)
        t("Quality Score — فقط Ping فاقد داده", "InsufficientData, coverage 60٪, بدون عدد کل", "نوع ${q2::class.simpleName}, coverage ${(q2 as? Quality.ScoreResult.InsufficientData)?.coverage}", q2 is Quality.ScoreResult.InsufficientData && q2.coverage == 0.6)
        val q3 = Quality.compute(100.0, 0.0, 2.0, 85, jitterValid = false)
        t("Quality Score — فقط Jitter فاقد داده", "Complete, Total 65 (52/80 نرمال‌شده)، coverage 80٪", "Total ${(q3 as? Quality.ScoreResult.Complete)?.total}", q3 is Quality.ScoreResult.Complete && q3.total == 65 && q3.coverage == 0.8)
        val q4 = Quality.compute(0.0, 0.0, 0.0, 90, pingValid = false, jitterValid = false)
        t("Quality Score — چند مؤلفه فاقد داده", "InsufficientData, coverage 40٪", "نوع ${q4::class.simpleName}", q4 is Quality.ScoreResult.InsufficientData && q4.coverage == 0.4)
        val q5 = Quality.compute(0.0, 0.0, 0.0, 0, pingValid = false, jitterValid = false, lossValid = false, stabValid = false)
        t("Quality Score — هیچ مؤلفه‌ای داده ندارد", "NotAvailable", "نوع ${q5::class.simpleName}", q5 is Quality.ScoreResult.NotAvailable)
        // Fix 1: avgMs <= 0 with pingValid=true must be N/A, not score 0
        val q6 = Quality.compute(0.0, 3.0, 0.0, 100)
        t("Quality Score — avgMs صفر", "Ping N/A (نه صفر)، coverage 60٪ -> InsufficientData", "Ping ${(q6 as? Quality.ScoreResult.InsufficientData)?.parts?.ping ?: "N/A"}", q6 is Quality.ScoreResult.InsufficientData && q6.parts.ping == null)
        // Coverage Gate exact boundary (70 is unreachable with weights 40/20/25/15, tested directly)
        t("Coverage Gate — مرز دقیق 70٪", "70/100 -> Complete", "gate(70,100)=${Quality.coverageGate(70, 100)}", Quality.coverageGate(70, 100))
        t("Coverage Gate — زیر مرز 69٪", "69/100 -> Insufficient", "gate(69,100)=${Quality.coverageGate(69, 100)}", !Quality.coverageGate(69, 100))
        t("Coverage Gate — پوشش کامل", "100/100 -> Complete", "gate(100,100)=${Quality.coverageGate(100, 100)}", Quality.coverageGate(100, 100))
        t("Coverage Gate — وزن صفر", "0/0 -> Insufficient", "gate(0,0)=${Quality.coverageGate(0, 0)}", !Quality.coverageGate(0, 0))
        // Shared ping table (#11): for any ping, Gaming's latency part must equal
        // Quality's ping part scaled 35/40 (rounded). Same cutoffs, same relative score.
        val sharedOk = listOf(30.0, 60.0, 100.0, 150.0, 250.0).all { ms ->
            val qp = Quality.pingPoints(ms, 40)
            val prx = PingResult("test", 20, 20, 0.0, ms, ms, ms, ms, ms, ms, ms, 0.0, 0, 0, listOf(ms))
            val gs = Gaming.score(prx, Gaming.Bufferbloat(ms, ms, 0.0, "A", 100))
            gs.latency == (qp * 35 + 20) / 40
        }
        t("Ping Points مشترک (Gaming/Quality)", "برای هر ping، بخش Gaming = گرد شده Quality × 35/40", if (sharedOk) "یکسان ✅" else "متفاوت ❌", sharedOk)
        // v2.8 HistoryRange — one unit, milliseconds, everywhere (the v2.7
        // bug: "7 days" showed 7 hours, "30 days" showed 30 hours).
        val hr24 = History.HistoryRange.H24.millis == 24L * 60 * 60 * 1000
        val hr7 = History.HistoryRange.D7.millis == 7L * 24 * 60 * 60 * 1000
        val hr30 = History.HistoryRange.D30.millis == 30L * 24 * 60 * 60 * 1000
        t("HistoryRange — مدت هر بازه", "24h=86,400,000ms • 7d=604,800,000ms • 30d=2,592,000,000ms", "24h=${History.HistoryRange.H24.millis} 7d=${History.HistoryRange.D7.millis} 30d=${History.HistoryRange.D30.millis}", hr24 && hr7 && hr30)
        val fixedNow = 1_700_000_000_000L
        val cut24 = History.HistoryRange.H24.cutoff(fixedNow) == fixedNow - 86_400_000L
        val cut7 = History.HistoryRange.D7.cutoff(fixedNow) == fixedNow - 604_800_000L
        val cut30 = History.HistoryRange.D30.cutoff(fixedNow) == fixedNow - 2_592_000_000L
        t("HistoryRange — محاسبه cutoff", "cutoff = now - millis برای هر سه بازه با زمان ثابت", "24h=$cut24 7d=$cut7 30d=$cut30", cut24 && cut7 && cut30)
        // Range selection with FIXED timestamps (no "now" anywhere): a sample
        // 1h ago is in 24h; 25h ago is out of 24h but in 7d; 8d ago is out of
        // 7d but in 30d; 31d ago is out of every range. Ping chart, health-%
        // chart, cards and Min/Avg/Max all filter on this one cutoff.
        val h = 3_600_000L; val d = 24 * h
        val pts = listOf(fixedNow - 1 * h to 40.0, fixedNow - 25 * h to 50.0, fixedNow - 8 * d to 60.0, fixedNow - 31 * d to 70.0)
        fun inRangeCount(range: History.HistoryRange): Int = pts.count { it.first >= range.cutoff(fixedNow) }
        val c24 = inRangeCount(History.HistoryRange.H24)
        val c7 = inRangeCount(History.HistoryRange.D7)
        val c30 = inRangeCount(History.HistoryRange.D30)
        t("HistoryRange — انتخاب داده با Timestamp ثابت", "24h=1 • 7d=2 • 30d=3 (نمونه ۳۱ روزه در هیچ بازه‌ای نیست)", "24h=$c24 7d=$c7 30d=$c30", c24 == 1 && c7 == 2 && c30 == 3)
        // v2.8 single-flight via MonitoringEngine.runCheck (the ONE shared
        // guard). If a real check is running right now (background service),
        // the guard is legitimately held — NOT TESTED, not a failure.
        val acq1 = MonitoringEngine.runCheck { try { Thread.sleep(300) } catch (e: Exception) {} }
        val acqHeldByOther = acq1 == null
        val acq2 = if (acq1 != null) MonitoringEngine.runCheck {} else null
        // v2.9: cancel does NOT free the key instantly any more — the old
        // task owns it until it really finishes. Wait for the wind-down
        // (poll isRunning, max 2s) before re-acquiring.
        if (acq1 != null) MonitoringEngine.cancelCheck()
        var acqWaited = 0
        while (MonitoringEngine.isCheckRunning() && acqWaited < 2000) { Thread.sleep(50); acqWaited += 50 }
        val acq3 = MonitoringEngine.runCheck {}
        if (acq3 != null) MonitoringEngine.cancelCheck()
        out.add(TestResult("MonitoringEngine — Single-flight", "Unit — ورودی ثابت، بدون شبکه",
            "اول موفق، دومی رد شد، بعد از لغو و پایان واقعی وظیفه دوباره موفق",
            if (acqHeldByOther) "یک بررسی واقعی در حال اجراست — گارد در اختیار تست نیست" else "1st=${acq1 != null} 2nd=${acq2 == null} 3rd=${acq3 != null} waited=${acqWaited}ms",
            if (acqHeldByOther) null else (acq1 != null && acq2 == null && acq3 != null), "", History.timeStr(System.currentTimeMillis())))
        // MonitoringEngine cadence policy (pure time math).
        val cycOk = MonitoringEngine.shouldRunCycle(0, 31000, 30, true)
        val cycSoon = MonitoringEngine.shouldRunCycle(0, 10000, 30, true)
        val cycOff = MonitoringEngine.shouldRunCycle(0, 31000, 30, false)
        val cycZero = MonitoringEngine.shouldRunCycle(0, 31000, 0, true)
        t("MonitoringEngine — زمان‌بندی چرخه", "31s بعد از 30s مجاز؛ 10s نه؛ خاموش نه؛ فاصله ۰ نه", "31s=$cycOk 10s=$cycSoon off=$cycOff iv0=$cycZero", cycOk && !cycSoon && !cycOff && !cycZero)
        val liveOk = MonitoringEngine.livePingDue(0, 6000, true, true)
        val liveSoon = MonitoringEngine.livePingDue(0, 2000, true, true)
        val liveOff = MonitoringEngine.livePingDue(0, 6000, true, false)
        val liveNoMon = MonitoringEngine.livePingDue(0, 6000, false, true)
        t("MonitoringEngine — زمان‌بندی Live Ping", "6s بعد مجاز؛ 2s نه؛ سوییچ خاموش نه؛ مانیتورینگ خاموش نه", "6s=$liveOk 2s=$liveSoon off=$liveOff noMon=$liveNoMon", liveOk && !liveSoon && !liveOff && !liveNoMon)
        // NetworkEngine single-flight (new API: Future? — null = refused).
        val single1 = NetworkEngine.submitSingle("lab-test-key") { try { Thread.sleep(300) } catch (e: Exception) {} }
        val single2 = NetworkEngine.submitSingle("lab-test-key") {}
        val singleRunning = NetworkEngine.isRunning("lab-test-key")
        Thread.sleep(500)
        val singleAfter = NetworkEngine.isRunning("lab-test-key")
        t("NetworkEngine — Single-flight", "اول Future، دومی null، در حال اجرا true، بعد از پایان false", "1st=${single1 != null} 2nd=${single2 == null} running=$singleRunning after=$singleAfter", single1 != null && single2 == null && singleRunning && !singleAfter)
        // REAL race test: 8 threads submit the same key at the same instant
        // (CountDownLatch release). Exactly one must win; after it finishes,
        // a new submit must succeed again.
        val raceKey = "race-test-key"
        val raceStart = CountDownLatch(1)
        val raceWinners = AtomicInteger(0)
        val raceThreads = (1..8).map {
            Thread {
                raceStart.await()
                val f = NetworkEngine.submitSingle(raceKey) { try { Thread.sleep(300) } catch (e: Exception) {} }
                if (f != null) raceWinners.incrementAndGet()
            }
        }
        raceThreads.forEach { it.start() }
        raceStart.countDown()
        raceThreads.forEach { it.join(5000) }
        Thread.sleep(500)
        val raceAfter = NetworkEngine.submitSingle(raceKey) {}
        val raceAfterOk = raceAfter != null
        if (raceAfter != null) NetworkEngine.cancelSingle(raceKey)
        t("NetworkEngine — Race Condition", "۸ نخ هم‌زمان → دقیقاً ۱ برنده؛ بعد از پایان، submit دوباره موفق", "winners=${raceWinners.get()} after=$raceAfterOk", raceWinners.get() == 1 && raceAfterOk)
        // Activity + Service non-concurrency: two threads racing for the ONE
        // shared "check" guard (one simulates the manual button, the other
        // the background cycle). Exactly one may run. If a real check is
        // already running, both are refused — NOT TESTED, not a failure.
        val concStart = CountDownLatch(1)
        val concResults = java.util.Collections.synchronizedList(mutableListOf<Boolean>())
        val concThreads = (1..2).map {
            Thread {
                concStart.await()
                concResults.add(MonitoringEngine.runCheck { try { Thread.sleep(300) } catch (e: Exception) {} } != null)
            }
        }
        concThreads.forEach { it.start() }
        concStart.countDown()
        concThreads.forEach { it.join(5000) }
        val concWins = concResults.count { it }
        MonitoringEngine.cancelCheck()
        val concPass: Boolean? = when {
            concResults.size < 2 -> null
            concWins == 0 -> null // a real check held the guard — not a failure
            else -> concWins == 1
        }
        out.add(TestResult("MonitoringEngine — عدم هم‌زمانی Activity و Service", "دو نخ هم‌زمان برای گارد check (دستی + پس‌زمینه)",
            "دقیقاً ۱ برنده",
            "wins=$concWins/2" + if (concWins == 0) " — یک بررسی واقعی در حال اجراست" else "",
            concPass, "", History.timeStr(System.currentTimeMillis())))
        // Several consecutive cycles must NOT create extra thread pools: the
        // shared pool stays at 4 "netwatch-net" threads and no default-named
        // "pool-" threads appear. (runLight does real network here; the
        // assertion is only about threads, not about probe success.)
        fun countThreads(prefix: String) = Thread.getAllStackTraces().keys.count { it.name.startsWith(prefix) }
        val poolBefore = countThreads("pool-")
        repeat(5) { NetworkEngine.runProbes(true) }
        val poolAfter = countThreads("pool-")
        val netCount = countThreads("netwatch-net")
        t("Executor — چرخه‌های متوالی بدون Pool اضافی", "۵ چرخه light پشت سر هم → نخ‌های netwatch-net همان ۴ تا، pool- جدید صفر", "netwatch-net=$netCount pool- before=$poolBefore after=$poolAfter", netCount == 4 && poolAfter == poolBefore)
        // Cancellation: a long task is interrupted, the guard is released,
        // and a new submit for the same key succeeds.
        val cancelInterrupted = AtomicBoolean(false)
        val cancelStarted = AtomicBoolean(false)
        val cancelF = NetworkEngine.submitSingle("cancel-test-key") {
            cancelStarted.set(true)
            try { Thread.sleep(10_000) } catch (e: InterruptedException) { cancelInterrupted.set(true) }
        }
        val cancelGot = cancelF != null
        // v2.9.1: wait until the task REALLY started — cancelling a task
        // that has not started yet removes it cleanly and the interrupt
        // flag is never set (that is correct, not a failure).
        var cancelStartWait = 0
        while (!cancelStarted.get() && cancelStartWait < 2000) { Thread.sleep(10); cancelStartWait += 10 }
        NetworkEngine.cancelSingle("cancel-test-key")
        var cancelWaited = 0
        while (!cancelInterrupted.get() && cancelWaited < 2000) { Thread.sleep(50); cancelWaited += 50 }
        // v2.9: the key is freed only when the interrupted task REALLY ends
        // (its finally), not at the cancel call — wait for the wind-down.
        var cancelFreed = 0
        while (NetworkEngine.isRunning("cancel-test-key") && cancelFreed < 2000) { Thread.sleep(50); cancelFreed += 50 }
        val cancelResubmit = NetworkEngine.submitSingle("cancel-test-key") {}
        if (cancelResubmit != null) NetworkEngine.cancelSingle("cancel-test-key")
        t("NetworkEngine — Cancellation و آزادسازی", "لغو → نخ قطع شد، گارد بعد از پایان واقعی آزاد شد، submit دوباره موفق", "got=$cancelGot interrupted=${cancelInterrupted.get()} running=${NetworkEngine.isRunning("cancel-test-key")} resubmit=${cancelResubmit != null}", cancelGot && cancelInterrupted.get() && !NetworkEngine.isRunning("cancel-test-key") && cancelResubmit != null)
        // AnalyticsEngine delegates to the same functions the UI used to call
        // directly — identical values, one API.
        val aeScore = AnalyticsEngine.gamingScore(pr, Gaming.Bufferbloat(40.0, 45.0, 5.0, "A", 100))
        t("AnalyticsEngine — Gaming Score", "همان Gaming.score مستقیم (total=100)", "total=${aeScore.total}", aeScore.total == sc.total && aeScore.total == 100)
        val aeQ = AnalyticsEngine.qualityScore(40.0, 3.0, 0.0, 100)
        t("AnalyticsEngine — Quality Score", "همان Quality.compute مستقیم (Complete, 100)", "نوع ${aeQ::class.simpleName}", aeQ is Quality.ScoreResult.Complete && aeQ.total == 100)
        val aeStats = AnalyticsEngine.burstStats(listOf(42.0, 48.0, 50.0, 55.0, 72.0), 5)
        t("AnalyticsEngine — Burst Stats", "avg 53.4 مثل Lab.computeStats", "avg ${"%.1f".format(aeStats.avg)}", aeStats.avg == 53.4)
        val aeChart = AnalyticsEngine.chartStats(listOf(now to 40.0, now + 1000 to -1.0, now + 2000 to 60.0))
        t("AnalyticsEngine — Chart Stats", "failed=1، avg فقط موفق‌ها=50", "failed=${aeChart.failed} avg=${aeChart.avg}", aeChart.failed == 1 && aeChart.avg == 50.0)
        // v2.9: a task that IGNORES interrupts must still own its key until
        // it REALLY finishes — the second submit right after cancel is
        // refused, isRunning stays true during the wind-down, and no two
        // tasks with the same key ever overlap (max concurrency stays 1).
        val ignRunning = AtomicInteger(0)
        val ignMax = AtomicInteger(0)
        val ignStarted = AtomicBoolean(false)
        val ignDone = AtomicBoolean(false)
        val ignKey = "ignore-interrupt-key"
        val ignF = NetworkEngine.submitSingle(ignKey) {
            ignStarted.set(true)
            val cur = ignRunning.incrementAndGet()
            ignMax.accumulateAndGet(cur) { a, b -> maxOf(a, b) }
            val end = System.nanoTime() + 2_000_000_000L
            try {
                while (System.nanoTime() < end) {
                    try { Thread.sleep(100) } catch (e: InterruptedException) { /* ignored on purpose */ }
                }
            } finally { ignRunning.decrementAndGet(); ignDone.set(true) }
        }
        val ignGot = ignF != null
        var ignStartWait = 0
        while (!ignStarted.get() && ignStartWait < 2000) { Thread.sleep(50); ignStartWait += 50 }
        val ignPass: Boolean?
        val ignActual: String
        if (!ignStarted.get()) {
            // The pool was busy (a real check running) — the task never
            // started, so this test cannot run: NOT TESTED, not a failure.
            ignPass = null
            ignActual = "وظیفه شروع نشد — Pool مشغول یک بررسی واقعی بود"
            if (ignF != null) NetworkEngine.cancelSingle(ignKey)
        } else {
            NetworkEngine.cancelSingle(ignKey)
            val ignRefused = NetworkEngine.submitSingle(ignKey) {} == null
            val ignStillRunning = NetworkEngine.isRunning(ignKey)
            var ignWaited = 0
            while (!ignDone.get() && ignWaited < 3000) { Thread.sleep(50); ignWaited += 50 }
            val ignAfter = NetworkEngine.submitSingle(ignKey) {}
            val ignAfterOk = ignAfter != null
            if (ignAfter != null) NetworkEngine.cancelSingle(ignKey)
            ignPass = ignGot && ignRefused && ignStillRunning && ignMax.get() == 1 && ignDone.get() && ignAfterOk
            ignActual = "got=$ignGot refused=$ignRefused running=$ignStillRunning maxConc=${ignMax.get()} after=$ignAfterOk"
        }
        out.add(TestResult("NetworkEngine — لغو وظیفه‌ای که Interrupt را نادیده می‌گیرد", "وظیفه ۲ ثانیه‌ای با نادیده‌گرفتن Interrupt؛ لغو → submit دوم رد شد؛ بعد از پایان واقعی submit موفق؛ هم‌زمانی هرگز ۲ نشد",
            "refused=true • running=true • maxConc=1 • after=true",
            ignActual, ignPass, "", History.timeStr(System.currentTimeMillis())))
        // v2.9: a task still QUEUED (pool saturated) can be cancelled without
        // a leak — it never runs, and the key is free immediately after.
        val qRan = AtomicBoolean(false)
        val qRan2 = AtomicBoolean(false)
        val qKey = "queued-test-key"
        val qFillers = (0..3).map { i ->
            NetworkEngine.submitSingle("qfill-$i") { try { Thread.sleep(1000) } catch (e: Exception) {} }
        }
        val qF = NetworkEngine.submitSingle(qKey) { qRan.set(true) }
        val qGot = qF != null
        val qEntryExists = NetworkEngine.isRunning(qKey)
        NetworkEngine.cancelSingle(qKey)
        Thread.sleep(1500)
        val qNeverRan = !qRan.get()
        val qFreeAfterCancel = !NetworkEngine.isRunning(qKey)
        val qNew = NetworkEngine.submitSingle(qKey) { qRan2.set(true) }
        val qNewOk = qNew != null
        var qWaited = 0
        while (!qRan2.get() && qWaited < 5000) { Thread.sleep(50); qWaited += 50 }
        t("NetworkEngine — لغو وظیفه صف‌شده (QUEUED)", "Pool با ۴ وظیفه پر شد؛ وظیفه پنجم در صف لغو شد → هرگز اجرا نشد، key بلافاصله آزاد شد، submit دوباره موفق و اجرا شد", "got=$qGot entry=$qEntryExists neverRan=$qNeverRan free=$qFreeAfterCancel new=$qNewOk ran2=${qRan2.get()}", qGot && qEntryExists && qNeverRan && qFreeAfterCancel && qNewOk && qRan2.get())
        // v2.9 socket guard: 200 failed TCP connects must not grow the
        // open-FD count by more than a small bound. Honest note: on this JDK
        // a failed connect closes the FD even without `use`, so this test
        // passes before the fix too — it is a regression guard; the real
        // assurance is the `use` in tcpProbe/tcpTime/quicUdp.
        val fdBefore = try { java.io.File("/proc/self/fd").list()?.size ?: -1 } catch (e: Exception) { -1 }
        repeat(200) { NetworkEngine.tcp("127.0.0.1", 1) }
        val fdAfter = try { java.io.File("/proc/self/fd").list()?.size ?: -1 } catch (e: Exception) { -1 }
        val fdGrowth = if (fdBefore < 0 || fdAfter < 0) -1 else fdAfter - fdBefore
        t("Sockets — FD پس از ۲۰۰ TCP ناموفق", "رشد FD حداکثر ۵ (نگهبان رگرسیون — اثبات اصلی، use در کد است)", "before=$fdBefore after=$fdAfter growth=$fdGrowth", fdGrowth in 0..5)
        // v2.9.2 — QUEUED-cancel race, DETERMINISTIC via the key-scoped
        // test gate: only the Callable whose key equals testGateKey parks
        // at the gate and signals entry. The test (a) parks the gateKey
        // Callable, (b) proves ANOTHER Callable with a different key runs
        // freely while the gate is set (isolation — a background check can
        // neither trip the test nor be delayed by it), (c) cancels the
        // gateKey entry, opens the gate, and asserts the task never ran.
        // With the v2.9 callable (no ownership check) this FAILS — the
        // test was verified to fail against it.
        val gateKey = "queued-cancel-race-key"
        val gateRan = AtomicBoolean(false)
        val gateEntered = AtomicBoolean(false)
        val otherRan = AtomicBoolean(false)
        val gate = java.util.concurrent.CountDownLatch(1)
        val gatePass: Boolean?
        val gateActual: String
        try {
            NetworkEngine.testGateKey = gateKey
            NetworkEngine.testCallableEntered = gateEntered
            NetworkEngine.testPreRunGate = gate
            val gateF = NetworkEngine.submitSingle(gateKey) { gateRan.set(true) }
            val gateGot = gateF != null
            var gateWaited = 0
            while (!gateEntered.get() && gateWaited < 2000) { Thread.sleep(10); gateWaited += 10 }
            if (!gateEntered.get()) {
                // The pool was busy — the Callable never reached the gate,
                // so this interleaving could not be forced: NOT TESTED.
                gatePass = null
                gateActual = "Callable به gate نرسید — Pool مشغول یک بررسی واقعی بود"
                if (gateF != null) NetworkEngine.cancelSingle(gateKey)
            } else {
                // Isolation: a Callable with a DIFFERENT key must run
                // freely while the gate is set (it must not wait at the
                // gate and must not touch the entry signal).
                val otherF = NetworkEngine.submitSingle("other-key-isolation") { otherRan.set(true) }
                Thread.sleep(200)
                val otherOk = otherF != null && otherRan.get()
                // The gateKey Callable is parked at the gate: cancel MUST
                // see QUEUED and remove the entry. Then open the gate.
                NetworkEngine.cancelSingle(gateKey)
                val gateFreed = !NetworkEngine.isRunning(gateKey)
                gate.countDown()
                Thread.sleep(300)
                gatePass = gateGot && otherOk && gateFreed && !gateRan.get()
                gateActual = "got=$gateGot otherRan=$otherOk entryFreed=$gateFreed ran=${gateRan.get()}"
            }
        } finally {
            NetworkEngine.testGateKey = null
            NetworkEngine.testPreRunGate = null
            NetworkEngine.testCallableEntered = null
        }
        out.add(TestResult("NetworkEngine — Race لغو QUEUED در شروع Callable", "Callable در gate متوقف شد؛ یک Callable دیگر با key متفاوت آزادانه اجرا شد؛ cancel ورودی را حذف کرد؛ بعد از بازشدن gate، task نباید اجرا شود",
            "got=true • otherRan=true • entryFreed=true • ran=false",
            gateActual, gatePass, "", History.timeStr(System.currentTimeMillis())))
        // v2.4: old 3-field samples parse with -1 metrics; new 6-field samples keep values.
        val sOld = History.parseSample("1700000000000,35,40")
        val sNew = History.parseSample("1700000000000,35,40,120.5,8.2,0.0")
        t("Sample قدیمی (۳ فیلد)", "بدون پینگ/جیتر/قطعی = -1", if (sOld != null && sOld.avgMs == -1.0 && sOld.lossPct == -1.0) "سازگار ✅" else "خراب ❌", sOld != null && sOld.avgMs == -1.0)
        t("Sample جدید (۶ فیلد)", "مقادیر حفظ شوند", if (sNew != null && sNew.avgMs == 120.5 && sNew.jitterMs == 8.2) "درست ✅" else "خراب ❌", sNew != null && sNew.avgMs == 120.5 && sNew.jitterMs == 8.2)
        // v2.4: timeline lines parse into time/kind/text.
        val evs = History.parseTimeline("12:30 [outage-start] شروع اختلال در 12:30 — دسترسی ۳۰٪\n12:45 [network-change] تغییر شبکه")
        t("Timeline parse", "نوع و زمان جدا شوند", if (evs.size == 2 && evs[0].kind == "outage-start" && evs[1].time == "12:45") "درست ✅" else "خراب ❌", evs.size == 2 && evs[0].kind == "outage-start" && evs[1].time == "12:45")
        // v2.4: one status vocabulary — same score, same word, app and widget alike.
        val stOk = Quality.widgetStatus(85, "Complete") == "Connected" && Quality.widgetStatus(60, "Complete") == "Degraded" && Quality.widgetStatus(30, "Complete") == "Offline" && Quality.widgetStatus(null, "InsufficientData") == "Degraded"
        t("Widget Status از امتیاز", "۸۵→Connected، ۶۰→Degraded، ۳۰→Offline", if (stOk) "یکسان ✅" else "متفاوت ❌", stOk)
        // Chart: values must be in 0..100 and count preserved
        val chart = listOf(42.0, 48.0, 72.0).map { (it / 2).toInt().coerceIn(0, 100) }
        t("صحت داده نمودار", "[21, 24, 36]", chart.toString(), chart == listOf(21, 24, 36))
        return out
    }

    fun save(ctx: Context, results: List<TestResult>) {
        val p = ctx.getSharedPreferences("lab", Context.MODE_PRIVATE)
        val old = p.getString("results", "") ?: ""
        val text = results.joinToString("\n") { "${it.date} | ${it.name} | ${if (it.pass == true) "PASS" else if (it.pass == false) "FAIL" else "NOT TESTED"} | expected: ${it.expected} | actual: ${it.actual} | ${it.error}" }
        p.edit().putString("results", (text + "\n" + old).lines().take(200).joinToString("\n")).apply()
    }
    fun load(ctx: Context): String = ctx.getSharedPreferences("lab", Context.MODE_PRIVATE).getString("results", "") ?: ""
}
