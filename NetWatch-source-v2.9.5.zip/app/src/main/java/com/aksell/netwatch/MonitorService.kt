package com.aksell.netwatch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

// Background monitoring (v2.6): foreground service so Android does not kill
// it immediately. NOTE (honest Android limit): on Android 6+ Doze/App Standby
// can still delay background work; foreground service + notification is the
// reliable route, and the widget updates on each check.
//
// v2.6 changes:
// - Background cycles run a LIGHT check (8 probes, ~2-3s) instead of the full
//   40+ probe run every 30s — far less battery and data.
// - The user-set interval is re-read on EVERY cycle, so changing it in
//   Settings applies to the running service immediately.
// - Live Ping shares the one managed executor (no new Thread per 5s tick)
//   and is skipped while a check is running — no duplicate ping measurements.
// - The widget's Live state is based on a heartbeat timestamp (written on
//   every successful refresh), not on a static boolean.
class MonitorService : Service() {
    companion object { @Volatile var running = false }
    private val handler = Handler(Looper.getMainLooper())
    // No local futures or flags: the single shared guard lives in
    // MonitoringEngine/NetworkEngine.submitSingle. This service only owns its
    // Handler loops, which Android requires to live here. Cancellation goes
    // through MonitoringEngine.cancelCheck()/cancelLivePing().

    private val loop = object : Runnable {
        override fun run() {
            val iv = History.intervalSec(this@MonitorService)
            HistoryEngine.setLastAttempt(this@MonitorService)
            // If a manual check is running, this cycle is skipped — the ONE
            // shared guard refuses a duplicate run. No finally is needed:
            // submitSingle removes the registry entry on completion.
            val f = MonitoringEngine.runCheck {
                try {
                    val results = NetworkEngine.runProbes(true)
                    val ok = results.count { it.ok }
                    val pct = if (results.isEmpty()) 0 else ok * 100 / results.size
                    val pingBg = NetworkEngine.pingStats("1.1.1.1")
                    HistoryEngine.recordPing(this@MonitorService, pingBg)
                    val intl = results.filter { !it.domestic }; val dom = results.filter { it.domestic }
                    val intlPct = if (intl.isEmpty()) 0 else intl.count { it.ok } * 100 / intl.size
                    val domPct = if (dom.isEmpty()) 0 else dom.count { it.ok } * 100 / dom.size
                    History.addHourly(this@MonitorService, ok, results.size)
                    // The quality score is computed once, and only when the ping
                    // burst completed; a failed cycle still records its sample
                    // but does not overwrite the "last check" summary.
                    val q = if (pingBg.completed) AnalyticsEngine.qualityScore(pingBg.avgMs, pingBg.jitterMs, pingBg.lossPct.toDouble(), pct,
                        pingValid = pingBg.ok && pingBg.avgMs > 0,
                        jitterValid = pingBg.completed && pingBg.lossPct <= 50,
                        lossValid = pingBg.completed, stabValid = results.isNotEmpty()) else null
                    val scoreTotal = when (q) { is Quality.ScoreResult.Complete -> q.total; else -> null }
                    val scoreStatus = when (q) { is Quality.ScoreResult.Complete -> "Complete"; is Quality.ScoreResult.InsufficientData -> "InsufficientData"; Quality.ScoreResult.NotAvailable -> "NotAvailable"; null -> "NotAvailable" }
                    if (pingBg.completed) History.saveConnType(this@MonitorService, Geo.connectionType(this@MonitorService))
                    HistoryEngine.recordCheck(this@MonitorService, ok, results.size,
                        if (pingBg.ok) pingBg.avgMs else -1.0,
                        if (pingBg.ok) pingBg.jitterMs else -1.0,
                        if (pingBg.ok) pingBg.lossPct.toDouble() else -1.0,
                        intlPct, domPct, scoreTotal, scoreStatus, "background", saveSummary = pingBg.completed)
                    History.blackbox(this@MonitorService, "$ok/${results.size} ok ($pct%) — light check")
                    val prev = History.lastPct(this@MonitorService)
                    val th = History.alertThreshold(this@MonitorService)
                    if (pct < th && prev >= th) alert("⚠️ قطعی اینترنت", "دسترسی به $pct٪ مقصدها قطع شد (آستانه هشدار $th٪) — جزئیات در Blackbox ثبت شد.")
                    if (pct >= 70 && prev < th) alert("✅ اتصال برگشت", "اینترنت دوباره سالم شد ($pct٪ مقصدها).")
                    History.setLastPct(this@MonitorService, pct)
                    HistoryEngine.setLastSuccess(this@MonitorService)
                    NetWatchWidget.refreshAll(this@MonitorService)
                    HistoryEngine.setHeartbeat(this@MonitorService)
                } catch (e: Exception) {
                    // Crash protection: a failed check must never kill the service
                    History.addLog(this@MonitorService, "خطا در بررسی پس‌زمینه: ${e.javaClass.simpleName}")
                }
            }
            if (f == null) { handler.postDelayed(this, iv * 1000L); return }
            handler.postDelayed(this, iv * 1000L)
        }
    }

    // Live Ping: one ICMP ping every 5s while this service runs, only when the
    // user enabled it in Settings. A 1-second loop is not used: Android throttles
    // widget updates and it would burn battery for no visible benefit.
    // Skipped while a background check is running (no duplicate measurement).
    private val liveLoop = object : Runnable {
        override fun run() {
            // One live ping at a time: the guard is atomic, so a slow ping can
            // never stack a second one on top of it. Skipped while a check runs.
            if (MonitoringEngine.livePingOn(this@MonitorService) && !MonitoringEngine.isCheckRunning()) {
                MonitoringEngine.runLivePing {
                    try {
                        val ms = NetworkEngine.pingOnce("1.1.1.1")
                        HistoryEngine.recordPingMs(this@MonitorService, ms)
                        if (ms != null) {
                            NetWatchWidget.refreshAll(this@MonitorService)
                            HistoryEngine.setHeartbeat(this@MonitorService)
                        }
                    } catch (e: Exception) {}
                }
            }
            handler.postDelayed(this, 5000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        History.ensureRecovered(this)
        running = true
        MonitoringEngine.setServiceRunning(true)
        val iv = History.intervalSec(this)
        handler.post(liveLoop)
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("netwatch", "NetWatch monitoring", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val notif = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "netwatch").setContentTitle("NetWatch در حال بررسی اینترنت است").setContentText("بررسی سبک هر $iv ثانیه — برای توقف، از داخل اپ خاموش کن.").setSmallIcon(R.drawable.netwatch_icon).build()
        else Notification.Builder(this).setContentTitle("NetWatch در حال بررسی اینترنت است").setSmallIcon(R.drawable.netwatch_icon).build()
        startForeground(1, notif)
        handler.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    private fun alert(title: String, text: String) {
        if (!History.alertsOn(this)) return
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("netwatch-alert", "NetWatch alerts", NotificationManager.IMPORTANCE_DEFAULT))
            val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "netwatch-alert").setContentTitle(title).setContentText(text).setSmallIcon(R.drawable.netwatch_icon).build()
            else Notification.Builder(this).setContentTitle(title).setContentText(text).setSmallIcon(R.drawable.netwatch_icon).build()
            nm.notify(2, n)
        } catch (e: Exception) {}
    }
    override fun onDestroy() {
        handler.removeCallbacks(loop); handler.removeCallbacks(liveLoop)
        MonitoringEngine.cancelCheck(); MonitoringEngine.cancelLivePing()
        MonitoringEngine.setServiceRunning(false)
        running = false; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
