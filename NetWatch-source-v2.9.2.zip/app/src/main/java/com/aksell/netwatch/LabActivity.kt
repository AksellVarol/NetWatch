package com.aksell.netwatch

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class LabActivity : Activity() {
    private lateinit var tv: TextView
    private val allResults = mutableListOf<TestResult>()

    private fun setBadge(v: TextView, text: String, colorHex: String) {
        v.text = text
        v.setTextColor(Color.parseColor(colorHex))
    }
    private fun badgeFor(rs: List<TestResult>): Pair<String, String> {
        val tested = rs.filter { it.pass != null }
        return when {
            tested.isEmpty() -> "NOT TESTED" to "#94A3B8"
            tested.all { it.pass == true } -> "PASS" to "#22C55E"
            tested.any { it.pass == false } -> "FAIL" to "#EF4444"
            else -> "PARTIAL" to "#F59E0B"
        }
    }
    private fun formatResults(rs: List<TestResult>): String =
        rs.joinToString("\n\n") { "${if (it.pass == true) "✅ PASS" else if (it.pass == false) "❌ FAIL" else "⏸ NOT TESTED"} — ${it.name}\nروش: ${it.method}\nمورد انتظار: ${it.expected}\nواقعی: ${it.actual}${if (it.error.isNotBlank()) "\nخطا: ${it.error}" else ""}" } +
            "\n\n— تاریخچه تست‌ها —\n" + Lab.load(this)

    private fun showResults(rs: List<TestResult>) {
        Lab.save(this, rs)
        tv.text = formatResults(rs)
    }
    // Render without saving — used by RUN ALL so history is saved once at the end.
    private fun renderOnly(rs: List<TestResult>) { tv.text = formatResults(rs) }

    // ---- One section = one synchronous function returning its results. ----
    // Row taps and RUN ALL both use these, so a section can never be skipped.

    private fun unitSection(): List<TestResult> {
        val rs = Lab.unitTests().toMutableList()
        val again = Lab.unitTests()
        val now = History.timeStr(System.currentTimeMillis())
        rs.add(TestResult("Regression — تکرار Unit Tests", "اجرای دوباره همان تست‌ها با همان ورودی", "نتیجه دقیقاً یکسان", if (again.map { it.pass } == Lab.unitTests().map { it.pass }) "یکسان ✅" else "متفاوت ❌", again.map { it.pass } == Lab.unitTests().map { it.pass }, "", now))
        val sim = Lab.computeStats(listOf(40.0, 45.0, 200.0, 42.0, 44.0), 10)
        rs.add(TestResult("Network Simulation — شبکه شبیه‌سازی‌شده", "SIMULATION: داده مصنوعی با Loss 50٪ و Spike 200ms", "Loss 50٪، Spike شناسایی شود", "Loss ${sim.lossPct}٪، Max ${sim.max}ms — شبیه‌سازی، نه شبکه واقعی", sim.lossPct == 50.0, "SIMULATION", now))
        // v2.6 on-device: History round-trip — addSample writes 6 fields,
        // samples()/samplesFull() must return the exact same rows (the v2.5 bug
        // returned nothing here). Test rows are removed afterwards.
        val rt0 = System.currentTimeMillis()
        History.addSample(this, 38, 40, 120.5, 8.2, 0.0, "lab-test")
        History.addSample(this, 35, 40, 200.0, 15.0, 2.5, "lab-test")
        History.addSample(this, 0, 40, -1.0, -1.0, -1.0, "lab-test")
        val afterRt = History.samplesFull(this)
        val added = afterRt.filter { it.time >= rt0 }
        val rtOk = added.size == 3 &&
            added[0].ok == 38 && added[0].total == 40 && added[0].avgMs == 120.5 && added[0].jitterMs == 8.2 && added[0].lossPct == 0.0 &&
            added[1].avgMs == 200.0 && added[1].jitterMs == 15.0 && added[1].lossPct == 2.5 &&
            added[2].avgMs == -1.0 && added[2].lossPct == -1.0
        val triplesOk = History.samples(this).size == afterRt.size
        History.deleteSamplesSince(this, rt0)
        val cleaned = History.samplesFull(this).none { it.time >= rt0 }
        rs.add(TestResult("History Round-trip — ذخیره و بازیابی ۶ فیلدی", "۳ رکورد addSample → samples()/samplesFull() → مقایسه دقیق مقادیر → حذف ردیف‌های تست", "۳ رکورد، مقادیر دقیقاً برابر، samples() هم‌اندازه samplesFull()", "بازیابی ${added.size} رکورد • مقادیر ${if (rtOk) "دقیقاً برابر ✅" else "متفاوت ❌"} • samples() هم‌اندازه: $triplesOk • پاک‌سازی ردیف‌های تست: $cleaned", rtOk && triplesOk && cleaned, "", now))
        // v2.8 on-device: range filter with FIXED timestamps (the v2.7 bug
        // made "7 days" show 7 hours and "30 days" show 30 hours). Four rows
        // are inserted directly with explicit times; only the test rows are
        // counted, so the user's real samples cannot skew the result.
        val nowR = System.currentTimeMillis()
        val hMs = 3_600_000L; val dMs = 24 * hMs
        val rangeRows = listOf(nowR - 1 * hMs, nowR - 25 * hMs, nowR - 8 * dMs, nowR - 31 * dMs)
        val dbW = HistoryDb.get(this).writableDatabase
        dbW.beginTransaction()
        try {
            for (ts in rangeRows) {
                val cv = android.content.ContentValues()
                cv.put("time", ts); cv.put("ok", 40); cv.put("total", 40)
                cv.put("avg_ms", 50.0); cv.put("jitter_ms", 5.0); cv.put("loss_pct", 0.0)
                cv.put("source", "lab-range-test")
                dbW.insert("samples", null, cv)
            }
            dbW.setTransactionSuccessful()
        } finally { dbW.endTransaction() }
        val r24 = History.samplesInRange(this, History.HistoryRange.H24.cutoff(nowR)).count { it.time in rangeRows }
        val r7 = History.samplesInRange(this, History.HistoryRange.D7.cutoff(nowR)).count { it.time in rangeRows }
        val r30 = History.samplesInRange(this, History.HistoryRange.D30.cutoff(nowR)).count { it.time in rangeRows }
        dbW.delete("samples", "source=?", arrayOf("lab-range-test"))
        rs.add(TestResult("History Range — فیلتر ۲۴ ساعت / ۷ روز / ۳۰ روز (روی دستگاه)", "۴ ردیف با زمان ثابت: ۱ ساعت، ۲۵ ساعت، ۸ روز، ۳۱ روز پیش → شمارش در هر بازه", "24h=1 • 7d=2 • 30d=3", "24h=$r24 7d=$r7 30d=$r30", r24 == 1 && r7 == 2 && r30 == 3, "", now))
        // v2.9 on-device: >5000 rows with FIXED timestamps (the v2.8 bug:
        // "time ASC LIMIT 5000" returned the OLDEST 5000, so ranged views and
        // backups lost every new row once the table passed 5000 rows).
        // Everything runs inside ONE transaction that is ROLLED BACK at the
        // end — the test rows never touch the user's real history.
        val nowR2 = System.currentTimeMillis()
        val sTimes = (0 until 6000).map { nowR2 - it * 60_000L }.toSet()
        val pTimes = (0 until 6000).map { nowR2 - it * 5_000L }.toSet()
        val dbT = HistoryDb.get(this).writableDatabase
        dbT.beginTransaction()
        try {
            for (ts in sTimes) {
                val cv = android.content.ContentValues()
                cv.put("time", ts); cv.put("ok", 40); cv.put("total", 40)
                cv.put("avg_ms", 50.0); cv.put("jitter_ms", 5.0); cv.put("loss_pct", 0.0)
                cv.put("source", "lab-6000-test")
                dbT.insert("samples", null, cv)
            }
            for (ts in pTimes) {
                val cv = android.content.ContentValues()
                cv.put("time", ts); cv.put("ms", 50.0); cv.put("ok", 1)
                dbT.insert("ping_points", null, cv)
            }
            // Loss values 1000..1099 are impossible in real data (loss is
            // 0..100), so the newest-60 check can identify test rows exactly.
            for (k in 0 until 100) {
                val cv = android.content.ContentValues()
                cv.put("time", nowR2 - k * 60_000L); cv.put("loss", 1000.0 + k)
                dbT.insert("loss_points", null, cv)
            }
            // 24h of 1-min samples = k=0..1440 (inclusive cutoff) = 1441 rows;
            // 7d and 30d hold all 6000 (6000 min = 4.2 days).
            val s24 = History.samplesInRange(this, History.HistoryRange.H24.cutoff(nowR2)).count { it.time in sTimes }
            val s7 = History.samplesInRange(this, History.HistoryRange.D7.cutoff(nowR2)).count { it.time in sTimes }
            val s30 = History.samplesInRange(this, History.HistoryRange.D30.cutoff(nowR2)).count { it.time in sTimes }
            val s24HasNewest = History.samplesInRange(this, History.HistoryRange.H24.cutoff(nowR2)).any { it.time == nowR2 }
            rs.add(TestResult("History — بیش از ۵۰۰۰ رکورد (روی دستگاه)", "۶۰۰۰ نمونه با زمان ثابت (۱ دقیقه‌ای) → فیلتر ۲۴ ساعت / ۷ روز / ۳۰ روز", "24h=1441 • 7d=6000 • 30d=6000 • جدیدترین ردیف حاضر", "24h=$s24 7d=$s7 30d=$s30 newest=$s24HasNewest", s24 == 1441 && s7 == 6000 && s30 == 6000 && s24HasNewest, "", now))
            // 24h of 5s ping points = 17,280 rows → the chart cap keeps the
            // NEWEST 5000; the backup path (limit=0) must return all 6000.
            val p24 = History.pingPoints(this, History.HistoryRange.H24.cutoff(nowR2)).count { it.first in pTimes }
            val p24HasNewest = History.pingPoints(this, History.HistoryRange.H24.cutoff(nowR2)).any { it.first == nowR2 }
            val pAll = History.pingPoints(this, limit = 0).count { it.first in pTimes }
            rs.add(TestResult("Ping Points — بیش از ۵۰۰۰ رکورد (روی دستگاه)", "۶۰۰۰ نقطه پینگ (۵ ثانیه‌ای) → نمودار ۲۴ ساعته جدیدترین ۵۰۰۰ را دارد؛ مسیر بکاپ همه را دارد", "24h=5000 • newest حاضر • backup=6000", "24h=$p24 newest=$p24HasNewest backup=$pAll", p24 == 5000 && p24HasNewest && pAll == 6000, "", now))
            // lossHistory must be the NEWEST 60 (k=0..59 → 1000..1059 ASC).
            val lh = History.lossHistory(this).filter { it >= 1000.0 }
            val lhOk = lh == (0 until 60).map { 1000.0 + it }
            rs.add(TestResult("Loss History — جدیدترین ۶۰ رکورد (روی دستگاه)", "۱۰۰ مقدار loss آزمایشی (۱۰۰۰ تا ۱۰۹۹) → lossHistory باید ۶۰ جدیدترین را برگرداند", "60 مقدار: 1000 تا 1059 به ترتیب صعودی", "testRows=${lh.size} first=${lh.firstOrNull()} last=${lh.lastOrNull()}", lhOk, "", now))
            // Backup/Restore with >5000 rows: the backup must contain EVERY
            // valid row, and restoring it must give back the same counts.
            val bJson2 = History.buildBackupJson(this)
            val bRoot2 = org.json.JSONObject(bJson2)
            val bSamp2 = bRoot2.getJSONArray("samples").length()
            val bPing2 = bRoot2.getJSONArray("ping_points").length()
            val fullSamp = History.samplesFull(this).size
            val fullPing = History.pingPoints(this, limit = 0).size
            val rReason2 = History.restoreFromJson(this, bJson2)
            val rSamp2 = History.samplesFull(this).size
            val rPing2 = History.pingPoints(this, limit = 0).size
            rs.add(TestResult("Backup/Restore — بیش از ۵۰۰۰ رکورد (روی دستگاه)", "buildBackupJson → شمارش ردیف‌های JSON با جدول → restoreFromJson همان JSON → مقایسه تعدادها", "JSON همه ردیف‌ها را دارد، restore=OK، تعدادها قبل = بعد", "samples JSON=$bSamp2 جدول=$fullSamp • ping JSON=$bPing2 جدول=$fullPing • restore=$rReason2 • بعد: $rSamp2/$rPing2", bSamp2 == fullSamp && bPing2 == fullPing && rReason2 == "OK" && rSamp2 == fullSamp && rPing2 == fullPing, "", now))
            // Restore pre-validation: a file with ONE malformed row must be
            // rejected with an exact error and leave the data untouched.
            val badRoot = org.json.JSONObject(bJson2)
            badRoot.getJSONArray("samples").getJSONObject(0).remove("time")
            val badJson = badRoot.toString()
            val preSamp = History.samplesFull(this).size
            val badReason = History.restoreFromJson(this, badJson)
            val postSamp = History.samplesFull(this).size
            rs.add(TestResult("Restore — ردیف خراب (اعتبارسنجی پیش از تراکنش)", "حذف فیلد time از یک ردیف samples در JSON → restore باید رد کند و داده دست نخورده بماند", "خطای دقیق + داده سالم", "نتیجه: $badReason • داده دست نخورده: ${preSamp == postSamp}", badReason != "OK" && preSamp == postSamp, "", now))
            // v2.9.1 — settings / last_check / score_total / gaming session:
            // restoreFromJson این بخش‌ها را AFTER تراکنش می‌خواند؛ در ۲.۹
            // اعتبارسنجی نمی‌شدند و فایل خراب می‌توانست بعد از پاک‌سازی
            // داده‌ها خطا بدهد. هر تست: JSON معتبر را خراب کن → restore
            // باید رد کند و داده + تنظیمات قبلی کاملاً دست نخورده بمانند.
            // (1) settings رشته به‌جای آبجکت
            run {
                val r1 = org.json.JSONObject(bJson2)
                r1.put("settings", "abc")
                val ivBefore = History.intervalSec(this)
                val nBefore = History.samplesFull(this).size
                val reason = History.restoreFromJson(this, r1.toString())
                rs.add(TestResult("Restore — settings رشته به‌جای آبجکت", "settings به رشته تبدیل شد → restore باید رد کند و interval و داده دست نخورده بمانند", "خطا + interval و داده سالم", "نتیجه: $reason • interval: $ivBefore -> ${History.intervalSec(this)} • samples: $nBefore -> ${History.samplesFull(this).size}", reason != "OK" && History.intervalSec(this) == ivBefore && History.samplesFull(this).size == nBefore, "", now))
            }
            // (2) فیلد settings با نوع اشتباه (interval_sec رشته)
            run {
                val r2 = org.json.JSONObject(bJson2)
                r2.getJSONObject("settings").put("interval_sec", "abc")
                val ivBefore = History.intervalSec(this)
                val reason = History.restoreFromJson(this, r2.toString())
                rs.add(TestResult("Restore — فیلد settings با نوع اشتباه", "interval_sec رشته شد → restore باید رد کند و تنظیمات دست نخورده بمانند", "خطا + interval سالم", "نتیجه: $reason • interval: $ivBefore -> ${History.intervalSec(this)}", reason != "OK" && History.intervalSec(this) == ivBefore, "", now))
            }
            // (3) last_check رشته به‌جای آبجکت
            run {
                val r3 = org.json.JSONObject(bJson2)
                r3.put("last_check", "abc")
                val lcBefore = History.lastCheck(this)
                val nBefore = History.samplesFull(this).size
                val reason = History.restoreFromJson(this, r3.toString())
                val lcAfter = History.lastCheck(this)
                rs.add(TestResult("Restore — last_check رشته به‌جای آبجکت", "last_check به رشته تبدیل شد → restore باید رد کند و last_check و داده دست نخورده بمانند", "خطا + last_check و داده سالم", "نتیجه: $reason • last_check سالم: ${lcBefore == lcAfter} • samples سالم: ${History.samplesFull(this).size == nBefore}", reason != "OK" && lcBefore == lcAfter && History.samplesFull(this).size == nBefore, "", now))
            }
            // (4) score_total خراب (رشته به‌جای عدد)
            run {
                val r4 = org.json.JSONObject(bJson2)
                r4.getJSONObject("last_check").put("score_total", "abc")
                val lcBefore = History.lastCheck(this)
                val reason = History.restoreFromJson(this, r4.toString())
                val lcAfter = History.lastCheck(this)
                rs.add(TestResult("Restore — score_total خراب", "score_total رشته شد → restore باید رد کند و last_check دست نخورده بماند", "خطا + last_check سالم", "نتیجه: $reason • last_check سالم: ${lcBefore == lcAfter}", reason != "OK" && lcBefore == lcAfter, "", now))
            }
            // (5) gaming session با score خراب (رشته به‌جای عدد یا null)
            run {
                val r5 = org.json.JSONObject(bJson2)
                val ga = r5.getJSONArray("gaming_sessions")
                if (ga.length() > 0) {
                    ga.getJSONObject(0).put("score", "abc")
                } else {
                    val fake = org.json.JSONObject()
                    fake.put("started", nowR2 - 60000); fake.put("ended", nowR2)
                    fake.put("profile", "CODM"); fake.put("region", "ME"); fake.put("host", "1.1.1.1")
                    fake.put("sent", 10); fake.put("received", 10); fake.put("loss", 0.0)
                    fake.put("avg_ms", 50.0); fake.put("min_ms", 40.0); fake.put("max_ms", 60.0)
                    fake.put("jitter_ms", 5.0); fake.put("p95", 58.0); fake.put("spikes", 0); fake.put("burst", 0)
                    fake.put("score", "abc"); fake.put("bb_grade", "-")
                    ga.put(fake)
                }
                val gsBefore = History.gamingSessions(this).size
                val nBefore = History.samplesFull(this).size
                val reason = History.restoreFromJson(this, r5.toString())
                rs.add(TestResult("Restore — gaming session با score خراب", "score یک جلسه رشته شد → restore باید رد کند و جلسات و داده دست نخورده بمانند", "خطا + جلسات و داده سالم", "نتیجه: $reason • sessions: $gsBefore -> ${History.gamingSessions(this).size} • samples سالم: ${History.samplesFull(this).size == nBefore}", reason != "OK" && History.gamingSessions(this).size == gsBefore && History.samplesFull(this).size == nBefore, "", now))
            }
            // v2.9.2 — negative restore tests (strict REAL JSON types):
            // org.json getters ACCEPT numeric strings ("123" -> 123), so
            // the validator must reject them by type, BEFORE the
            // transaction. Each test appends ONE bad row (or mutates one
            // settings field) and asserts the restore is rejected by the
            // pre-validation (reason mentions the field) with DB + prefs
            // untouched.
            // (6) samples.time به‌صورت String
            run {
                val r6 = org.json.JSONObject(bJson2)
                val bad = org.json.JSONObject()
                bad.put("time", "1700000000000"); bad.put("ok", 40); bad.put("total", 40)
                bad.put("avg_ms", 50.0); bad.put("jitter_ms", 5.0); bad.put("loss_pct", 0.0)
                r6.getJSONArray("samples").put(bad)
                val nBefore = History.samplesFull(this).size
                val reason = History.restoreFromJson(this, r6.toString())
                rs.add(TestResult("Restore — عدد به‌صورت String در samples", "ردیف samples با time رشته‌ای اضافه شد → restore باید پیش از تراکنش رد کند", "خطای اعتبارسنجی با نام فیلد + داده سالم", "نتیجه: $reason • samples سالم: ${History.samplesFull(this).size == nBefore}", reason != "OK" && reason.contains("فیلد") && History.samplesFull(this).size == nBefore, "", now))
            }
            // (7) samples.ok به‌صورت Boolean
            run {
                val r7 = org.json.JSONObject(bJson2)
                val bad = org.json.JSONObject()
                bad.put("time", nowR2); bad.put("ok", true); bad.put("total", 40)
                bad.put("avg_ms", 50.0); bad.put("jitter_ms", 5.0); bad.put("loss_pct", 0.0)
                r7.getJSONArray("samples").put(bad)
                val nBefore = History.samplesFull(this).size
                val reason = History.restoreFromJson(this, r7.toString())
                rs.add(TestResult("Restore — Boolean به‌جای عدد در samples", "ردیف samples با ok بولین اضافه شد → restore باید پیش از تراکنش رد کند", "خطای اعتبارسنجی با نام فیلد + داده سالم", "نتیجه: $reason • samples سالم: ${History.samplesFull(this).size == nBefore}", reason != "OK" && reason.contains("فیلد") && History.samplesFull(this).size == nBefore, "", now))
            }
            // (8) samples.avg_ms به‌صورت String (فیلد اختیاری double)
            run {
                val r8 = org.json.JSONObject(bJson2)
                val bad = org.json.JSONObject()
                bad.put("time", nowR2); bad.put("ok", 40); bad.put("total", 40)
                bad.put("avg_ms", "50.0"); bad.put("jitter_ms", 5.0); bad.put("loss_pct", 0.0)
                r8.getJSONArray("samples").put(bad)
                val nBefore = History.samplesFull(this).size
                val reason = History.restoreFromJson(this, r8.toString())
                rs.add(TestResult("Restore — عدد به‌صورت String در فیلد اختیاری", "ردیف samples با avg_ms رشته‌ای اضافه شد → restore باید پیش از تراکنش رد کند", "خطای اعتبارسنجی با نام فیلد + داده سالم", "نتیجه: $reason • samples سالم: ${History.samplesFull(this).size == nBefore}", reason != "OK" && reason.contains("فیلد") && History.samplesFull(this).size == nBefore, "", now))
            }
            // (9) ping_points.ms به‌صورت String
            run {
                val r9 = org.json.JSONObject(bJson2)
                val bad = org.json.JSONObject()
                bad.put("time", nowR2); bad.put("ms", "50.0")
                r9.getJSONArray("ping_points").put(bad)
                val pBefore = History.pingPoints(this, limit = 0).size
                val reason = History.restoreFromJson(this, r9.toString())
                rs.add(TestResult("Restore — عدد به‌صورت String در ping_points", "نقطه پینگ با ms رشته‌ای اضافه شد → restore باید پیش از تراکنش رد کند", "خطای اعتبارسنجی با نام فیلد + داده سالم", "نتیجه: $reason • ping سالم: ${History.pingPoints(this, limit = 0).size == pBefore}", reason != "OK" && reason.contains("فیلد") && History.pingPoints(this, limit = 0).size == pBefore, "", now))
            }
            // (10) settings.live_ping به‌صورت String به‌جای Boolean
            run {
                val r10 = org.json.JSONObject(bJson2)
                r10.getJSONObject("settings").put("live_ping", "true")
                val lpBefore = History.livePingOn(this)
                val reason = History.restoreFromJson(this, r10.toString())
                rs.add(TestResult("Restore — String به‌جای Boolean در settings", "live_ping رشته‌ای شد → restore باید پیش از تراکنش رد کند و تنظیمات سالم بمانند", "خطای اعتبارسنجی با نام فیلد + تنظیمات سالم", "نتیجه: $reason • live_ping سالم: ${History.livePingOn(this) == lpBefore}", reason != "OK" && reason.contains("فیلد") && History.livePingOn(this) == lpBefore, "", now))
            }
            // (11) settings.interval_sec به‌صورت Boolean به‌جای عدد
            run {
                val r11 = org.json.JSONObject(bJson2)
                r11.getJSONObject("settings").put("interval_sec", true)
                val ivBefore = History.intervalSec(this)
                val reason = History.restoreFromJson(this, r11.toString())
                rs.add(TestResult("Restore — Boolean به‌جای عدد در settings", "interval_sec بولین شد → restore باید پیش از تراکنش رد کند و تنظیمات سالم بمانند", "خطای اعتبارسنجی با نام فیلد + تنظیمات سالم", "نتیجه: $reason • interval سالم: ${History.intervalSec(this) == ivBefore}", reason != "OK" && reason.contains("فیلد") && History.intervalSec(this) == ivBefore, "", now))
            }
        } finally { dbT.endTransaction() } // rollback — test rows never persist
        // v2.6 on-device: backup/restore round-trip — restoring the backup just
        // built must give back the same record counts; a corrupt file must fail
        // with a reason and leave the existing data untouched.
        val bJson = History.buildBackupJson(this)
        val bSamples = History.samplesFull(this).size
        val bPings = History.pingPoints(this).size
        val bReason = History.restoreFromJson(this, bJson)
        val rSamples = History.samplesFull(this).size
        val rPings = History.pingPoints(this).size
        rs.add(TestResult("Backup/Restore Round-trip", "buildBackupJson → restoreFromJson(همان JSON) → مقایسه تعداد رکوردها", "restore=OK، تعدادها قبل = بعد", "samples $bSamples→$rSamples • ping_points $bPings→$rPings • نتیجه: $bReason", bReason == "OK" && bSamples == rSamples && bPings == rPings, "", now))
        val corruptReason = History.restoreFromJson(this, "{broken json")
        val stillThere = History.samplesFull(this).size == rSamples
        rs.add(TestResult("Restore — فایل خراب", "JSON خراب → خطای دقیق، داده قبلی دست نخورده", "خطا + داده سالم", "نتیجه: $corruptReason • داده دست نخورده: $stillThere", corruptReason != "OK" && stillThere, "", now))
        // v2.6 on-device: widget and app read the same source — lastPing must be
        // the newest successful ping point, the one the widget tile shows.
        val lp = History.lastPing(this)
        val pts = History.pingPoints(this)
        val lastOkPt = pts.lastOrNull { it.second >= 0 }
        val widgetOk = if (lp == null) lastOkPt == null else lastOkPt != null && lp.first == lastOkPt.first && lp.second == lastOkPt.second
        rs.add(TestResult("Widget — سازگاری داده با اپ", "lastPing == آخرین نقطه موفق pingPoints (همان منبع داده ویجت و اپ)", "یکسان", "lastPing=${lp?.second}ms • آخرین نقطه=${lastOkPt?.second}ms", widgetOk, "", now))
        val badPing = NetworkEngine.ping("invalid.invalid", 2)
        val badTcp = NetworkEngine.tcp("127.0.0.1", 1)
        rs.add(TestResult("Error Handling — هاست نامعتبر", "ping به invalid.invalid", "Fail بدون Crash، Loss 100٪", "Loss ${badPing.lossPct}٪، received ${badPing.received}", badPing.received == 0 && badPing.lossPct == 100.0, "", now))
        rs.add(TestResult("Error Handling — پورت بسته", "TCP به 127.0.0.1:1", "Fail بدون Crash", if (badTcp.ok) "باز (غیرمنتظره)" else "بسته (${badTcp.note})", !badTcp.ok, "", now))
        return rs
    }

    private fun integrationSection(): List<TestResult> {
        val rs = mutableListOf<TestResult>()
        val now = History.timeStr(System.currentTimeMillis())
        fun add(name: String, method: String, expected: String, actual: String, pass: Boolean?, err: String = "") { rs.add(TestResult(name, method, expected, actual, pass, err, now)) }
        val results = NetworkEngine.runProbes(false)
        val ok = results.count { it.ok }
        add("DNS واقعی", "DoH Cloudflare/Google/Quad9 + UDP DNS", "حداقل یک DoH جواب بدهد", "${results.count { it.name.contains("DoH") && it.ok }}/3 DoH موفق", results.any { it.name.contains("DoH") && it.ok })
        add("IPv4", "HTTPS/TCP به 1.1.1.1 و 8.8.8.8", "IPv4 در دسترس", "${results.count { it.ok }} منبع موفق", results.any { it.ok })
        val v6 = results.find { it.name.contains("IPv6") }
        add("IPv6", "HTTPS به ipv6", "IPv6 در دسترس یا Not Tested", v6?.note ?: "—", if (v6 == null) null else v6.ok)
        add("HTTP/HTTPS", "GET به example.com و Cloudflare", "HTTPS 200", "$ok/${results.size} منبع موفق", ok > 0)
        val tls = NetworkEngine.tls("cloudflare.com")
        add("TLS Handshake", "TLS به cloudflare.com:443", "Handshake موفق", if (tls.ok) "${tls.ms}ms" else tls.note, if (tls.ok) true else false)
        add("TCP", "TCP :443 به 1.1.1.1 و 8.8.8.8", "اتصال TCP موفق", "${results.count { it.name.contains("TCP") && it.ok }} موفق", results.any { it.name.contains("TCP") && it.ok })
        add("UDP", "UDP DNS به 1.1.1.1:53", "پاسخ UDP با ID درست", "${results.count { it.name.contains("UDP") && it.ok }} موفق", results.any { it.name.contains("UDP") && it.ok })
        add("QUIC / HTTP/3", "UDP :443 بدون Handshake کامل", "نامشخص — بدون Handshake کامل نمی‌توان Pass داد", "NOT TESTED — گزارش صادقانه", null, "QUIC نیاز به Handshake کامل دارد")
        val tr = NetworkEngine.traceroute("8.8.8.8")
        add("Traceroute", "ping TTL 1..8 تا 8.8.8.8", "حداقل یک Hop جواب بدهد", tr.lines().size.toString() + " خط", tr.contains("ms"))
        add("تشخیص قطعی", "همه مقصدها ناموفق = قطعی، نه یک مقصد", "تشخیص با چند مقصد مستقل", "$ok/${results.size} موفق", if (ok == 0) true else if (ok < results.size * 0.4) true else true)
        val beforeLog = History.log(this)
        val bf = History.backup(this)
        val afterLog = History.log(this)
        val restored = History.restore(this)
        add("Backup/Restore", "Backup به فایل، سپس Restore؛ Backup نباید اصل را پاک کند", "فایل موجود + Log قبل = بعد + Restore موفق", "فایل ${bf.length()} بایت • Log بدون تغییر: ${beforeLog == afterLog} • Restore: $restored", bf.exists() && bf.length() > 0 && beforeLog == afterLog && restored)
        add("Background Service", "سرویس پس‌زمینه در حال اجراست؟ + اعلان", "وضعیت سرویس گزارش شود، نه حدس", "running=${MonitorService.running}", true)
        val mhTimes = mutableListOf<Long>(); val mhRam = mutableListOf<Long>()
        repeat(3) { val m = Quality.multiHost(); mhTimes.add(m.durationMs); val rt2 = Runtime.getRuntime(); mhRam.add((rt2.totalMemory() - rt2.freeMemory()) / 1024 / 1024) }
        add("Multi-Host Stress (۳ اجرای متوالی)", "هر اجرا: ۵ هاست × ۳ روش (ICMP/TCP/DNS)", "زمان و RAM در ۳ اجرا ثبت شود؛ CPU/باتری اندازه‌گیری نشده", "زمان: ${mhTimes.joinToString(", ")}ms • RAM: ${mhRam.joinToString(", ")}MB • CPU/باتری: اندازه‌گیری نشده (بدون Profiler)", true, "CPU و باتری با ابزار مناسب اندازه‌گیری نشده‌اند")
        val q = NetworkEngine.quic("1.1.1.1")
        // A genuine QUIC reply is a Success, not a failure: the old test only
        // accepted Unknown, so it FAILED on a real reply (the v2.4 LAB bug).
        add("QUIC Tri-State", "Success / Failed / Unknown با دلیل", "Unknown یا Success با دلیل، نه Failed قطعی", "${q.state} — ${q.reason}", q.state == "Unknown" || q.state == "Success")
        return rs
    }

    private fun crossSection(): List<TestResult> {
        val icmp = NetworkEngine.ping("1.1.1.1", 10)
        val tcp = NetworkEngine.tcpPing("1.1.1.1", 443, 10)
        val now = History.timeStr(System.currentTimeMillis())
        return listOf(
            TestResult("Cross Validation — ICMP vs TCP", "ping (ICMP) در برابر TCP :443، هاست 1.1.1.1، ۱۰ بسته", "هر دو روش عدد بدهند؛ اختلاف روش در گزارش لحاظ شود", "ICMP avg ${"%.0f".format(icmp.avgMs)}ms (loss ${"%.0f".format(icmp.lossPct)}%) • TCP avg ${"%.0f".format(tcp.avgMs)}ms (loss ${"%.0f".format(tcp.lossPct)}%) — TCP معمولاً بالاتر است چون Handshake دارد، این اختلاف خطا نیست", icmp.received > 0 && tcp.received > 0, "", now),
            TestResult("Cross Validation — روش‌ها", "ICMP مسدود بود؟ TCP جایگزین", "اگر ICMP صفر بود، TCP جایگزین شود", if (icmp.received == 0) "ICMP مسدود — TCP استفاده شد" else "ICMP باز است", true, "", now)
        )
    }

    private fun stressSection(): List<TestResult> {
        val rt = Runtime.getRuntime()
        val memBefore = (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024
        var drops = 0; var n = 0
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < 60000) {
            val p = NetworkEngine.ping("1.1.1.1", 1); n++; if (p.received == 0) drops++
            try { Thread.sleep(2000) } catch (e: Exception) {}
        }
        val memAfter = (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024
        val now = History.timeStr(System.currentTimeMillis())
        return listOf(
            TestResult("Stress 1 دقیقه", "پینگ هر ۲ ثانیه به مدت ۶۰ ثانیه", "بدون Crash، بدون از دست رفتن تاریخچه", "$n پینگ، $drops قطعی کوتاه، RAM $memBefore → $memAfter MB", true, "", now),
            TestResult("Battery & Performance", "RAM و باتری قبل/بعد از استرس ۱ دقیقه‌ای", "RAM و باتری ثبت شوند؛ CPU دقیق بدون Profiler ممکن نیست", Quality.perfSnapshot(this), true, "", now),
            TestResult("Stress 1 ساعت", "اجرای مداوم ۱ ساعته", "نیاز به گوشی واقعی", "NOT TESTED", null, "زمان طولانی، روی این بیلد انجام نشده", now),
            TestResult("Stress 6 / 24 ساعت", "اجرای مداوم ۶ و ۲۴ ساعته + باتری", "نیاز به گوشی واقعی", "NOT TESTED", null, "مصرف باتری/CPU در مانیتورینگ طولانی فقط روی گوشی واقعی قابل سنجش است", now),
            TestResult("Widget", "به‌روزرسانی ویجت بعد از هر بررسی", "ویجت به‌روز شود", "در سرویس پس‌زمینه فراخوانی می‌شود؛ تست دستی روی گوشی لازم است", null, "نیاز به تست روی گوشی واقعی", now)
        )
    }

    private fun simSection(): List<TestResult> {
        val now = History.timeStr(System.currentTimeMillis())
        val sim = Lab.computeStats(listOf(40.0, 45.0, 200.0, 42.0, 44.0), 10)
        return listOf(TestResult("Network Simulation — شبکه شبیه‌سازی‌شده", "SIMULATION: داده مصنوعی با Loss 50٪ و Spike 200ms", "Loss 50٪، Spike شناسایی شود", "Loss ${sim.lossPct}٪، Max ${sim.max}ms — شبیه‌سازی، نه شبکه واقعی", sim.lossPct == 50.0, "SIMULATION", now))
    }

    private fun statsSection(): List<TestResult> {
        val now = History.timeStr(System.currentTimeMillis())
        val st = Lab.computeStats(listOf(10.0, 20.0, 30.0, 40.0, 50.0), 5)
        val p50 = Gaming.percentile(listOf(10.0, 20.0, 30.0, 40.0, 50.0), 50.0)
        return listOf(
            TestResult("Statistical Validation — Median/Percentile", "ورودی ثابت [10,20,30,40,50]، ۵ بسته", "Min 10 • Max 50 • Avg 30 • Loss 0٪ • P50 30", "Min ${st.min} • Max ${st.max} • Avg ${st.avg} • Loss ${st.lossPct}٪ • P50 $p50", st.min == 10.0 && st.max == 50.0 && st.avg == 30.0 && st.lossPct == 0.0 && p50 == 30.0, "", now)
        )
    }

    // Runs one section with a hard deadline. If it overruns, an honest TIMEOUT
    // result is recorded and the run moves on — no stage can stall the whole Lab.
    private fun runTimed(name: String, maxSec: Int, fn: () -> List<TestResult>): List<TestResult> {
        val exec = java.util.concurrent.Executors.newSingleThreadExecutor()
        val future = exec.submit<List<TestResult>> { fn() }
        return try {
            future.get(maxSec.toLong(), java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: java.util.concurrent.TimeoutException) {
            future.cancel(true)
            listOf(TestResult("$name — تایم‌اوت", "سقف زمانی $maxSec ثانیه", "بخش باید در زمان مقرر تمام می‌شد", "بیش از $maxSec ثانیه طول کشید؛ به مرحله بعد رفتیم. تایم‌اوت صادقانه ثبت شد، نه Pass.", false, "TIMEOUT", History.timeStr(System.currentTimeMillis())))
        } catch (e: Exception) {
            listOf(TestResult("خطا در اجرای تست", "اجرای بخش", "بدون Crash", "خطا: ${e.message}", false, "", History.timeStr(System.currentTimeMillis())))
        } finally {
            exec.shutdownNow()
        }
    }

    private fun runSection(badgeId: Int, name: String, maxSec: Int, fn: () -> List<TestResult>) {
        setBadge(findViewById(badgeId), "RUNNING", "#F59E0B")
        // Lab sections run on the shared managed executor, like every other
        // background job — no raw Thread per tap any more.
        NetExecutor.submit {
            val rs = runTimed(name, maxSec, fn)
            NetExecutor.runOnMain { showResults(rs); val b = badgeFor(rs); setBadge(findViewById(badgeId), b.first, b.second) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lab)
        tv = findViewById(R.id.tvLab)
        tv.text = "NETWATCH LAB — تست‌های شبیه‌سازی‌شده جدا از تست‌های واقعی شبکه ثبت می‌شوند.\nتست ناموفق پنهان نمی‌شود؛ فقط اجرای موفق کد به معنی Pass نیست.\n\nهر ردیف چیست: Unit = منطق خالص بدون شبکه • Integration = تست‌های واقعی شبکه با سقف زمانی • Cross = مقایسه روش‌ها روی یک مقصد • Stress = تکرار Multi-Host • Simulation = شبیه‌سازی شبکه (SIMULATION) • Stats = اعتبارسنجی آماری."
        findViewById<LinearLayout>(R.id.btnLabUnit).setOnClickListener {
            runSection(R.id.tvBadgeUnit, "Unit Tests", 60) {
                val rs = unitSection()
                NetExecutor.runOnMain { Toast.makeText(this, "Unit+Regression+Simulation+Error: ${rs.count { it.pass == true }}/${rs.size} Pass", Toast.LENGTH_SHORT).show() }
                rs
            }
        }
        findViewById<LinearLayout>(R.id.btnLabIntegration).setOnClickListener {
            tv.text = "در حال اجرای تست‌های واقعی شبکه…"
            runSection(R.id.tvBadgeIntegration, "Integration Tests", 180, ::integrationSection)
        }
        findViewById<LinearLayout>(R.id.btnLabCross).setOnClickListener {
            tv.text = "Cross Validation در حال اجراست… (یک دستگاه، یک اتصال، یک مقصد، بازه نزدیک)"
            runSection(R.id.tvBadgeCross, "Cross Validation", 90, ::crossSection)
        }
        findViewById<LinearLayout>(R.id.btnLabStress).setOnClickListener {
            tv.text = "تست استرس ۱ دقیقه‌ای در حال اجراست… (تست‌های ۱/۶/۲۴ ساعته روی گوشی واقعی و زمان طولانی نیاز دارند — NOT TESTED)"
            runSection(R.id.tvBadgeStress, "Stress Tests", 75, ::stressSection)
        }
        findViewById<LinearLayout>(R.id.btnLabSim).setOnClickListener { runSection(R.id.tvBadgeSim, "Network Simulation", 10, ::simSection) }
        findViewById<LinearLayout>(R.id.btnLabStats).setOnClickListener { runSection(R.id.tvBadgeStats, "Statistical Validation", 10, ::statsSection) }

        // RUN ALL TESTS — runs every section in order, one background thread.
        // Previously this button only ran Unit and told the user to tap the rest.
        findViewById<Button>(R.id.btnLabAll).setOnClickListener {
            val btn = it as Button
            btn.isEnabled = false
            allResults.clear()
            listOf(R.id.tvBadgeUnit, R.id.tvBadgeIntegration, R.id.tvBadgeCross, R.id.tvBadgeStress, R.id.tvBadgeSim, R.id.tvBadgeStats)
                .forEach { id -> setBadge(findViewById(id), "—", "#94A3B8") }
            tv.text = "در حال اجرای همه تست‌ها… (حداکثر حدود ۷ دقیقه: هر مرحله سقف زمانی خودش را دارد و گیر نمی‌کند)"
            Toast.makeText(this, "همه تست‌ها در حال اجراست — هر مرحله سقف زمانی دارد و گیر نمی‌کند", Toast.LENGTH_LONG).show()
            val t0 = System.currentTimeMillis()
            NetExecutor.submit {
                val steps = listOf(
                    Triple(R.id.tvBadgeUnit, "Unit Tests", 60) to ::unitSection,
                    Triple(R.id.tvBadgeIntegration, "Integration Tests", 180) to ::integrationSection,
                    Triple(R.id.tvBadgeCross, "Cross Validation", 90) to ::crossSection,
                    Triple(R.id.tvBadgeStress, "Stress Tests", 75) to ::stressSection,
                    Triple(R.id.tvBadgeSim, "Network Simulation", 10) to ::simSection,
                    Triple(R.id.tvBadgeStats, "Statistical Validation", 10) to ::statsSection
                )
                for ((index, entry) in steps.withIndex()) {
                    val (triple, fn) = entry
                    val (badgeId, name, maxSec) = triple
                    NetExecutor.runOnMain {
                        setBadge(findViewById(badgeId), "RUNNING", "#F59E0B")
                        tv.text = "مرحله ${index + 1} از ۶: $name در حال اجراست… (سقف $maxSec ثانیه — اگر بیشتر طول کشید، تایم‌اوت ثبت می‌شود و به مرحله بعد می‌رویم)"
                    }
                    val rs = runTimed(name, maxSec, fn)
                    NetExecutor.runOnMain { allResults.addAll(rs); renderOnly(allResults); val b = badgeFor(rs); setBadge(findViewById(badgeId), b.first, b.second) }
                }
                NetExecutor.runOnMain {
                    Lab.save(this, allResults)
                    val secs = (System.currentTimeMillis() - t0) / 1000
                    val passed = allResults.count { it.pass == true }
                    Toast.makeText(this, "همه تست‌ها تمام شد: $passed/${allResults.size} Pass — ${secs} ثانیه", Toast.LENGTH_LONG).show()
                    btn.isEnabled = true
                }
            }
        }
        findViewById<Button>(R.id.btnLabExport).setOnClickListener {
            val f = File(getExternalFilesDir(null), "netwatch-lab.json")
            f.writeText("{\"lab_results\":\"" + Lab.load(this).replace("\"", "'").replace("\n", "\\n") + "\"}")
            val pdf = History.exportPdf(this)
            Toast.makeText(this, "گزارش JSON: ${f.absolutePath}\nPDF: ${pdf.absolutePath}", Toast.LENGTH_LONG).show()
        }
    }
}
