// NetWatch — app/build.gradle.kts (v2.11.3, issue 01)
// Single-module Android app. Zero third-party dependencies by design:
// the app only uses the Android framework SDK and the Kotlin/Java stdlib
// (no AndroidX libraries, no networking/JSON libraries — see README.md).

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aksell.netwatch"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aksell.netwatch"
        minSdk = 21
        targetSdk = 34
        versionCode = 39
        versionName = "2.11.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    testOptions {
        unitTests {
            // Local JVM unit tests (src/test) — LabPureTests and
            // LabProbesRestoreTests (58 JUnit4 tests, issue 03).
            // Keep resource access on so a test that touches R.* returns
            // real values instead of 0.
            isIncludeAndroidResources = true
            // Unmocked Android framework calls return defaults instead of
            // throwing "not mocked" RuntimeExceptions.
            isReturnDefaultValues = true
        }
    }
}

dependencies {
    // Intentionally empty of runtime libraries: NetWatch has zero
    // third-party runtime dependencies. Do not add libraries here without
    // a deliberate project decision — the zero-dependency rule is what
    // keeps the APK small and the build reproducible offline from the
    // Android SDK alone.
    // Test-only: JUnit4 for the JVM unit tests in src/test (issue 03).
    testImplementation("junit:junit:4.13.2")
}
