# NetWatch — R8 / ProGuard rules (v2.11.3, issue 01)
# Minimal keep rules. The app has zero third-party dependencies and uses no
# reflection or serialization libraries, so no library-specific rules are
# needed. R8 already keeps everything referenced from AndroidManifest.xml
# (activities, service, widget provider, content provider); the rules below
# only cover what the manifest reference alone does not guarantee.

# Keep the Application subclass (referenced by android:name in the manifest).
-keep public class com.aksell.netwatch.NetWatchApp

# Keep custom Views used from layout XML: R8 must not strip their
# (Context, AttributeSet) constructors, which the layout inflater calls.
-keep public class * extends android.view.View {
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# Keep members accessed from XML layouts / the widget (onClick handlers
# and RemoteViews targets are resolved by name at runtime).
-keepclassmembers class com.aksell.netwatch.* {
    public void *(android.view.View);
}

# Keep annotations (used by the framework and lint).
-keepattributes *Annotation*
