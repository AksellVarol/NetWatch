# Changelog — NetWatch

All notable changes to NetWatch, in release order. Only information that is
verified from the repository or from the fix work itself is listed; anything
unknown is marked «در دسترس نیست» rather than invented.

## v2.11.3 — 2026-11-28 (versionCode 39)

Fix round for the 22-issue v2.11.2 audit (3 critical, 9 serious,
10 medium). All 22 were verified against the real code; 21 fixed,
1 partial (03 — LAB stays in the release binary, see below).

- **Build system (01, p0):** the archive now contains a complete
  Gradle project — `settings.gradle.kts`, root `build.gradle.kts`
  (AGP 8.5.2, Kotlin 1.9.24), `app/build.gradle.kts` (namespace
  `com.aksell.netwatch`, compileSdk 34, minSdk 21, targetSdk 34,
  versionCode 39, versionName 2.11.3), `gradle.properties`,
  `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.7),
  `app/proguard-rules.pro` (minimal R8 keep rules) and a minimal
  `.gitignore`. Zero third-party runtime dependencies, as before;
  test-only JUnit 4.13.2 for `src/test`.
  `gradle/wrapper/gradle-wrapper.jar` is **not** included: it must be
  generated once with `gradle wrapper --gradle-version 8.7` or by opening
  the project in Android Studio.
- **RTL (02, p0):** `android:supportsRtl="true"` in the Manifest;
  the manual `layoutDirection="rtl"` on sectionHome was removed.
- **LAB tests (03, p0) — partial:** 58 pure JVM unit tests added in
  `app/src/test` (LabPureTests 47, LabProbesRestoreTests 11).
  `LabActivity` stays in `src/main`: `MainActivity` calls it directly
  and the Manifest registers it, so moving it to `src/debug` would
  break the release build. `Lab.kt` also stays: its APIs are used by
  the production code (AnalyticsEngine, Bridge, AiCore).
- **Hourly percent (04, p1):** `addHourly` denominator is now
  `scored.size`, not `results.size`.
- **Probe waiting (05–07, p1):** `InterruptedException` restores the
  interrupt flag and breaks; Timeout/Execution/Cancellation are
  separated; a zero-timeout sweep over remaining futures fixes the
  visibility race; the deadline is now `ceil(n/8) × 10s` with
  cheapest probes first (full run 60s, light run 10s).
- **Monotonic clock (08, p1):** gaming end and Live freshness use
  `SystemClock.elapsedRealtime()`; wall-clock stays only for
  calendar history dates.
- **Notifications (09, p1):** separate IDs — monitor 1, alert 2,
  AI 3, gaming 4 (new); gaming notification is cancelled when a
  session ends.
- **Location permission (10, p1):** no longer requested
  unconditionally at startup; only on demand from the network-details
  view, with an explicit explanation dialog. Kept in the Manifest:
  SSID really is read via `WifiManager` and is unavailable without it.
- **Geo consent (11, p1):** public-IP fetch in WidgetStats is now
  gated on `Geo.isConsentGiven`; without consent no request is made
  and cached values are cleared.
- **AI share spoofing (12, p1):** 32KB cap on shared text, sender
  recorded, replies accepted only while a Pending round exists;
  `exported=true` kept on purpose — the Muse share flow needs it.
- **Strings & i18n (13, 15, p2):** `res/values/strings.xml` created
  (255 keys, mirrored in `values-fa` and `values-en`); layout texts
  moved to `@string`; English labels (Ping, Packet Loss, Download,
  Upload, Live, Connected, …) are now Persian; widget language follows
  `Locale.getDefault()`.
- **Accessibility (14, p2):** all 51 ImageViews now have a
  `contentDescription` (47) or `importantForAccessibility="no"` (4
  decorative widget items); was 4/51.
- **Empty catches (16, p2):** empty catches in the swept files went
  from 47 to 0 (21 now log, 26 kept empty with a reason comment);
  `lightCheck` failures are now logged via `History.addLog`.
- **CSV export (17, p2):** numbers with `Locale.US`, UTF-8 BOM
  prefix, quoted text fields.
- **DoH parsing (18, p2):** `parseDohJson` now uses `org.json`;
  the regex parser remains only as fallback (JVM test stubs).
- **Non-null assertions (19, p2):** both flagged `!!` removed
  (`History.kt:812`, `BridgeActivity.kt:262`).
- **Widget size (20, p2):** compact 4×3 widget — `minHeight` 780dp
  → 220dp, `targetCellHeight` 12 → 3; tall layout stays available
  via resize.
- **Docs (21, p2):** `README.md` and this `CHANGELOG.md` added at
  the archive root (build instructions, project structure, version table).
- **Backup errors (22, p2):** `History.backupToUriReason` returns the
  exact Persian reason (disk full / not writable / permission
  revoked); the backup Toast in MainActivity shows it.
- **Version bump:** `AndroidManifest.xml` versionCode 38 → 39,
  versionName 2.11.2 → 2.11.3.
- **Not verified in this environment:** no full Gradle compile was run
  (no Gradle/JDK in this environment) — build in Android Studio before
  releasing an APK and run the in-app LAB tests.

## v2.11.2 — 2026-11-28 (versionCode 38)

Fix round for 26 audited issues (v2.11.1 → v2.11.2; source commit
27 Nov 2026). Source zip: 456,866 bytes, 108 files. APK / SHA-256:
در دسترس نیست.

- Cleartext traffic limited to three domains (`ip-api.com`,
  `example.com`, `connectivitycheck.gstatic.com`) via
  `network_security_config.xml`; Geo tries HTTPS `ipapi.co` first.
- Runtime permission requests added (notifications on Android 13+,
  storage on API ≤ 28, location for SSID).
- AI Share no longer fails the whole round when writing to Downloads
  fails (falls back to text-only share); old AI files older than 7 days
  are cleaned up.
- Separate 8-thread probe pool (no more thread starvation); probe
  timeout handling fixed.
- Restore now preserves the AI tables (`ai_analyses`, `ai_chats`).
- AI reply routing fixed (no attaching to the wrong round; stale
  Pending rounds expire after 24 h); share Intent is processed once.
- `onDestroy` no longer cancels the service background check.
- API 26/23 calls guarded by `SDK_INT` branches (minSdk stays 21).
- `TelephonyManager.networkType` wrapped against `SecurityException`;
  no `READ_PHONE_STATE` permission added.
- Ping loss/jitter/burst recomputed from `icmp_seq` (not from printed
  text); informational probes excluded from the health percentage.
- Bufferbloat download loop, service `startForeground` ordering,
  reconnect threshold, separate AI notification ID, DB migration to
  version 4 with `onDowngrade`, Bridge persist throttling, binary
  Quad9 DoH (RFC 8484), TLS hostname verification, VPN-aware gateway
  classification, balanced-JSON reply parsing, `allowBackup=false`,
  Geo JSON parsing + user consent, SpeedTest timing fixes, dead code
  removed (AiGateway caps, 9 `selfTests()` functions), `clearAll`
  no longer wipes settings.
- One UI spelling fix («تاریخه» → «تاریخچه»); no other Persian UI
  strings changed.

## v2.11.1 (versionCode 37)

Last repo source before the v2.11.2 fix round (commit 27 Nov 2026).
No changelog details available for this version. APK / SHA-256:
در دسترس نیست.

## v2.9.9

Session-based background gaming monitoring (gaming session loop moved
to `MonitorService`). Details from code comments only. APK / SHA-256:
در دسترس نیست.

## v2.9.8

Restore path: sidecar reconcile / fresh recovery for restore
(`History.kt`). Details from code comments only. APK / SHA-256:
در دسترس نیست.

## v2.9.7

Chart time-axis labels with second resolution; packet-loss strip
(`ChartData.kt`, `GraphView.kt`). Details from code comments only.
APK / SHA-256: در دسترس نیست.
