# NetWatch

NetWatch — برنامهٔ اندرویدی پایش شبکه: تست سلامت اتصال، پینگ و جیتر، تست سرعت،
تشخیص قطعی و گیمینگ، تاریخچهٔ اندازه‌گیری‌ها، ویجت و صفحهٔ «هوشمند» (AI).

NetWatch is an Android network-monitoring app: connection health checks, ping
and jitter, speed test, outage and gaming diagnostics, measurement history,
a home-screen widget, and an AI ("هوشمند") page.

- **Current version / نسخهٔ فعلی:** v2.11.3 (versionCode 39)
- **Package:** `com.aksell.netwatch`
- **minSdk 21** (Android 5.0) · **targetSdk 34** (Android 14) · **compileSdk 34**
- **Zero third-party dependencies** — only the Android framework SDK and the
  Kotlin/Java standard library. No AndroidX libraries, no networking or JSON
  libraries. This keeps the APK small and the build reproducible from the
  Android SDK alone.

## Build / ساخت

Requirements / پیش‌نیازها:

- Android Studio (recommended) with **JDK 17** (required by AGP 8.5.x;
  Android Studio ships a bundled JDK 17), or a command-line Gradle install
  with `JAVA_HOME` pointing at JDK 17.
- Android SDK with API 34 (compileSdk/targetSdk) installed.

Build with Android Studio: open this folder as a project, let it sync Gradle,
then **Build → Make Project** (or **Run** to install on a device/emulator).

Build from the command line:

```sh
./gradlew assembleDebug      # debug APK in app/build/outputs/apk/debug/
./gradlew assembleRelease    # release APK (R8 minify + shrink, see app/proguard-rules.pro)
./gradlew testDebugUnitTest  # local JVM unit tests (src/test)
```

> **Gradle wrapper:** `gradle/wrapper/gradle-wrapper.jar` is not in this
> archive — it cannot be generated without a Gradle install. Generate it
> once with `gradle wrapper --gradle-version 8.7`, or simply open the project
> in Android Studio, which creates the wrapper automatically.

### Build versions / نسخه‌های ابزار ساخت

| Tool | Version | Why this version |
| ---- | ------- | ---------------- |
| Android Gradle Plugin | 8.5.2 | Last AGP line with compileSdk 34 as its default; requires Gradle ≥ 8.7 and JDK 17 |
| Kotlin Gradle Plugin | 1.9.24 | Newest 1.9.x patch; compatible with AGP 8.5 and Gradle 8.7; avoids the Kotlin 2.0 (K2 compiler) switch for this old-style, coroutine-free codebase |
| Gradle | 8.7 | Minimum Gradle for AGP 8.5.2 (AGP 8.5.x supports 8.7–8.9) |
| JDK | 17 | Required to run AGP 8.5.x / Gradle 8.7 |

## Project structure / ساختار پروژه

```text
NetWatch-v2.11.3/
├── README.md                    # this file
├── CHANGELOG.md                 # release history
├── settings.gradle.kts          # project name (NetWatch), includes :app
├── build.gradle.kts             # root: AGP + Kotlin plugin versions
├── gradle.properties            # JVM args, useAndroidX, Kotlin code style
├── gradle/wrapper/
│   └── gradle-wrapper.properties  # Gradle 8.7 (wrapper jar: see note above)
├── .gitignore
└── app/
    ├── build.gradle.kts         # namespace, SDKs, versionCode 39 / 2.11.3, ProGuard, tests
    ├── proguard-rules.pro       # minimal R8 keep rules
    └── src/main/
        ├── AndroidManifest.xml  # package, permissions, components
        ├── java/com/aksell/netwatch/   # Kotlin sources (no dependencies)
        └── res/                 # layouts, drawables, values, xml
```

Key sources (under `app/src/main/java/com/aksell/netwatch/`):

- `MainActivity.kt` — main screen, monitoring loop
- `MonitorService.kt` — foreground monitoring service
- `Probes.kt`, `Diagnostics.kt`, `Quality.kt` — probes, ping/loss, health scoring
- `SpeedTest.kt`, `Gaming.kt`, `GamingActivity.kt` — speed and gaming tests
- `History.kt`, `HistoryDb.kt` — measurement history (SQLite) and backup/restore
- `AiCore.kt`, `AiActivity.kt`, `AiProviders.kt`, `AiGateway.kt` — AI page and sharing
- `Bridge.kt`, `BridgeActivity.kt`, `BridgeReport.kt` — Muse Bridge page
- `Lab.kt`, `LabActivity.kt` — in-app LAB self-tests
- `NetWatchWidget.kt`, `WidgetStats.kt` — home-screen widget

## Permissions / مجوزها

The app requests at runtime only what it needs: notifications
(`POST_NOTIFICATIONS`, Android 13+), location (`ACCESS_FINE_LOCATION`,
only to read the Wi‑Fi SSID), and storage (`WRITE_EXTERNAL_STORAGE`,
Android 9 and below only, for legacy report exports). No `READ_PHONE_STATE`
permission is used. Geo IP lookup sends the device IP to a third-party
service only after the user consents in the one-time dialog.

## Version history / جدول نسخه‌ها

Only what is known from the repository is listed. APK files and SHA-256
hashes are **not available / در دسترس نیست** for any version below — no
numbers are invented here. See `CHANGELOG.md` for per-release notes.

| Version | versionCode | Notes |
| ------- | ----------- | ----- |
| v2.9.7 | در دسترس نیست | Chart time-axis labels with second resolution; packet-loss strip (from code comments) |
| v2.9.8 | در دسترس نیست | Restore sidecar reconcile / fresh recovery for the restore path (from code comments) |
| v2.9.9 | در دسترس نیست | Session-based background gaming monitoring (from code comments) |
| v2.11.1 | 37 | Last repo source before the v2.11.2 fix round (commit 27 Nov 2026) |
| v2.11.2 | 38 | Fix round for 26 audited issues; source zip 456,866 bytes, 108 files |
| v2.11.3 | 39 | Current — Gradle build files, README/CHANGELOG, and the 22-issue audit fixes (see CHANGELOG.md) |

APK / SHA-256 for every version above: **در دسترس نیست**.
