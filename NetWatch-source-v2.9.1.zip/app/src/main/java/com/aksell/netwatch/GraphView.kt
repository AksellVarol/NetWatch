package com.aksell.netwatch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Dashboard / History / Gaming latency chart (v2.6) — TIME-based, not
// "last 60 samples".
// - points: (timestampMs, ms); ms < 0 means the measurement FAILED: the line
//   breaks there (a visible gap) and a red tick marks the failure at the
//   bottom. Failed samples are never drawn as 0ms.
// - The x axis is real time (first sample time … last sample time, HH:mm).
// - The y axis uses ChartData.yMax (P95-based), so one huge spike does not
//   flatten the rest of the chart; points above it are clipped at the top.
// - pctPoints: optional second series (sources-ok %), drawn on the same
//   time axis — the two series can never be misaligned, because both carry
//   their own timestamps.
class GraphView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var points: List<Pair<Long, Double>> = emptyList()
        set(v) { field = v; invalidate() }
    var pctPoints: List<Pair<Long, Double>> = emptyList()
        set(v) { field = v; invalidate() }

    private val gridPaint = Paint().apply { color = Color.parseColor("#1E293B"); strokeWidth = 2f }
    private val axisPaint = Paint().apply { color = Color.parseColor("#7C8AA0"); textSize = 28f; isAntiAlias = true }
    private val linePaint = Paint().apply { color = Color.parseColor("#2DD4BF"); strokeWidth = 4f; isAntiAlias = true; style = Paint.Style.STROKE }
    private val fillPaint = Paint().apply { color = Color.parseColor("#142E2B"); style = Paint.Style.FILL; alpha = 160 }
    private val failPaint = Paint().apply { color = Color.parseColor("#EF4444"); strokeWidth = 5f; isAntiAlias = true }
    private val emptyPaint = Paint().apply { color = Color.parseColor("#94A3B8"); textSize = 32f; isAntiAlias = true; textAlign = Paint.Align.CENTER }
    private val emptySubPaint = Paint().apply { color = Color.parseColor("#7C8AA0"); textSize = 26f; isAntiAlias = true; textAlign = Paint.Align.CENTER }

    private fun fmtTime(t: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(t))

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        val padL = 92f; val padR = 12f; val padT = 12f; val padB = 28f
        val plotW = w - padL - padR; val plotH = h - padT - padB
        val valid = points.filter { it.second >= 0 }.map { it.second }
        val maxV = ChartData.yMax(valid)
        val topLabel = "${"%.0f".format(maxV)}ms"
        val midLabel = "${"%.0f".format(maxV / 2)}ms"
        for (i in 0..2) {
            val y = padT + plotH * i / 2
            canvas.drawLine(padL, y, w - padR, y, gridPaint)
            val label = when (i) { 0 -> topLabel; 1 -> midLabel; else -> "0ms" }
            canvas.drawText(label, 4f, y + 10f, axisPaint)
        }
        if (points.isEmpty()) {
            canvas.drawText("هنوز داده‌ای نیست", w / 2, h / 2 - 8f, emptyPaint)
            canvas.drawText("بعد از اولین بررسی، نمودار اینجا رسم می‌شود", w / 2, h / 2 + 30f, emptySubPaint)
            return
        }
        // Real time axis: first … last sample time.
        val t0 = points.minOf { it.first }
        val t1 = points.maxOf { it.first }
        val span = (t1 - t0).coerceAtLeast(1L)
        fun xOf(t: Long): Float = padL + (t - t0).toFloat() / span * plotW
        fun yOf(ms: Double): Float = padT + plotH - (ms.coerceAtMost(maxV) / maxV * plotH).toFloat()
        canvas.drawText(fmtTime(t0), padL, h - 6f, axisPaint)
        val nowLabel = fmtTime(t1)
        canvas.drawText(nowLabel, w - padR - axisPaint.measureText(nowLabel), h - 6f, axisPaint)
        // Failed samples: red ticks at the bottom (visible gaps, not zeros).
        for (p in points) {
            if (p.second < 0) {
                val x = xOf(p.first)
                canvas.drawLine(x, padT + plotH - 14f, x, padT + plotH, failPaint)
            }
        }
        // Latency line, broken at failures.
        for (seg in ChartData.segments(points)) {
            if (seg.size == 1) {
                canvas.drawCircle(xOf(seg[0].first), yOf(seg[0].second), 7f, linePaint)
                continue
            }
            val path = Path(); val fill = Path()
            for ((i, p) in seg.withIndex()) {
                val x = xOf(p.first); val y = yOf(p.second)
                if (i == 0) { path.moveTo(x, y); fill.moveTo(x, padT + plotH); fill.lineTo(x, y) }
                else { path.lineTo(x, y); fill.lineTo(x, y) }
            }
            fill.lineTo(xOf(seg.last().first), padT + plotH); fill.close()
            canvas.drawPath(fill, fillPaint)
            canvas.drawPath(path, linePaint)
        }
        val last = points.lastOrNull { it.second >= 0 }
        if (last != null) canvas.drawCircle(xOf(last.first), yOf(last.second), 7f, linePaint)
        // Sources-ok % on the same time axis (purple, right side).
        if (pctPoints.isNotEmpty()) {
            val pctPaint = Paint().apply { color = Color.parseColor("#A855F7"); strokeWidth = 4f; isAntiAlias = true; style = Paint.Style.STROKE }
            val pctPath = Path()
            var started = false
            for (p in pctPoints) {
                val x = xOf(p.first)
                val y = padT + plotH - (p.second.coerceIn(0.0, 100.0) / 100.0 * plotH).toFloat()
                if (!started) { pctPath.moveTo(x, y); started = true } else pctPath.lineTo(x, y)
            }
            canvas.drawPath(pctPath, pctPaint)
            val rightPaint = Paint().apply { color = Color.parseColor("#A855F7"); textSize = 26f; isAntiAlias = true }
            canvas.drawText("100%", w - padR - rightPaint.measureText("100%"), padT + 10f, rightPaint)
            canvas.drawText("0%", w - padR - rightPaint.measureText("0%"), padT + plotH, rightPaint)
        }
    }
}
