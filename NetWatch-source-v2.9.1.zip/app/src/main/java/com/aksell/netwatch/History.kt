package com.aksell.netwatch

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// History (v2.6): structured samples live in SQLite (HistoryDb); settings,
// logs and the timeline stay in SharedPreferences (append-only logs).
// Old SharedPreferences data (samples string + ping history) is migrated once
// into the database — nothing the user collected is lost.
// All DB writes are synchronized on one lock, so the service and the UI can
// never lose each other's samples.
object History {
    private const val PREF = "netwatch"
    private const val KEY_SAMPLES = "samples"
    private const val KEY_LOG = "log"
    private const val KEY_OUTAGE_START = "outage_start"
    private const val KEY_INTERVAL = "interval_sec"
    private const val KEY_CUSTOM_TARGET = "custom_target"
    private const val KEY_PING_HIST = "ping_hist"
    private const val KEY_MIGRATED = "db_migrated_v1"
    private val dbLock = Any()

    private fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun intervalSec(ctx: Context): Int = prefs(ctx).getInt(KEY_INTERVAL, 30)
    fun setInterval(ctx: Context, sec: Int) { prefs(ctx).edit().putInt(KEY_INTERVAL, sec).apply() }
    fun customTarget(ctx: Context): String = prefs(ctx).getString(KEY_CUSTOM_TARGET, "") ?: ""
    fun setCustomTarget(ctx: Context, t: String) { prefs(ctx).edit().putString(KEY_CUSTOM_TARGET, t).apply() }

    fun livePingOn(ctx: Context): Boolean = prefs(ctx).getBoolean("live_ping", false)
    fun setLivePing(ctx: Context, on: Boolean) { prefs(ctx).edit().putBoolean("live_ping", on).apply() }

    fun alertThreshold(ctx: Context): Int = prefs(ctx).getInt("alert_threshold", 40)
    fun setAlertThreshold(ctx: Context, pct: Int) { prefs(ctx).edit().putInt("alert_threshold", pct).apply() }

    // ---- Service heartbeat (v2.6): the widget's Live pill is based on this,
    // not on a static boolean. lastAttempt = last cycle start, lastSuccess =
    // last cycle that produced a result, lastHeartbeat = last widget refresh
    // the service performed. ----
    fun setHeartbeat(ctx: Context) { prefs(ctx).edit().putLong("last_heartbeat", System.currentTimeMillis()).apply() }
    fun lastHeartbeat(ctx: Context): Long = prefs(ctx).getLong("last_heartbeat", 0L)
    fun setLastAttempt(ctx: Context, t: Long = System.currentTimeMillis()) { prefs(ctx).edit().putLong("last_attempt", t).apply() }
    fun lastAttempt(ctx: Context): Long = prefs(ctx).getLong("last_attempt", 0L)
    fun setLastSuccess(ctx: Context, t: Long = System.currentTimeMillis()) { prefs(ctx).edit().putLong("last_success", t).apply() }
    fun lastSuccess(ctx: Context): Long = prefs(ctx).getLong("last_success", 0L)

    // ---- Migration: old prefs strings -> SQLite, once. ----
    fun migrateIfNeeded(ctx: Context) {
        val p = prefs(ctx)
        if (p.getBoolean(KEY_MIGRATED, false)) return
        synchronized(dbLock) {
            if (p.getBoolean(KEY_MIGRATED, false)) return
            val db = HistoryDb.get(ctx).writableDatabase
            db.beginTransaction()
            try {
                val old = p.getString(KEY_SAMPLES, "") ?: ""
                for (line in old.split(";").filter { it.isNotBlank() }) {
                    parseSample(line)?.let { s -> insertSampleRow(db, s.time, s.ok, s.total, s.avgMs, s.jitterMs, s.lossPct, "full") }
                }
                val ph = p.getString(KEY_PING_HIST, "") ?: ""
                for (e in ph.split(";").filter { it.isNotBlank() }) {
                    val a = e.split(",")
                    val t = a.getOrNull(0)?.toLongOrNull()
                    val ms = a.getOrNull(1)?.toDoubleOrNull()
                    if (t != null && ms != null) insertPingRow(db, t, ms, 1)
                }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
            p.edit().putBoolean(KEY_MIGRATED, true).apply()
        }
    }

    private fun insertSampleRow(db: SQLiteDatabase, time: Long, ok: Int, total: Int, avgMs: Double, jitterMs: Double, lossPct: Double, source: String) {
        val cv = ContentValues().apply {
            put("time", time); put("ok", ok); put("total", total)
            put("avg_ms", avgMs); put("jitter_ms", jitterMs); put("loss_pct", lossPct); put("source", source)
        }
        db.insert("samples", null, cv)
    }
    private fun insertPingRow(db: SQLiteDatabase, time: Long, ms: Double, ok: Int) {
        val cv = ContentValues().apply { put("time", time); put("ms", ms); put("ok", ok) }
        db.insert("ping_points", null, cv)
    }
    private fun pruneOld(db: SQLiteDatabase) {
        val cutoff = System.currentTimeMillis() - HistoryDb.RETENTION_MS
        db.delete("samples", "time < ?", arrayOf(cutoff.toString()))
        db.delete("ping_points", "time < ?", arrayOf(cutoff.toString()))
        db.delete("loss_points", "time < ?", arrayOf(cutoff.toString()))
    }

    // ---- Samples: one row per check. THE v2.5 BUG was here: addSample wrote
    // 6 fields but samples() only accepted exactly 3, so it always returned
    // an empty list and the widget, gauge, CSV, JSON, PDF and backup all saw
    // ---- History ranges (v2.8 fix) ----
    // The v2.7 bug: refreshHistory() computed the cutoff as `range * 3600000`
    // while the buttons sent MIXED units — 24 meant hours but 7 and 30 meant
    // days. So "7 days" showed only 7 hours and "30 days" only 30 hours.
    // Every ranged view (ping chart, health-% chart, cards, Min/Avg/Max) must
    // use ONE HistoryRange: the duration in milliseconds lives here and
    // nowhere else. Never pass a bare Int and guess its unit again.
    enum class HistoryRange(val label: String, val millis: Long) {
        H24("۲۴ ساعت", 24L * 60 * 60 * 1000),
        D7("۷ روز", 7L * 24 * 60 * 60 * 1000),
        D30("۳۰ روز", 30L * 24 * 60 * 60 * 1000);
        fun cutoff(nowMs: Long = System.currentTimeMillis()): Long = nowMs - millis
        companion object {
            // The old button values (24/7/30) map here so a wrong unit can
            // never sneak back in through an Int.
            fun fromButton(value: Int): HistoryRange = when (value) {
                24 -> H24; 7 -> D7; 30 -> D30; else -> H24
            }
        }
    }
    // no data. samples() is now backed by the same rows addSample writes. ----
    data class Sample(val time: Long, val ok: Int, val total: Int, val avgMs: Double = -1.0, val jitterMs: Double = -1.0, val lossPct: Double = -1.0)
    fun parseSample(line: String): Sample? {
        val a = line.split(",")
        if (a.size < 3) return null
        val time = a[0].toLongOrNull() ?: return null
        val ok = a[1].toIntOrNull() ?: return null
        val total = a[2].toIntOrNull() ?: return null
        return Sample(time, ok, total,
            if (a.size > 3) a[3].toDoubleOrNull() ?: -1.0 else -1.0,
            if (a.size > 4) a[4].toDoubleOrNull() ?: -1.0 else -1.0,
            if (a.size > 5) a[5].toDoubleOrNull() ?: -1.0 else -1.0)
    }

    // v2.9: NO LIMIT here. The old "time ASC LIMIT 5000" returned the
    // OLDEST 5000 rows, so after ~42h of monitoring the newest data vanished
    // from every ranged view — and from backups too. The 30-day retention
    // prune bounds this table instead (max ~86,400 rows). Ranged reads use
    // samplesInRange() below, which caps AFTER the time filter.
    fun samplesFull(ctx: Context): List<Sample> {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            val out = mutableListOf<Sample>()
            db.query("samples", arrayOf("time", "ok", "total", "avg_ms", "jitter_ms", "loss_pct"), null, null, null, null, "time ASC", null).use { c ->
                while (c.moveToNext()) out.add(Sample(c.getLong(0), c.getInt(1), c.getInt(2), c.getDouble(3), c.getDouble(4), c.getDouble(5)))
            }
            return out
        }
    }
    // v2.9: the time filter runs in SQL and the 5000 cap applies to the
    // NEWEST rows in range (DESC + LIMIT, then reversed to ASC for charts).
    // Filtering the oldest 5000 in memory — the v2.8 way — dropped every new
    // row once the table passed 5000 rows.
    fun samplesInRange(ctx: Context, sinceMs: Long): List<Sample> {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            val out = mutableListOf<Sample>()
            db.query("samples", arrayOf("time", "ok", "total", "avg_ms", "jitter_ms", "loss_pct"),
                "time >= ?", arrayOf(sinceMs.toString()), null, null, "time DESC", "5000").use { c ->
                while (c.moveToNext()) out.add(Sample(c.getLong(0), c.getInt(1), c.getInt(2), c.getDouble(3), c.getDouble(4), c.getDouble(5)))
            }
            out.reverse()
            return out
        }
    }
    // LEGACY COMPAT ONLY — samples() returns (time, ok, total) and DROPS
    // avgMs/jitterMs/lossPct. It exists so old callers that only need the
    // ok/total ratio (widget fallback status, home gauge) keep working.
    // Anything that shows Ping, Jitter or Loss MUST use samplesFull() (or
    // samplesInRange()) instead — reading those values from samples() is
    // impossible by design, and silently showing 0 or -1 would be fake data.
    fun samples(ctx: Context): List<Triple<Long, Int, Int>> = samplesFull(ctx).map { Triple(it.time, it.ok, it.total) }

    fun addSample(ctx: Context, ok: Int, total: Int, avgMs: Double = -1.0, jitterMs: Double = -1.0, lossPct: Double = -1.0, source: String = "full") {
        migrateIfNeeded(ctx)
        val now = System.currentTimeMillis()
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            db.beginTransaction()
            try {
                insertSampleRow(db, now, ok, total, avgMs, jitterMs, lossPct, source)
                pruneOld(db)
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
        // outage start/end tracking: outage = <40% ok
        val p = prefs(ctx)
        val pct = if (total == 0) 0 else ok * 100 / total
        val start = p.getLong(KEY_OUTAGE_START, 0L)
        if (pct < 40 && start == 0L) {
            p.edit().putLong(KEY_OUTAGE_START, now).apply()
            addTimeline(ctx, "outage-start", "شروع اختلال در ${timeStr(now)} — دسترسی $pct٪ (قبل از آن سالم بود)")
        }
        if (pct >= 70 && start != 0L) {
            val durMin = (now - start) / 60000
            addLog(ctx, "پایان اختلال: از ${timeStr(start)} تا ${timeStr(now)} — حدود $durMin دقیقه")
            addTimeline(ctx, "outage-end", "پایان اختلال: شروع ${timeStr(start)} • پایان ${timeStr(now)} • مدت حدود $durMin دقیقه • دسترسی قبل از اختلال سالم، بعد از آن $pct٪ • علت احتمالی: در گزارش تشخیص نوع اختلال ببین")
            p.edit().putLong(KEY_OUTAGE_START, 0L).apply()
        }
    }

    // ---- Ping points: every measurement with its timestamp. ms < 0 = failed. ----
    // Removes samples/ping/loss rows written at or after a timestamp — used by
    // the Lab round-trip test to clean up its own test rows afterwards.
    fun deleteSamplesSince(ctx: Context, sinceMs: Long) {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            db.delete("samples", "time >= ?", arrayOf(sinceMs.toString()))
            db.delete("ping_points", "time >= ?", arrayOf(sinceMs.toString()))
            db.delete("loss_points", "time >= ?", arrayOf(sinceMs.toString()))
        }
    }

    fun addPing(ctx: Context, avgMs: Double) {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            db.beginTransaction()
            try { insertPingRow(db, System.currentTimeMillis(), avgMs, 1); pruneOld(db); db.setTransactionSuccessful() }
            finally { db.endTransaction() }
        }
    }
    fun addPingFailed(ctx: Context) {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            db.beginTransaction()
            try { insertPingRow(db, System.currentTimeMillis(), -1.0, 0); pruneOld(db); db.setTransactionSuccessful() }
            finally { db.endTransaction() }
        }
    }
    // Time-ordered (time, ms) pairs; failed points carry ms = -1.0 (gap, not 0).
    // v2.9: time filter in SQL, newest `limit` rows (DESC), final order
    // ASC for charts. limit = 0 means no cap (backup/export only).
    fun pingPoints(ctx: Context, sinceMs: Long = 0L, limit: Int = 5000): List<Pair<Long, Double>> {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            val out = mutableListOf<Pair<Long, Double>>()
            val sel = if (sinceMs > 0) "time >= ?" else null
            val args = if (sinceMs > 0) arrayOf(sinceMs.toString()) else null
            db.query("ping_points", arrayOf("time", "ms"), sel, args, null, null, "time DESC", if (limit > 0) limit.toString() else null).use { c ->
                while (c.moveToNext()) out.add(c.getLong(0) to c.getDouble(1))
            }
            out.reverse()
            return out
        }
    }
    fun pingHistory(ctx: Context): List<Double> = pingPoints(ctx).filter { it.second >= 0 }.map { it.second }
    // Newest SUCCESSFUL ping with its timestamp (widget live tile).
    fun lastPing(ctx: Context): Pair<Long, Double>? {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            db.query("ping_points", arrayOf("time", "ms"), "ok = 1", null, null, null, "time DESC", "1").use { c ->
                return if (c.moveToFirst()) c.getLong(0) to c.getDouble(1) else null
            }
        }
    }
    // Newest ping attempt of any kind (for "last measurement" age).
    fun lastPingTime(ctx: Context): Long {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            db.query("ping_points", arrayOf("MAX(time)"), null, null, null, null, null).use { c ->
                return if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L
            }
        }
    }

    // ---- Loss points (loss sparkline source). ----
    fun addLoss(ctx: Context, lossPct: Double) {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            db.beginTransaction()
            try {
                val cv = ContentValues().apply { put("time", System.currentTimeMillis()); put("loss", lossPct) }
                db.insert("loss_points", null, cv)
                pruneOld(db)
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
    }
    // v2.9: the NEWEST 60 loss values (the old ASC LIMIT 60 returned the
    // oldest 60 — a sparkline frozen on the first hour of data).
    fun lossHistory(ctx: Context): List<Double> = lossPoints(ctx, limit = 60).map { it.second }
    // v2.9: same newest-first pattern as pingPoints (limit = 0: no cap).
    fun lossPoints(ctx: Context, sinceMs: Long = 0L, limit: Int = 5000): List<Pair<Long, Double>> {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            val out = mutableListOf<Pair<Long, Double>>()
            val sel = if (sinceMs > 0) "time >= ?" else null
            val args = if (sinceMs > 0) arrayOf(sinceMs.toString()) else null
            db.query("loss_points", arrayOf("time", "loss"), sel, args, null, null, "time DESC", if (limit > 0) limit.toString() else null).use { c ->
                while (c.moveToNext()) out.add(c.getLong(0) to c.getDouble(1))
            }
            out.reverse()
            return out
        }
    }

    // ---- Gaming sessions (persisted, with per-sample timestamps). ----
    data class GamingSession(val id: Long, val started: Long, val ended: Long, val profile: String, val region: String, val host: String,
        val sent: Int, val received: Int, val loss: Double, val avgMs: Double, val minMs: Double, val maxMs: Double,
        val jitterMs: Double, val p95: Double, val spikes: Int, val burst: Int, val score: Int?, val bbGrade: String)
    fun startGamingSession(ctx: Context, profile: String, region: String, host: String): Long {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            val cv = ContentValues().apply {
                put("started", System.currentTimeMillis()); put("ended", 0L)
                put("profile", profile); put("region", region); put("host", host)
                put("sent", 0); put("received", 0); put("loss", 0.0)
                put("avg_ms", 0.0); put("min_ms", 0.0); put("max_ms", 0.0)
                put("jitter_ms", 0.0); put("p95", 0.0); put("spikes", 0); put("burst", 0)
                put("score", null as Int?); put("bb_grade", "-")
            }
            return db.insert("gaming_sessions", null, cv)
        }
    }
    fun addGamingSample(ctx: Context, sessionId: Long, ms: Double, ok: Boolean) {
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            val cv = ContentValues().apply { put("session_id", sessionId); put("time", System.currentTimeMillis()); put("ms", if (ok) ms else -1.0); put("ok", if (ok) 1 else 0) }
            db.insert("gaming_samples", null, cv)
        }
    }
    fun finishGamingSession(ctx: Context, sessionId: Long, sent: Int, received: Int, loss: Double, avgMs: Double, minMs: Double, maxMs: Double, jitterMs: Double, p95: Double, spikes: Int, burst: Int, score: Int?, bbGrade: String) {
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            val cv = ContentValues().apply {
                put("ended", System.currentTimeMillis()); put("sent", sent); put("received", received)
                put("loss", loss); put("avg_ms", avgMs); put("min_ms", minMs); put("max_ms", maxMs)
                put("jitter_ms", jitterMs); put("p95", p95); put("spikes", spikes); put("burst", burst)
                put("score", score); put("bb_grade", bbGrade)
            }
            db.update("gaming_sessions", cv, "id = ?", arrayOf(sessionId.toString()))
        }
    }
    // v2.9: uncapped read for backup only — the UI keeps showing the
    // newest 50 via gamingSessions(), but a backup must not drop sessions.
    fun gamingSessionsAll(ctx: Context): List<GamingSession> {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            val out = mutableListOf<GamingSession>()
            db.query("gaming_sessions", null, null, null, null, null, "started DESC", null).use { c ->
                while (c.moveToNext()) {
                    out.add(GamingSession(c.getLong(0), c.getLong(1), c.getLong(2), c.getString(3), c.getString(4), c.getString(5),
                        c.getInt(6), c.getInt(7), c.getDouble(8), c.getDouble(9), c.getDouble(10), c.getDouble(11),
                        c.getDouble(12), c.getDouble(13), c.getInt(14), c.getInt(15),
                        if (c.isNull(16)) null else c.getInt(16), c.getString(17)))
                }
            }
            return out
        }
    }

    fun gamingSessions(ctx: Context): List<GamingSession> {
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            val out = mutableListOf<GamingSession>()
            db.query("gaming_sessions", null, null, null, null, null, "started DESC", "50").use { c ->
                while (c.moveToNext()) {
                    out.add(GamingSession(c.getLong(0), c.getLong(1), c.getLong(2), c.getString(3), c.getString(4), c.getString(5),
                        c.getInt(6), c.getInt(7), c.getDouble(8), c.getDouble(9), c.getDouble(10), c.getDouble(11),
                        c.getDouble(12), c.getDouble(13), c.getInt(14), c.getInt(15),
                        if (c.isNull(16)) null else c.getInt(16), c.getString(17)))
                }
            }
            return out
        }
    }
    fun gamingSessionSamples(ctx: Context, sessionId: Long): List<Pair<Long, Double>> {
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).readableDatabase
            val out = mutableListOf<Pair<Long, Double>>()
            db.query("gaming_samples", arrayOf("time", "ms"), "session_id = ?", arrayOf(sessionId.toString()), null, null, "time ASC").use { c ->
                while (c.moveToNext()) out.add(c.getLong(0) to c.getDouble(1))
            }
            return out
        }
    }

    // ---- Last full check, for the widget. ----
    data class LastCheck(val pingAvg: Double, val jitterMs: Double, val lossPct: Double, val intlPct: Int, val domPct: Int, val scoreTotal: Int?, val scoreStatus: String, val checkedAt: Long = 0)
    fun saveLastCheck(ctx: Context, pingAvg: Double, jitterMs: Double, lossPct: Double, intlPct: Int, domPct: Int, scoreTotal: Int?, scoreStatus: String) {
        prefs(ctx).edit()
            .putString("last_check", "$pingAvg|$jitterMs|$lossPct|$intlPct|$domPct|${scoreTotal ?: ""}|$scoreStatus|${System.currentTimeMillis()}").apply()
    }
    fun lastCheck(ctx: Context): LastCheck? {
        val t = prefs(ctx).getString("last_check", "") ?: ""
        if (t.isBlank()) return null
        val a = t.split("|")
        if (a.size < 7) return null
        return LastCheck(a[0].toDoubleOrNull() ?: -1.0, a[1].toDoubleOrNull() ?: -1.0, a[2].toDoubleOrNull() ?: -1.0, a[3].toIntOrNull() ?: 0, a[4].toIntOrNull() ?: 0, a[5].toIntOrNull(), a[6], if (a.size > 7) a[7].toLongOrNull() ?: 0 else 0)
    }
    fun saveConnType(ctx: Context, t: String) {
        if (t != "—") prefs(ctx).edit().putString("last_conn_type", t).apply()
    }
    fun connType(ctx: Context): String? {
        val t = prefs(ctx).getString("last_conn_type", "") ?: ""
        return if (t.isBlank()) null else t
    }

    // ---- Logs / timeline (append-only, stay in prefs). ----
    fun addLog(ctx: Context, line: String) {
        val p = prefs(ctx)
        val old = p.getString(KEY_LOG, "")!!
        val lines = (line + "\n" + old).lines().take(200).joinToString("\n")
        p.edit().putString(KEY_LOG, lines).apply()
    }
    fun log(ctx: Context): String = prefs(ctx).getString(KEY_LOG, "") ?: ""

    fun compareText(ctx: Context): String {
        val lines = Gaming.log(ctx).lines().filter { it.isNotBlank() }
        if (lines.size < 2) return "مقایسه تست‌ها: هنوز دو تست گیمینگ ثبت نشده."
        val a = lines[0]; val b = lines[1]
        val hourlyData = hourly(ctx).split(";").filter { it.isNotBlank() }
        val avg = if (hourlyData.isEmpty()) 0 else hourlyData.mapNotNull { it.split(":").getOrNull(1)?.toIntOrNull() }.average()
        return "مقایسه دو تست آخر گیمینگ:\nآخرین: $a\nقبلی: $b\n\nمیانگین دسترسی ساعتی (ISP): ${"%.0f".format(avg)}٪ از ${hourlyData.size} نمونه ساعتی — نمودار روزانه/هفتگی از همین داده‌هاست."
    }
    fun addTimeline(ctx: Context, kind: String, line: String) {
        val p = prefs(ctx)
        val old = (p.getString("timeline", "") ?: "").lines().filter { it.isNotBlank() }.toMutableList()
        old.add(0, "${timeStr(System.currentTimeMillis())} [$kind] $line")
        while (old.size > 100) old.removeAt(old.size - 1)
        p.edit().putString("timeline", old.joinToString("\n")).apply()
    }
    data class TimelineEvent(val time: String, val kind: String, val text: String)
    fun parseTimeline(text: String): List<TimelineEvent> {
        return text.lines().filter { it.isNotBlank() }.map { line ->
            val open = line.indexOf(" [")
            val close = if (open >= 0) line.indexOf("] ", open) else -1
            if (open < 0 || close < 0) TimelineEvent("", "", line)
            else TimelineEvent(line.substring(0, open), line.substring(open + 2, close), line.substring(close + 2))
        }
    }
    fun timeline(ctx: Context): String = prefs(ctx).getString("timeline", "") ?: ""
    fun addSpike(ctx: Context, ms: Double) {
        val p = ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE)
        val old = (p.getString("spikes", "") ?: "").lines().filter { it.isNotBlank() }.toMutableList()
        old.add(0, "${timeStr(System.currentTimeMillis())} — Spike ${"%.0f".format(ms)}ms")
        while (old.size > 100) old.removeAt(old.size - 1)
        p.edit().putString("spikes", old.joinToString("\n")).apply()
    }
    fun spikes(ctx: Context): String = ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).getString("spikes", "") ?: ""
    fun addHourly(ctx: Context, ok: Int, total: Int) {
        val p = prefs(ctx)
        val hour = SimpleDateFormat("HH", Locale.US).format(Date())
        val old = p.getString("hourly", "") ?: ""
        p.edit().putString("hourly", (old + ";" + hour + ":" + (if (total == 0) 0 else ok * 100 / total)).split(";").filter { it.isNotBlank() }.takeLast(96).joinToString(";")).apply()
    }
    fun hourly(ctx: Context): String = prefs(ctx).getString("hourly", "") ?: ""
    fun blackbox(ctx: Context, line: String) {
        val p = prefs(ctx)
        val old = (p.getString("blackbox", "") ?: "").lines().filter { it.isNotBlank() }.toMutableList()
        old.add("${timeStr(System.currentTimeMillis())} $line")
        while (old.size > 20) old.removeAt(0)
        p.edit().putString("blackbox", old.joinToString("\n")).apply()
    }
    fun blackboxLog(ctx: Context): String = prefs(ctx).getString("blackbox", "") ?: ""

    fun clearAll(ctx: Context) {
        prefs(ctx).edit().clear().apply()
        ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit().clear().apply()
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            db.delete("samples", null, null); db.delete("ping_points", null, null)
            db.delete("loss_points", null, null); db.delete("gaming_sessions", null, null); db.delete("gaming_samples", null, null)
        }
    }

    // ---- Backup / restore: one valid JSON document (org.json — no hand-built
    // string escaping). Restore validates the structure + version first and
    // writes everything in ONE transaction, so a corrupt file can never
    // destroy the existing data. ----
    fun buildBackupJson(ctx: Context): String {
        migrateIfNeeded(ctx)
        val root = org.json.JSONObject()
        root.put("version", 1)
        root.put("exported_at", dateTimeStr(System.currentTimeMillis()))
        val samples = org.json.JSONArray()
        for (s in samplesFull(ctx)) {
            val o = org.json.JSONObject()
            o.put("time", s.time); o.put("ok", s.ok); o.put("total", s.total)
            o.put("avg_ms", s.avgMs); o.put("jitter_ms", s.jitterMs); o.put("loss_pct", s.lossPct)
            samples.put(o)
        }
        root.put("samples", samples)
        val pings = org.json.JSONArray()
        for ((t, ms) in pingPoints(ctx, limit = 0)) { val o = org.json.JSONObject(); o.put("time", t); o.put("ms", ms); pings.put(o) }
        root.put("ping_points", pings)
        val losses = org.json.JSONArray()
        for ((t, l) in lossPoints(ctx, limit = 0)) { val o = org.json.JSONObject(); o.put("time", t); o.put("loss", l); losses.put(o) }
        root.put("loss_points", losses)
        root.put("log", log(ctx))
        root.put("timeline", timeline(ctx))
        root.put("hourly", hourly(ctx))
        root.put("blackbox", blackboxLog(ctx))
        root.put("gaming_log", Gaming.log(ctx))
        root.put("gaming_matches", Gaming.matches(ctx))
        root.put("spikes", spikes(ctx))
        val sessions = org.json.JSONArray()
        for (gs in gamingSessionsAll(ctx)) {
            val o = org.json.JSONObject()
            o.put("started", gs.started); o.put("ended", gs.ended); o.put("profile", gs.profile); o.put("region", gs.region)
            o.put("host", gs.host); o.put("sent", gs.sent); o.put("received", gs.received); o.put("loss", gs.loss)
            o.put("avg_ms", gs.avgMs); o.put("min_ms", gs.minMs); o.put("max_ms", gs.maxMs); o.put("jitter_ms", gs.jitterMs)
            o.put("p95", gs.p95); o.put("spikes", gs.spikes); o.put("burst", gs.burst)
            if (gs.score != null) o.put("score", gs.score) else o.put("score", org.json.JSONObject.NULL)
            o.put("bb_grade", gs.bbGrade)
            val ss = org.json.JSONArray()
            for ((t, ms) in gamingSessionSamples(ctx, gs.id)) { val so = org.json.JSONObject(); so.put("time", t); so.put("ms", ms); ss.put(so) }
            o.put("samples", ss)
            sessions.put(o)
        }
        root.put("gaming_sessions", sessions)
        val lc = lastCheck(ctx)
        if (lc != null) {
            val o = org.json.JSONObject()
            o.put("ping_avg", lc.pingAvg); o.put("jitter_ms", lc.jitterMs); o.put("loss_pct", lc.lossPct)
            o.put("intl_pct", lc.intlPct); o.put("dom_pct", lc.domPct)
            if (lc.scoreTotal != null) o.put("score_total", lc.scoreTotal) else o.put("score_total", org.json.JSONObject.NULL)
            o.put("score_status", lc.scoreStatus); o.put("checked_at", lc.checkedAt)
            root.put("last_check", o)
        }
        val settings = org.json.JSONObject()
        settings.put("interval_sec", intervalSec(ctx)); settings.put("alert_threshold", alertThreshold(ctx))
        settings.put("live_ping", livePingOn(ctx)); settings.put("custom_target", customTarget(ctx))
        settings.put("dns_rounds", prefs(ctx).getInt("dns_rounds", 20))
        settings.put("alerts_on", prefs(ctx).getBoolean("alerts_on", true))
        root.put("settings", settings)
        return root.toString()
    }

    // Returns a human-readable result: "OK" or the exact reason it failed.
    // Strict type helpers for validation: org.json's opt* getters COERCE
    // wrong types silently (optInt("x") on "abc" returns the fallback), so
    // a corrupt value would slip through and only fail later — or worse,
    // be stored as a wrong default. These check the REAL JSON type.
    // A missing field is fine (the restore uses its default); a present
    // field with the wrong type is a corrupt file.
    private fun isNum(o: org.json.JSONObject, key: String): Boolean =
        !o.has(key) || o.opt(key) is Number
    private fun isNumOrNull(o: org.json.JSONObject, key: String): Boolean =
        !o.has(key) || o.isNull(key) || o.opt(key) is Number
    private fun isBool(o: org.json.JSONObject, key: String): Boolean =
        !o.has(key) || o.opt(key) is Boolean
    private fun isStr(o: org.json.JSONObject, key: String): Boolean =
        !o.has(key) || o.opt(key) is String
    private fun checkType(cond: Boolean, what: String) {
        if (!cond) throw IllegalArgumentException("فیلد $what نوع معتبر ندارد")
    }

    // Reads every row with the same strict getters the insert loop uses,
    // AND validates every section restoreFromJson reads AFTER the DB
    // transaction (settings, last_check) — v2.9 only validated the table
    // rows, so a corrupt settings/last_check threw AFTER the old data was
    // already deleted and replaced. Now a corrupt file in ANY section is
    // rejected with its exact position and the DB + prefs are never touched.
    // Returns an exact error message, or null when the file is fully valid.
    private fun validateRestoreJson(root: org.json.JSONObject): String? {
        return try {
            val sa = root.getJSONArray("samples")
            for (i in 0 until sa.length()) {
                val o = sa.getJSONObject(i)
                o.getLong("time"); o.getInt("ok"); o.getInt("total")
                o.optDouble("avg_ms", -1.0); o.optDouble("jitter_ms", -1.0); o.optDouble("loss_pct", -1.0)
            }
            val pa = root.getJSONArray("ping_points")
            for (i in 0 until pa.length()) {
                val o = pa.getJSONObject(i)
                o.getLong("time"); o.getDouble("ms")
            }
            if (root.has("loss_points")) {
                val la = root.getJSONArray("loss_points")
                for (i in 0 until la.length()) {
                    val o = la.getJSONObject(i)
                    o.getLong("time"); o.getDouble("loss")
                }
            }
            if (root.has("gaming_sessions")) {
                val ga = root.getJSONArray("gaming_sessions")
                for (i in 0 until ga.length()) {
                    val o = ga.getJSONObject(i)
                    checkType(isNum(o, "started"), "gaming_sessions[$i].started")
                    checkType(isNum(o, "ended"), "gaming_sessions[$i].ended")
                    checkType(isStr(o, "profile"), "gaming_sessions[$i].profile")
                    checkType(isStr(o, "region"), "gaming_sessions[$i].region")
                    checkType(isStr(o, "host"), "gaming_sessions[$i].host")
                    checkType(isNum(o, "sent"), "gaming_sessions[$i].sent")
                    checkType(isNum(o, "received"), "gaming_sessions[$i].received")
                    checkType(isNum(o, "loss"), "gaming_sessions[$i].loss")
                    checkType(isNum(o, "avg_ms"), "gaming_sessions[$i].avg_ms")
                    checkType(isNum(o, "min_ms"), "gaming_sessions[$i].min_ms")
                    checkType(isNum(o, "max_ms"), "gaming_sessions[$i].max_ms")
                    checkType(isNum(o, "jitter_ms"), "gaming_sessions[$i].jitter_ms")
                    checkType(isNum(o, "p95"), "gaming_sessions[$i].p95")
                    checkType(isNum(o, "spikes"), "gaming_sessions[$i].spikes")
                    checkType(isNum(o, "burst"), "gaming_sessions[$i].burst")
                    checkType(isNumOrNull(o, "score"), "gaming_sessions[$i].score")
                    checkType(isStr(o, "bb_grade"), "gaming_sessions[$i].bb_grade")
                    if (o.has("samples")) {
                        val ss = o.getJSONArray("samples")
                        for (j in 0 until ss.length()) {
                            val so = ss.getJSONObject(j)
                            so.getLong("time"); so.getDouble("ms")
                        }
                    }
                }
            }
            if (root.has("settings")) {
                val st = root.opt("settings")
                checkType(st is org.json.JSONObject, "settings (باید آبجکت باشد)")
                val so = st as org.json.JSONObject
                checkType(isNum(so, "interval_sec"), "settings.interval_sec")
                checkType(isNum(so, "alert_threshold"), "settings.alert_threshold")
                checkType(isBool(so, "live_ping"), "settings.live_ping")
                checkType(isStr(so, "custom_target"), "settings.custom_target")
                checkType(isNum(so, "dns_rounds"), "settings.dns_rounds")
                checkType(isBool(so, "alerts_on"), "settings.alerts_on")
            }
            if (root.has("last_check")) {
                val lc = root.opt("last_check")
                checkType(lc is org.json.JSONObject, "last_check (باید آبجکت باشد)")
                val lo = lc as org.json.JSONObject
                checkType(isNum(lo, "ping_avg"), "last_check.ping_avg")
                checkType(isNum(lo, "jitter_ms"), "last_check.jitter_ms")
                checkType(isNum(lo, "loss_pct"), "last_check.loss_pct")
                checkType(isNum(lo, "intl_pct"), "last_check.intl_pct")
                checkType(isNum(lo, "dom_pct"), "last_check.dom_pct")
                checkType(isNumOrNull(lo, "score_total"), "last_check.score_total")
                checkType(isStr(lo, "score_status"), "last_check.score_status")
                checkType(isNum(lo, "checked_at"), "last_check.checked_at")
            }
            null
        } catch (e: Exception) {
            "فایل بکاپ خراب است: ${e.message ?: e.javaClass.simpleName} — داده‌های قبلی دست نخورده باقی ماند"
        }
    }

    fun restoreFromJson(ctx: Context, json: String): String {
        val root = try { org.json.JSONObject(json) } catch (e: Exception) { return "فایل بکاپ خراب است: JSON معتبر نیست (${e.message})" }
        if (!root.has("version")) return "فایل بکاپ خراب است: نسخه فایل مشخص نیست"
        if (root.optInt("version", -1) != 1) return "نسخه فایل بکاپ پشتیبانی نمی‌شود: ${root.optInt("version", -1)}"
        if (!root.has("samples") || !root.has("ping_points")) return "فایل بکاپ ناقص است: بخش نمونه‌ها وجود ندارد"
        // v2.9: validate EVERY row BEFORE the transaction starts. The old
        // code only checked the JSON shape; a malformed row mid-file threw
        // during the insert loop. The transaction rolled back (old data was
        // safe), but the failure was late and generic. Now a bad row is
        // rejected with its exact position and the DB is never touched.
        val preError = validateRestoreJson(root)
        if (preError != null) return preError
        migrateIfNeeded(ctx)
        synchronized(dbLock) {
            val db = HistoryDb.get(ctx).writableDatabase
            db.beginTransaction()
            try {
                db.delete("samples", null, null); db.delete("ping_points", null, null)
                db.delete("loss_points", null, null); db.delete("gaming_sessions", null, null); db.delete("gaming_samples", null, null)
                val sa = root.getJSONArray("samples")
                for (i in 0 until sa.length()) {
                    val o = sa.getJSONObject(i)
                    insertSampleRow(db, o.getLong("time"), o.getInt("ok"), o.getInt("total"),
                        o.optDouble("avg_ms", -1.0), o.optDouble("jitter_ms", -1.0), o.optDouble("loss_pct", -1.0), "restore")
                }
                val pa = root.getJSONArray("ping_points")
                for (i in 0 until pa.length()) {
                    val o = pa.getJSONObject(i)
                    insertPingRow(db, o.getLong("time"), o.getDouble("ms"), if (o.getDouble("ms") >= 0) 1 else 0)
                }
                if (root.has("loss_points")) {
                    val la = root.getJSONArray("loss_points")
                    for (i in 0 until la.length()) {
                        val o = la.getJSONObject(i)
                        val cv = ContentValues().apply { put("time", o.getLong("time")); put("loss", o.getDouble("loss")) }
                        db.insert("loss_points", null, cv)
                    }
                }
                if (root.has("gaming_sessions")) {
                    val ga = root.getJSONArray("gaming_sessions")
                    for (i in 0 until ga.length()) {
                        val o = ga.getJSONObject(i)
                        val cv = ContentValues().apply {
                            put("started", o.optLong("started", 0)); put("ended", o.optLong("ended", 0))
                            put("profile", o.optString("profile", "")); put("region", o.optString("region", ""))
                            put("host", o.optString("host", "")); put("sent", o.optInt("sent", 0)); put("received", o.optInt("received", 0))
                            put("loss", o.optDouble("loss", 0.0)); put("avg_ms", o.optDouble("avg_ms", 0.0))
                            put("min_ms", o.optDouble("min_ms", 0.0)); put("max_ms", o.optDouble("max_ms", 0.0))
                            put("jitter_ms", o.optDouble("jitter_ms", 0.0)); put("p95", o.optDouble("p95", 0.0))
                            put("spikes", o.optInt("spikes", 0)); put("burst", o.optInt("burst", 0))
                            if (o.isNull("score")) putNull("score") else put("score", o.getInt("score"))
                            put("bb_grade", o.optString("bb_grade", "-"))
                        }
                        val sid = db.insert("gaming_sessions", null, cv)
                        if (o.has("samples")) {
                            val ss = o.getJSONArray("samples")
                            for (j in 0 until ss.length()) {
                                val so = ss.getJSONObject(j)
                                val scv = ContentValues().apply {
                                    put("session_id", sid); put("time", so.getLong("time")); put("ms", so.getDouble("ms"))
                                    put("ok", if (so.getDouble("ms") >= 0) 1 else 0)
                                }
                                db.insert("gaming_samples", null, scv)
                            }
                        }
                    }
                }
                db.setTransactionSuccessful()
            } catch (e: Exception) {
                return "بازیابی ناموفق شد: ${e.javaClass.simpleName} — داده‌های قبلی دست نخورده باقی ماند"
            } finally { db.endTransaction() }
        }
        val p = prefs(ctx).edit()
        if (root.has("log")) p.putString(KEY_LOG, root.optString("log", ""))
        if (root.has("timeline")) p.putString("timeline", root.optString("timeline", ""))
        if (root.has("hourly")) p.putString("hourly", root.optString("hourly", ""))
        if (root.has("blackbox")) p.putString("blackbox", root.optString("blackbox", ""))
        if (root.has("settings")) {
            val s = root.getJSONObject("settings")
            p.putInt(KEY_INTERVAL, s.optInt("interval_sec", 30))
            p.putInt("alert_threshold", s.optInt("alert_threshold", 40))
            p.putBoolean("live_ping", s.optBoolean("live_ping", false))
            p.putString(KEY_CUSTOM_TARGET, s.optString("custom_target", ""))
            p.putInt("dns_rounds", s.optInt("dns_rounds", 20))
            p.putBoolean("alerts_on", s.optBoolean("alerts_on", true))
        }
        p.apply()
        if (root.has("gaming_log")) ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit().putString("log", root.optString("gaming_log", "")).apply()
        if (root.has("gaming_matches")) ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit().putString("matches", root.optString("gaming_matches", "")).apply()
        if (root.has("spikes")) ctx.getSharedPreferences("gaming", Context.MODE_PRIVATE).edit().putString("spikes", root.optString("spikes", "")).apply()
        if (root.has("last_check")) {
            val o = root.getJSONObject("last_check")
            prefs(ctx).edit().putString("last_check",
                "${o.optDouble("ping_avg", -1.0)}|${o.optDouble("jitter_ms", -1.0)}|${o.optDouble("loss_pct", -1.0)}|${o.optInt("intl_pct", 0)}|${o.optInt("dom_pct", 0)}|${if (o.isNull("score_total")) "" else o.getInt("score_total")}|${o.optString("score_status", "")}|${o.optLong("checked_at", 0)}").apply()
        }
        return "OK"
    }

    fun backup(ctx: Context): File {
        val f = File(ctx.getExternalFilesDir(null), "netwatch-backup.json")
        f.writeText(buildBackupJson(ctx))
        return f
    }
    fun restore(ctx: Context): Boolean {
        return try {
            val f = File(ctx.getExternalFilesDir(null), "netwatch-backup.json")
            if (!f.exists()) return false
            restoreFromJson(ctx, f.readText()) == "OK"
        } catch (e: Exception) { false }
    }
    fun backupToUri(ctx: Context, uri: android.net.Uri): Boolean {
        return try {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(buildBackupJson(ctx).toByteArray(Charsets.UTF_8)) }
            true
        } catch (e: Exception) { false }
    }
    // SAF restore with the exact failure reason (used by MainActivity's toast).
    fun restoreFromUriReason(ctx: Context, uri: android.net.Uri): String {
        return try {
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: return "فایل خوانده نشد."
            restoreFromJson(ctx, text)
        } catch (e: Exception) { e.message ?: e.javaClass.simpleName }
    }

    fun restoreFromUri(ctx: Context, uri: android.net.Uri): Boolean {
        return try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.readBytes() ?: return false
            restoreFromJson(ctx, String(bytes, Charsets.UTF_8)) == "OK"
        } catch (e: Exception) { false }
    }

    // ---- Exports: full timestamps, real metrics, valid formats. ----
    fun exportCsv(ctx: Context): File {
        val f = File(ctx.getExternalFilesDir(null), "netwatch-history.csv")
        val sb = StringBuilder("time,ok,total,pct,avg_ms,jitter_ms,loss_pct\n")
        for (s in samplesFull(ctx)) {
            val pct = if (s.total == 0) 0 else s.ok * 100 / s.total
            sb.append("\"${dateTimeStr(s.time)}\",${s.ok},${s.total},$pct,${fmtNum(s.avgMs)},${fmtNum(s.jitterMs)},${fmtNum(s.lossPct)}\n")
        }
        f.writeText(sb.toString())
        return f
    }
    private fun fmtNum(v: Double): String = if (v < 0) "" else "%.1f".format(v)

    fun exportJson(ctx: Context): File {
        val f = File(ctx.getExternalFilesDir(null), "netwatch-history.json")
        f.writeText(buildBackupJson(ctx))
        return f
    }

    // Real Persian PDF: multi-page, RTL (text drawn from the right edge),
    // wrapped lines, full timestamps. Android PdfDocument renders Persian
    // shaping/joining correctly with the system font.
    fun exportPdf(ctx: Context): File {
        val f = File(ctx.getExternalFilesDir(null), "netwatch-report.pdf")
        val doc = android.graphics.pdf.PdfDocument()
        val paint = android.graphics.Paint().apply { textSize = 12f; color = android.graphics.Color.BLACK }
        val titlePaint = android.graphics.Paint().apply { textSize = 18f; color = android.graphics.Color.BLACK; isFakeBoldText = true }
        val headPaint = android.graphics.Paint().apply { textSize = 14f; color = android.graphics.Color.BLACK; isFakeBoldText = true }
        val pw = 595f; val ph = 842f; val margin = 40f; val rightX = pw - margin
        var pageNum = 1
        var page = doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pw.toInt(), ph.toInt(), pageNum).create())
        var canvas = page.canvas
        var y = 50f
        fun newPage() {
            doc.finishPage(page)
            pageNum++
            page = doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pw.toInt(), ph.toInt(), pageNum).create())
            canvas = page.canvas; y = 50f
        }
        fun drawRtl(t: String, p: android.graphics.Paint) {
            // Wrap a long line to the page width, right-aligned.
            var rest = t
            while (rest.isNotEmpty()) {
                var n = rest.length
                while (n > 0 && p.measureText(rest, 0, n) > pw - 2 * margin) n--
                if (n == 0) n = 1
                val part = rest.substring(0, n)
                canvas.drawText(part, rightX - p.measureText(part), y, p)
                y += 20f
                if (y > ph - 60) newPage()
                rest = rest.substring(n).trimStart()
            }
        }
        fun heading(t: String) { y += 8f; drawRtl(t, headPaint); y += 4f }
        drawRtl("NetWatch — Diagnostic Report", titlePaint)
        drawRtl("تاریخ گزارش: " + dateTimeStr(System.currentTimeMillis()), paint)
        drawRtl("Connection: local only, no server upload", paint)
        heading("تاریخچه بررسی‌ها (Ping / Jitter / Loss):")
        val samples = samplesFull(ctx)
        if (samples.isEmpty()) drawRtl("هنوز بررسی‌ای ثبت نشده است.", paint)
        for (s in samples.takeLast(200)) {
            val pct = if (s.total == 0) 0 else s.ok * 100 / s.total
            drawRtl("${dateTimeStr(s.time)} — ${s.ok}/${s.total} سالم ($pct٪) • Ping ${if (s.avgMs < 0) "—" else "%.0f".format(s.avgMs) + "ms"} • Jitter ${if (s.jitterMs < 0) "—" else "%.1f".format(s.jitterMs) + "ms"} • Loss ${if (s.lossPct < 0) "—" else "%.1f".format(s.lossPct) + "٪"}", paint)
        }
        heading("Gaming sessions:")
        val sessions = gamingSessions(ctx)
        if (sessions.isEmpty()) drawRtl("هنوز جلسه گیمینگ ثبت نشده است.", paint)
        for (gs in sessions) {
            drawRtl("${dateTimeStr(gs.started)} — ${gs.profile} • ${gs.region} • avg ${"%.0f".format(gs.avgMs)}ms • loss ${"%.1f".format(gs.loss)}٪ • score ${gs.score ?: "—"} • Bufferbloat ${gs.bbGrade}", paint)
        }
        heading("Blackbox (last 20 checks):")
        for (raw in blackboxLog(ctx).lines().take(20)) drawRtl(raw, paint)
        heading("History log:")
        for (raw in log(ctx).lines().take(100)) drawRtl(raw, paint)
        doc.finishPage(page)
        try { f.outputStream().use { doc.writeTo(it) } } finally { doc.close() }
        return f
    }

    fun timeStr(t: Long): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(t))
    fun dateTimeStr(t: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(t))
}
