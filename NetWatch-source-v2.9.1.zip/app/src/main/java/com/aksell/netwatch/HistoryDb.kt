package com.aksell.netwatch

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// SQLite storage (v2.6) — replaces the single big SharedPreferences string.
// Tables:
// - samples: one row per check (full or background), with ping/jitter/loss.
// - ping_points: every ping measurement with its timestamp; ms < 0 = failed
//   (charts draw a gap for failures, never 0ms).
// - loss_points: per-check packet-loss values with timestamps (loss sparkline).
// - gaming_sessions / gaming_samples: persisted gaming sessions with
//   per-sample timestamps, so a session survives leaving the screen.
// Retention: rows older than 30 days are pruned on write.
class HistoryDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "netwatch.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE samples(id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, ok INTEGER NOT NULL, total INTEGER NOT NULL, avg_ms REAL NOT NULL, jitter_ms REAL NOT NULL, loss_pct REAL NOT NULL, source TEXT NOT NULL)")
        db.execSQL("CREATE TABLE ping_points(id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, ms REAL NOT NULL, ok INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE loss_points(id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, loss REAL NOT NULL)")
        db.execSQL("CREATE TABLE gaming_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, started INTEGER NOT NULL, ended INTEGER NOT NULL, profile TEXT NOT NULL, region TEXT NOT NULL, host TEXT NOT NULL, sent INTEGER NOT NULL, received INTEGER NOT NULL, loss REAL NOT NULL, avg_ms REAL NOT NULL, min_ms REAL NOT NULL, max_ms REAL NOT NULL, jitter_ms REAL NOT NULL, p95 REAL NOT NULL, spikes INTEGER NOT NULL, burst INTEGER NOT NULL, score INTEGER, bb_grade TEXT NOT NULL)")
        db.execSQL("CREATE TABLE gaming_samples(id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, time INTEGER NOT NULL, ms REAL NOT NULL, ok INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_samples_time ON samples(time)")
        db.execSQL("CREATE INDEX idx_ping_time ON ping_points(time)")
        db.execSQL("CREATE INDEX idx_loss_time ON loss_points(time)")
        db.execSQL("CREATE INDEX idx_gsamples_session ON gaming_samples(session_id)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    companion object {
        const val RETENTION_MS: Long = 30L * 24 * 60 * 60 * 1000
        @Volatile private var inst: HistoryDb? = null
        fun get(ctx: Context): HistoryDb = inst ?: synchronized(this) {
            inst ?: HistoryDb(ctx.applicationContext).also { inst = it }
        }
    }
}
